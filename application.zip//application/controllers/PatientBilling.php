<?php

/* * ***************************************************** */
/** Class/Function Name            : PatientBilling()
 * /**
 * /** Class/Function Description  : This class/function is use New Patient Report.
 * /**
 * /**
 * /** Author                       : Bhagwan Pawar[bhagwan.pawar@appetals.com]
 * /**
 * /** Creation Date                : [04/05/2016]
 * /**
 * /** param1                       : -
 * /** param2                       : -
 * /** return                       : New Patient Billing view
 * /**
 * /******************************************************** */
defined('BASEPATH') OR exit('No direct script access allowed');

class PatientBilling extends CI_Controller {

    public function patientBillingList() {
        $this->load->view('patientbilling/newpatientreport_list');
    }

    public function getPatientBillingtList() {
        $newpatientReportList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $newpatientReport = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($newpatientReport as $p) {
            $newpatientReportList['data'][] = $p;
        }

        $newpatientReportList['total'] = count($newpatientReportList['data']);
        $newpatientReportList['data'] = (array_slice($newpatientReportList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($newpatientReportList));
    }

}
