<?php

/* * ***************************************************** */
/** Class/Function Name            : Reports()
 * /**
 * /** Class/Function Description  : This class/function is use New Patient Report.
 * /**
 * /**
 * /** Author                       : Bhagwan Pawar[bhagwan.pawar@appetals.com]
 * /**
 * /** Creation Date                : [02/05/2016]
 * /**
 * /** param1                       : -
 * /** param2                       : -
 * /** return                       : New Patient Report view
 * /**
 * /******************************************************** */
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    public function newPatientReportList() {
        $this->load->view('reports/newpatientreport_list');
    }

    public function getNewpatientReportList() {
        $newpatientReportList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $newpatientReport = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($newpatientReport as $p) {
            $newpatientReportList['data'][] = $p;
        }

        $newpatientReportList['total'] = count($newpatientReportList['data']);
        $newpatientReportList['data'] = (array_slice($newpatientReportList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($newpatientReportList));
    }

    public function patientBillingReportList() {
        $this->load->view('reports/patientbillingreport_list');
    }

    public function getPatientBillingList() {
        $patientBillingList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $patientbilling = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($patientbilling as $p) {
            $patientBillingList['data'][] = $p;
        }

        $patientBillingList['total'] = count($patientBillingList['data']);
        $patientBillingList['data'] = (array_slice($patientBillingList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($patientBillingList));
    }

    public function revenueReportList() {
        $this->load->view('reports/revenuereport_list');
    }

    public function getRevenueReportList() {
        $patientBillingList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $patientbilling = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($patientbilling as $p) {
            $patientBillingList['data'][] = $p;
        }

        $patientBillingList['total'] = count($patientBillingList['data']);
        $patientBillingList['data'] = (array_slice($patientBillingList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($patientBillingList));
    }

    public function outstandingReportList() {
        $this->load->view('reports/outstandingreport_list');
    }

    public function getOutstandingReportList() {
        $patientBillingList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $patientbilling = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($patientbilling as $p) {
            $patientBillingList['data'][] = $p;
        }

        $patientBillingList['total'] = count($patientBillingList['data']);
        $patientBillingList['data'] = (array_slice($patientBillingList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($patientBillingList));
    }

    public function missedApptReportList() {
        $this->load->view('reports/missedapptreport_list');
    }

    public function getMissedApptReportList() {
        $patientBillingList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $patientbilling = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($patientbilling as $p) {
            $patientBillingList['data'][] = $p;
        }

        $patientBillingList['total'] = count($patientBillingList['data']);
        $patientBillingList['data'] = (array_slice($patientBillingList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($patientBillingList));
    }

    public function cancelledApptReportList() {
        $this->load->view('reports/cancelledapptreport_list');
    }

    public function getCancelledApptReportList() {
        $patientBillingList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $patientbilling = json_decode(file_get_contents(base_url() . '/assets/json/newpatientreport.json'), true);

        foreach ($patientbilling as $p) {
            $patientBillingList['data'][] = $p;
        }

        $patientBillingList['total'] = count($patientBillingList['data']);
        $patientBillingList['data'] = (array_slice($patientBillingList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($patientBillingList));
    }

}
