<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('patients/patients_listing');
	}	
        public function patientsViews()
	{
                $page = $this->uri->segment(1);
		$this->load->view('patients/'.$page);
	}       
	public function patientsPopup()
	{
                $page = $this->uri->segment(2);
		$this->load->view('patients/popup/'.$page);
	}
        public function patientCommonList()
	{
		$this->load->view('patients/patients_tabs');
	}		
        public function getPatientsList()
        {
            $patientList=array();
            $status = $this->input->post('status');
            if($this->input->post('pageno') != ''){
                $page = $this->input->post('pageno') - 1;
            } else {
                $page = 0;
            }            
            $status = $this->input->post('status');
            
            
            $limit=$this->config->item('pagination_limit');
            $start=$page * $limit;
            
            $patientList['data']=$this->crud->userMeta($status,$start,$limit);           
            if($status !=0 || $status != 1)
                $wh=array("status"=>'1',"status"=>'2',"user_group_id"=>"2");
            else
                $wh=array("status"=>$status,"user_group_id"=>"2");
                    
            $patientList['total'] = $this->crud->select('*', SELF_USERS, $wh, '', '', '', '', 'count',$echo = 0);                              
            $this->output->set_content_type('application/json')->set_output(json_encode($patientList));                          
                      
        }	
        public function savePatient(){
           $dob=$this->input->post('dob');          
           $data_users = array(
                'user_group_id' => '2',                
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'gender' =>$this->input->post('gender'),
                'dob' => isset($dob) ? strftime("%Y-%m-%d", strtotime($dob)) : "",
                'status' =>1,
                'created_by' =>'Amruta',
                'created_date' =>date("Y-m-d H:i:s"),
                'modified_by' =>'Amruta',
                'modified_date' =>date("Y-m-d H:i:s")
            );   
           $last_user_id = $this->crud->insert(SELF_USERS, $data_users); 
            
           $array_key=array_keys($this->input->post());
           $array_count=count($array_key);
            foreach ($array_key as $val){
                $data = array(
                   'user_id' => $last_user_id,                
                   'meta_key' => $val,
                   'meta_values' => $this->input->post($val),
                   'created_by' =>'Amruta',
                   'is_advised' =>'0'
                );      
                $insert_id = $this->crud->insert(SELF_USERS_META, $data);
            }
        }	                
}
