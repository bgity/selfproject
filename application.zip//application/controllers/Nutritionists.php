<?php

/* * ***************************************************** */
/** Class/Function Name            : Nutritionists()
 * /**
 * /** Class/Function Description    : This class/function is use Nutritionist list nad add.
 * /**
 * /**
 * /** Author                      : Bhagwan Pawar[bhagwan.pawar@appetals.com]
 * /**
 * /** Creation Date                : [11/04/2016]
 * /**
 * /** param1                        : -
 * /** param2                        : -
 * /** return                        : Nutritionist master view
 * /**
 * /******************************************************** */
defined('BASEPATH') OR exit('No direct script access allowed');

class Nutritionists extends CI_Controller {

    public function index() {
        $this->load->view('nutritionists/nutritionst_list');
    }

    public function nutritionstadd() {
        $this->load->view('nutritionists/nutritionists_add');
    }

    public function nutritionistsDetails() {
        $this->load->view('nutritionists/nutritionists_details');
    }

    public function nutritioniststabList() {
        $this->load->view('nutritionists/nutritionists_tabs');
    }

    public function getNutritionistsList() {
        $nutritionistList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }
        $status = $this->input->post('status');
        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $nutritionist = json_decode(file_get_contents(base_url() . '/assets/json/nutr.json'), true);
        if ($status == 'showall') {
            foreach ($nutritionist as $p) {
                $nutritionistList['data'][] = $p;
            }
        } else {
            foreach ($nutritionist as $p) {
                if ($p['status'] == $status) {
                    $nutritionistList['data'][] = $p;
                }
            }
        }

        $nutritionistList['total'] = count($nutritionistList['data']);
        $nutritionistList['data'] = (array_slice($nutritionistList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($nutritionistList));
    }

}
