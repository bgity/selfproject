<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Master extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/master
     * 	- or -  
     * 		http://example.com/index.php/master/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/master/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }

    public function index() {
        //$this->load->view('client/client_list'); 
        //$this->load->view('client/client_info');
    }

    public function foodGroupMasterList() {
        $this->load->view('master/foodGroupMasterList');
    }

    public function get_foodGroup() {
        $p = $this->master_model->get_foodGroup();
        //echo "<pre>";print_r($p);"<pre>"; die;
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function editMasterFoodGroupView() {
        $this->load->view('master/editMasterFoodGroupView');
    }

    public function getMasterFoodEditdetails() {
        $pid = $this->input->post('pid');
        if ($pid > 0) {
            $pid = $pid;
        } else {
            $pid = 1;
        }
        $p = $this->master_model->getMasterFoodEditdetails($pid);
        //echo "<pre>";print_r($p);"<pre>"; die;
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function editFoodGroupMaster() {
        //echo "<pre>";print_r($_POST);"<pre>"; die;
        $id = $this->input->post('id');
        $data['name'] = $this->input->post('name');
        $data['weight_per_serving'] = $this->input->post('weight_per_serving');
        $data['prot_per_serving'] = $this->input->post('prot_per_serving');
        $data['fat_per_serving'] = $this->input->post('fat_per_serving');
        $data['chol_per_serving'] = $this->input->post('chol_per_serving');
        $data['calo_per_serving'] = $this->input->post('calo_per_serving');
        $data['calc_per_serving'] = $this->input->post('calc_per_serving');



        $p = $this->master_model->editFoodGroupMaster($data, $id);

        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function getFoodMaster() {
        $result = $this->master_model->getFoodMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getFoodMasterShort() {
        $result = $this->master_model->getFoodMasterShort();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getFoodMasterCustom() {
        $result = $this->master_model->getFoodMasterCustom();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function heightWeight() {
        $this->load->view('master/heightWeight');
    }

    public function viewHeightWeights() {
        $result = $this->master_model->getHeightWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addHeightWeightview() {
        $this->load->view('master/heightWeightAdd');
    }

    public function addHeightWeight() {
        $result = $this->master_model->addHeightWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function saveHWDet() {
        $result = $this->master_model->saveHWDet();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function foodMaster() {
        $this->load->view('master/foodMaster');
    }

    public function addFoodsview() {
        $this->load->view('master/foodAdd');
    }

    public function addFood() {
        $result = $this->master_model->addFood();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getFoodDetails() {
        $result = $this->master_model->getFoodDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editFood() {
        $result = $this->master_model->editFood();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteFood() {
        $result = $this->master_model->deleteFood();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function uomMaster() {
        $this->load->view('master/uomMaster');
    }

    public function viewUomMaster() {
        $result = $this->master_model->getUomMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function saveUOMDet() {
        $result = $this->master_model->saveUOMDet();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteUom() {
        $result = $this->master_model->deleteUom();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getPlanFoodOptions() {
        $result = array("sandwich", "sambhar", "butter", "bajra", "jowar");
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# body weight #######################	

    public function bodyWeightMaster() {
        $this->load->view('master/bodyWeightMaster');
    }

    public function moreBodyWeight() {
        $this->load->view('master/moreBodyWeight');
    }

    public function get_bodyWeight() {
        $p = $this->master_model->get_bodyWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function editBodyWeightMaster() {
        $this->load->view('master/editBodyWeightMaster');
    }

    public function getBodyWeightDetails() {
        $pid = $this->input->post('pid');
        $p = $this->master_model->get_bodyWeightDetail($pid);
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function editBodyWeight() {
        $result = $this->master_model->editBodyWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addBodyWeight() {
        $result = $this->master_model->addBodyWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteBodyWeight() {
        $result = $this->master_model->deleteBodyWeight();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# end body weight #######################
    ############# Frame Size start #######################	

    public function frameSizeMaster() {
        $this->load->view('master/frameSizeMaster');
    }

    public function editFrameSizeView() {
        $this->load->view('master/editFrameSize');
    }

    public function getFrameSize() {
        $p = $this->master_model->getFrameSize();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function getFrameSizeDetails() {
        $p = $this->master_model->getFrameSizeDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function addFrameSize() {
        $result = $this->master_model->addFrameSize();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editFrameSize() {
        $result = $this->master_model->editFrameSize();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function saveFrameSizeDet() {
        $result = $this->master_model->saveFrameSizeDet();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# Frame Size end #######################
    ############# intake start #######################	

    public function intakeMaster() {
        $this->load->view('master/intakeMaster');
    }

    public function addIntakeView() {
        $this->load->view('master/addIntake');
    }

    public function getIntake() {
        $p = $this->master_model->getIntake();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function getIntakeDetails() {
        $p = $this->master_model->getIntakeDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function addIntake() {
        $result = $this->master_model->addIntake();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editIntake() {
        $result = $this->master_model->editIntake();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteIntake() {
        $result = $this->master_model->deleteIntake();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# intake end #######################	
    ############# Food Pref start #######################	

    public function foodPrefMaster() {
        $this->load->view('master/foodPrefMaster');
    }

    public function getFoodpfsMaster() {
        $result = $this->master_model->getFoodpfsMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function saveFoodpfDet() {
        $result = $this->master_model->saveFoodpf();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteFoodpf() {
        $result = $this->master_model->deleteFoodpf();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# disease recommend start #######################	

    public function diseaseRecommendation() {
        $this->load->view('master/diseaseRecommendation');
    }

    public function addDiseaseRecView() {
        $this->load->view('master/addDiseaseRec');
    }

    public function getDiseases() {
        $result = $this->master_model->getDisease();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getDiseaseRecDetails() {
        $p = $this->master_model->getDiseaseRecDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($p));
    }

    public function getDiseaseRec() {
        $result = $this->master_model->getDiseaseRec();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    /* public function saveDiseaseRec() {
      $result = $this->master_model->saveDiseaseRec();
      $this->output->set_content_type('application/json')->set_output(json_encode($result));
      } */

    public function addDiseaseRec() {
        $result = $this->master_model->addDiseaseRec();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editDiseaseRec() {
        $result = $this->master_model->editDiseaseRec();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteDiseaseRec() {
        $result = $this->master_model->deleteDiseaseRec();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addDiseaseView() {
        $this->load->view('master/addDisease');
    }

    public function addDisease() {
        $result = $this->master_model->addDisease();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ############# disease recommend end #######################

    public function addClientView() {
        $this->load->view('plan/addClient');
    }

    ########### Food item master ###########

    public function foodItemMaster() {
        $this->load->view('master/foodItemMaster');
    }

    public function addFoodItemview() {
        $this->load->view('master/foodItemAdd');
    }

    public function getFoodItemMaster() {
        $result = $this->master_model->getFoodItemMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addFoodItem() {
        $result = $this->master_model->addFooditem();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getFoodItemDetails() {
        $result = $this->master_model->getFoodItemDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editFoodItem() {
        $result = $this->master_model->editFoodItem();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteFoodItem() {
        $result = $this->master_model->deleteFoodItem();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ########### end Food item master ###########
    ########### Exercise master ###########

    public function exerciseMaster() {
        $this->load->view('master/exerciseMaster');
    }

    public function addExerciseview() {
        $this->load->view('master/exerciseAdd');
    }

    public function getExerciseMaster() {
        $result = $this->master_model->getExerciseMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addExercise() {
        $result = $this->master_model->addExercise();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function getExerciseDetails() {
        $result = $this->master_model->getExerciseDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editExercise() {
        $result = $this->master_model->editExercise();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteExercise() {
        $result = $this->master_model->deleteExercise();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    ########### end Exercise master ###########
    ############# User master #######################	

    public function userMaster() {
        $this->load->view('master/userMaster');
    }

    public function addUserView() {
        $this->load->view('master/addUser');
    }

    public function getUserMaster() {
        $user = $this->master_model->getUserMaster();
        $this->output->set_content_type('application/json')->set_output(json_encode($user));
    }

    public function getUserDetails() {
        $userDetails = $this->master_model->getUserDetails();
        $this->output->set_content_type('application/json')->set_output(json_encode($userDetails));
    }

    public function addUser() {
        $result = $this->master_model->addUser();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function editUser() {
        $result = $this->master_model->editUser();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function deleteUser() {
        $result = $this->master_model->deleteUser();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
    }

    public function addGroupItem() {
        $this->load->view('addgroupitem');
    }

    public function addGroup() {
        $this->load->view('addgroup');
    }

    public function addMasterGroup() {
        //$result = $this->master_model->deleteUser();
        $data = $this->input->post();
        $now = date("Y-m-d H:i:s");
        if ($data['mastername'] == 'Lab Tests') {
            $section_id = 1;
            $master_type_id = 1;
        }
        $type_machine_name = str_replace(' ', '_', strtolower($data['mastername']));
        $group_machin_name = str_replace(' ', '_', strtolower($data['groupname']));

        $insert_data = array('machine_name' => $group_machin_name,
            'name' => $data['groupname'],
            'master_type_id' => $master_type_id,
            'is_required' => '0', 'status' => '1',
            'created_by' => 'bhagwan',
            'created_date' => $now);
        $res = $this->crud->insert('master_group', $insert_data);
        if ($res) {
            $data['success'] = true;
            $data['message'] = " Lab Test Group has been added successfully!";
        } else {
            $data['success'] = false;
            $data['message'] = 'Unable to add! Please try again.';
        }
        //return $data;
        $this->output->set_content_type('application/json')->set_output(json_encode($data));
        //echo $data;
    }
    
    public function addMasterGroupItems() {
        
        $data = $this->input->post();
        
        $now = date("Y-m-d H:i:s");
        
       
        $item_machin_name= str_replace(' ', '_', strtolower($data['item_lable']));

        $insert_data = array('machine_name' => $item_machin_name,
            'name' => $data['item_lable'],
            'master_group_id' => $data['grpid'],
            'field_type' => $data['field_type'],
            'unit_id' => '0', 
            'is_required'=>'0',
            'status' => '1',
            'created_by' => 'bhagwan',
            'created_date' => $now);
        $res = $this->crud->insert('master_group', $insert_data);
        if ($res) {
            $data['success'] = true;
            $data['message'] = " Lab Test Group has been added successfully!";
        } else {
            $data['success'] = false;
            $data['message'] = 'Unable to add! Please try again.';
        }
        //return $data;
        $this->output->set_content_type('application/json')->set_output(json_encode($data));
        //echo $data;
    }


    public function anthropometricMasterList() {
        $this->load->view('master/anthropometricmaster_list');
    }

    public function dietrecallmasterList() {
        $this->load->view('master/dietrecallmaster_list');
    }

    public function branchMasterList() {
        $this->load->view('master/branchmaster_list');
    }

    public function branchAdd() {
        $this->load->view('master/branchmaster_add');
    }
    
     public function unitMasterList() {
        $this->load->view('master/unitmaster_list');
    }
    
    public function getUnitList() {
        $BranchList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $branch = json_decode(file_get_contents(base_url() . '/assets/json/UnitMaster.json'), true);

        foreach ($branch as $p) {
            $BranchList['data'][] = $p;
        }

        $BranchList['total'] = count($BranchList['data']);
        $BranchList['data'] = (array_slice($BranchList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($BranchList));
    }

    public function unitAdd() {
        $this->load->view('master/unitmaster_add');
    }
    
    public function programMainMasterList() {
        $this->load->view('master/programmaster_list');
    }

    public function programMainAdd() {
        $this->load->view('master/programmaster_add');
    }

    public function getProgramMainList() {
        $BranchList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $branch = json_decode(file_get_contents(base_url() . '/assets/json/branchMaster.json'), true);

        foreach ($branch as $p) {
            $BranchList['data'][] = $p;
        }

        $BranchList['total'] = count($BranchList['data']);
        $BranchList['data'] = (array_slice($BranchList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($BranchList));
    }
    
    public function labNameMasterList() {
        $this->load->view('master/labnamemaster_list');
    }

    public function getLabNameList() {
        $BranchList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $branch = json_decode(file_get_contents(base_url() . '/assets/json/branchMaster.json'), true);

        foreach ($branch as $p) {
            $BranchList['data'][] = $p;
        }

        $BranchList['total'] = count($BranchList['data']);
        $BranchList['data'] = (array_slice($BranchList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($BranchList));
    }

    public function getBranchList() {
        $BranchList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }

        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $branch = json_decode(file_get_contents(base_url() . '/assets/json/branchMaster.json'), true);

        foreach ($branch as $p) {
            $BranchList['data'][] = $p;
        }

        $BranchList['total'] = count($BranchList['data']);
        $BranchList['data'] = (array_slice($BranchList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($BranchList));
    }

    public function diagnosisMasterList() {
        $this->load->view('master/diagnosismaster_list');
    }

    public function diseasesMasterList() {
        $this->load->view('master/diseasesmaster_list');
    }

    public function exerciseMasterList() {
        $this->load->view('master/exercisemaster_list');
    }

    public function labTestMasterList() {
        $this->load->view('master/labtestmaster_list');
    }

    public function geneticTestMasterList() {
        $this->load->view('master/geneticmaster_list');
    }

    public function medicationMasterList() {
        $this->load->view('master/medicationmaster_list');
    }

    public function programList() {
        $this->load->view('master/program_list');
    }

    public function programtabList() {
        $this->load->view('master/program_tabs');
    }

    public function programAdd() {
        $this->load->view('master/program_add');
    }

    public function getProgramsList() {

        $programList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }
        $status = $this->input->post('status');
        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $programData = json_decode(file_get_contents(base_url() . '/assets/json/programMaster.json'), true);
        foreach ($programData as $n) {
            if (isset($n['status']) == $status) {
                $programList['data'][] = $n;
            }
        }
        $programList['total'] = count($programList['data']);
        $programList['data'] = (array_slice($programList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($programList));
    }

    public function questionnaireMasterList() {
        $this->load->view('master/questionnairemaster_list');
    }

    public function labNameAdd() {
        $this->load->view('master/labnamemaster_add');
    }

    public function dietRecallMaster()
    {
        $dietrecallList=array();
        $query = $this->crud->select("*",'master_group',array("master_type_id"=>2),'','','','','result_array');
        foreach($query as $row)
        {

            $query1 = $this->crud->select("*",'master_group_item',array("master_group_id"=>$row['id']),'','','','','result_array');
            foreach($query1 as $row1)
            {
                $innerarray=array();
                $innerarray[]['name'] = $row1['name'];
            }
            $dietrecallList[]=array("group"=>$row['name'],"item"=>$innerarray);
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($dietrecallList));
    }

}
