<div class="container-fluid">
<div class="row">
<div class="login_panel_self">
<div class="col-md-4 no-space">
<div class="self_care_login_area">
	<div class="login_container">
	<div class="logoself_login_page"> <img src="http://localhost/selfcare/assets/layouts/layout/img/self_care.png" alt="logo" class="logo-default"> </div>
          <div class="sign_head_ogin">Login to your Account </div>	
            <form action="http://localhost/selfcare/dashboard.html" method="post" enctype="multipart/form-data">
              <div class="form-group">            
                <input type="text" name="email" value="" placeholder="Username" id="input-email" class="form-control login_self_fiels">
              </div>
              <div class="form-group">                
                <input type="password" name="password" value="" placeholder="*********" id="input-password" class="form-control login_self_fiels">
                </div>
              <input type="submit" value="SIGN IN" class="login_btn_self">
                           
            </form>
            </div>
             <a class="forgotpass_link" href="#">Forgot Password</a>
            </div>   </div> 
<div class="col-md-8 no-space imgeover_login"> <img src="assets/layouts/layout/self-images/login_right.jpg">	</div>  

  </div>  </div>     </div>        
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<!-- BEGIN LOGIN -->
		<div class="container-fluid">
<div class="row">
<div class="login_panel_self">
<div class="col-md-4 no-space">
       
        <div class="self_care_login_area">
		<div class="login_container">
            <!-- BEGIN LOGIN FORM -->
			<div class="logoself_login_page"> <img src="http://localhost/selfcare/assets/layouts/layout/img/self_care.png" alt="logo" class="logo-default"> </div>
               <div class="sign_head_ogin">Login to your Account </div>
            <form class="login-form" action="dashboard.html" method="post" ng-show="showlogin">
			
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
                    <span> Enter any username and password. </span>
                </div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                    <div class="input-icon">
                        <i class="fa fa-user"></i>
                        <input class="form-control placeholder-no-fix login_self_fiels" type="text" autocomplete="off" placeholder="Username" name="username" /> </div>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock"></i>
                        <input class="form-control placeholder-no-fix login_self_fiels" type="password" autocomplete="off" placeholder="Password" name="password" /> </div>
                </div>
                    <button type="submit" class="login_btn_self"> Login </button>
                    <a href="javascript:;" ng-click="showlogin=false; showforgot=true;" class="forgotpass_link">Forgot Password</a>
                            
            </form>
            <!-- END LOGIN FORM -->
            <!-- BEGIN FORGOT PASSWORD FORM -->
            <h3>{{ sent_message }}</h3>
            <button type="button" id="back-btn" class="btn grey-salsa btn-outline" ng-show="sent_message"  ng-click="showlogin=true; showforgot=false;sent_message='';"> Back </button>
            <form class="forget-form" ng-show="showforgot">
                <h3>Forget Password ?</h3>
                <p> Enter your e-mail address below to reset your password. </p>
                <div class="form-group">
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix login_self_fiels" type="text" autocomplete="off" placeholder="Email" name="email" /> </div>
                </div>
                <div class="form-actions">                   
                    <button type="button" id="back-btn" class="btn grey-salsa btn-outline"  ng-click="showlogin=true; showforgot=false;"> Back </button>
                    <button type="submit" class="btn green pull-right" ng-click="sendpassword()"> Reset Password </button>
                </div>
            </form>
            <!-- END FORGOT PASSWORD FORM -->            
        </div> </div> </div> 
<div class="col-md-8 no-space imgeover_login"> <img src="assets/layouts/layout/self-images/login_right.jpg">	</div>  
		</div></div></div>
    
        <!-- END LOGIN -->