 <div class="col-md-12 medication_area_maindiv">
  <form class="form-horizontal patient_area_sec_no_bg"> 
                    <div class="margin-15-panel">
                        
						<div class="portlet-body collapse in" id="medication_div pateint_meditaion_area">     
                            <div class="tabbable-line">
                                <ul class="nav nav-tabs">                                   
                                    <li class="active"><a data-target="#tab_normal" data-toggle="tab" aria-expanded="true"> Outside Medication </a></li>
                                    <li><a data-target="#tab_selfcare" data-toggle="tab" aria-expanded="true">Selfcare Medication</a></li>
                                </ul>
                                <div class="tab-content">                                                                                              
                                    <div class="tab-pane active" id="tab_normal">                                                           
                                        <div class="portlet-body">
                                            <!--------<div class="col-md-12">                                                
                                                <div class="col-md-4">Name</div>
                                                <div class="col-md-4">Dosage</div>
                                                <div class="col-md-4">Remarks</div>                                                
                                            </div>-------------->                                            
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Name </span>
                                                <div class="form-group form-md-line-input">
                                                    <input type="text" class="form-control">
											</div>
											</div>
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Dosage </span>
                                                <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1">
                                            </div>     
											</div>								
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Remark </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div>  
											</div>  
											<div class="col-md-12"><button class="btn save-intense">Add</button></div>										
                                        </div>
                                    </div>  
                                    <div class="tab-pane" id="tab_selfcare">  
                                        <div class="portlet-body">
                                            <!-----------<div class="col-md-12">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-1">Name</div>
                                                <div class="col-md-3">Dosage</div>
                                                <div class="col-md-3">Remarks</div>
                                                <div class="col-md-3">Reminder in</div>
                                            </div>--------------->
                                            <div class="col-md-6 no-space">
											<div class="col-md-6 labletext_medi">
												<span class="labletext_medi">Select  </span>
                                                <div class="form-group form-md-line-input">
                                                <select class="bs-select form-control">
                                                    <option value="">Select</option>
                                                    <option>Multi Vitamins</option>
                                                    <option>Vitamins</option>                            
                                                </select>
                                            </div>
											</div>
											<div class="col-md-6 labletext_medi">
											<span class="labletext_medi">Name </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div> </div>
											</div>
											<div class="col-md-6">
											<div class="col-md-6 labletext_medi">
											<span class="labletext_medi">Dosage </span>
                                                <div class="form-group form-md-line-input">
                                                 <input type="text" class="form-control dosage_mask"   size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1">
                                            </div></div>
											<div class="col-md-6 labletext_medi">
											<span class="labletext_medi">Remark </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div>  
											</div> 
											</div>  
                                            
                                                                                  
                                            <div class="col-md-12"><button class="btn save-intense">Add</button></div>
												
										
                                        </div>
                                    </div>  

                                </div>                                                                                             
                            </div>                                            
                        </div> 
                    </div> 
                    </form>                   
                </div>  