<div class="portlet-body">
    <div class="table-responsive table_new_self_bg line-height-30">
        <table class="table">
            <tbody class="margin-left-15">
                <tr>
                    <td class="padding-left-15"> Blood Group </td>
                    <td> O +ve </td>
                    <td> Genetic-Pridisposition </td>
                    <td> Thyroid, Migrane </td>
                    <td> &nbsp; </td>
                </tr>
                <tr>
                    <td class="padding-left-15"> Current Meditation </td>
                    <td> Thyroid Migrane </td>
                    <td> Dignosis </td>
                    <td> Thyroid </td>
                    <td> &nbsp; </td>
                </tr>
                <tr>
                    <td class="padding-left-15"> Diseases </td>
                    <td> Thyronorm </td>
                    <td> Allergy Alert </td>
                    <td> Thyroid <img src="assets/layouts/layout/self-images/icon.png" class="left_text_self_icon"></td>
                    <td> <button type="button" class="btn btn-circle red-mint leftplace_tenp"> Details </button> </td>

                </tr>
            </tbody>
        </table>
    </div>  
</div>