<div class="portlet-body">   
    <div class="table-responsive">
        <div class="comment_area_patient">
            <div class="col-md-12">
            <ul class="media-list">
                <li class="media">
                <a class="pull-left" href="javascript:;">
                <img class="todo-userpic" src="assets/layouts/layout/self-images/avatar4.jpg" width="27px" height="27px"> </a>
                <div class="media-body todo-comment">
                    <button type="button" class="todo-comment-btn btn btn-circle btn-default btn-sm">&nbsp; Reply &nbsp;</button>
                    <p class="todo-comment-head">
                    <span class="todo-comment-username"> Sheetal Manchanda </span> &nbsp;
                    <span class="todo-comment-date">17 Sep 2014 at 2:05pm</span></p>
                    <p class="todo-text-color"> So far so good. Not only will the "button" trigger the file input, but it will also acquire the :hover and :active pseudo classes so it behaves like a real button. </p> <!-- Nested media object -->
                                                                                        
                </div>
                </li>
            </ul>
            </div>
        </div>
		
		<div class="comment_area_patient">
            <div class="col-md-12">
            <ul class="media-list">
                <li class="media">
                <a class="pull-left" href="javascript:;">
                <img class="todo-userpic" src="assets/layouts/layout/self-images/avatar6.jpg" width="27px" height="27px"> </a>
                <div class="media-body todo-comment">
                    <button type="button" class="todo-comment-btn btn btn-circle btn-default btn-sm">&nbsp; Reply &nbsp;</button>
                    <p class="todo-comment-head">
                    <span class="todo-comment-username"> Suman Agrwal </span> &nbsp;
                    <span class="todo-comment-date">17 Sep 2014 at 2:05pm</span></p>
                    <p class="todo-text-color"> So far so good. Not only will the "button" trigger the file input, but it will also acquire the :hover and :active pseudo classes so it behaves like a real button. </p> <!-- Nested media object -->
                                                                                        
                </div>
                </li>
            </ul>
            </div>
        </div>
		
		<div class="comment_area_patient">
            <div class="col-md-12">
            <ul class="media-list">
                <li class="media">
                <a class="pull-left" href="javascript:;">
                <img class="todo-userpic" src="assets/layouts/layout/self-images/avatar8.jpg" width="27px" height="27px"> </a>
                <div class="media-body todo-comment">
                    <button type="button" class="todo-comment-btn btn btn-circle btn-default btn-sm">&nbsp; Reply &nbsp;</button>
                    <p class="todo-comment-head">
                    <span class="todo-comment-username"> Pratiksha Patel </span> &nbsp;
                    <span class="todo-comment-date">17 Sep 2014 at 2:05pm</span></p>
                    <p class="todo-text-color"> So far so good. Not only will the "button" trigger the file input, but it will also acquire the :hover and :active pseudo classes so it behaves like a real button. </p> <!-- Nested media object -->
                                                                                        
                </div>
                </li>
            </ul>
            </div>
        </div>
																	
		<div class="comment_area_patient">
        <div class="col-md-12">
        <ul class="media-list">
            <li class="media">
            <a class="pull-left" href="javascript:;">
            <img class="todo-userpic" src="assets/layouts/layout/self-images/avatar7.jpg" width="27px" height="27px"> </a>
            <div class="media-body">
                <textarea class="form-control todo-taskbody-taskdesc" rows="4" placeholder="Type your comment..."></textarea>
            </div>
            </li>
            </ul>
           
        </div>
        </div>
         <div class="comnt_btn_sbmt"><button type="button" class="pull-right btn save-intense"> &nbsp; Submit &nbsp; </button> </div>
    </div>
</div>
