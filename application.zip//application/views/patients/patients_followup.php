<div class="portlet-body allfromgroup-sec followedup_pateint" ng-controller="PatientFollowupController">
    <?php include_once 'patients_info.php'; ?>
    <form name="frmFollowup" id="frmFollowup" class="form-horizontal patient_area_sec_no_bg">           
        <div class="form-body">
            <div class="row">
                <div class="col-md-3">
                    <label class="col-md-4 control-label">Date : </label>
                    <div class="col-md-8"   ng-controller="DatepickerCtrl">                                    
                        <div class="form-group form-md-line-input"> <input type="text" placeholder="Enter date" class="form-control input-inline "  datepicker-popup="{{ format}}" is-open="opened.openedDob" datepicker-options="dateOptions" close-text="Close" ng-model="frm.dob" >
                            <span class="input-group-btn calendar_all_sec">
                                <button type="button" class="btn btn-default" ng-click="open($event, 'openedDob')">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="col-md-4 control-label"> Time : </label>
                    <div class="col-md-8">
                        <div class="form-group form-md-line-input">
									<input id="timepicker4" class="form-control input-inline ng-pristine ng-touched ng-invalid ng-invalid-required" type="text" restrict-paste="" required="" placeholder="00:00 AM" ng-blur="IsAppointmentExist(Appointment); IsValidStrtTimeLimit(Appointment)" ng-focus="appointmentExist = false;
                                                                IsStartTimeValid = false;
                                                                IsEndTimeValid = false;" ng-model="Appointment.StartTime" name="AppointmentStartTime">
																<span class="input-group-btn time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
							</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="col-md-4 control-label"> 
                        Visit :</label> 
                    <div class="col-md-8">
                        <div class="form-group form-md-line-input switch_width_area">									
                            <input type="checkbox" class="make-switch" data-on-text="Follow&nbsp;Up" data-off-text="Visit">
                        </div></div></div>
                <div class="col-md-3 pull-right checkwithdoctrname">
                <div class="text-right"> Suman Agarwal <input type="checkbox" name="sa_status" class="radio_list_chekbox"> </div> 
                    
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 allfromgroup-sec">
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold" data-toggle="collapse"  data-target="#anthropometric_div">Anthropometric</span> 
                            </div>
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body collapse in" id="anthropometric_div"> 
                            <div class="col-md-12 no-space">                        
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in AnthroDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Anthro in value">
                                                <label class="col-md-4 control-label">{{ Anthro.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="text" class="form-control" name="{{ Anthro.Name}}" id="{{ Anthro.Name}}"></div>   
                                                </div></div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>                         
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="height-20"></div>               
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold"  data-toggle="collapse"  data-target="#diet_recall_div">Diet Recall</span>  
                            </div> 
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>							
                        </div>
                        <div class="portlet-body collapse in" id="diet_recall_div">   
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in DietDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Diet in value">
                                                <label class="col-md-4 control-label">{{ Diet.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="text" class="form-control" name="{{ Diet.Name}}" id="{{ Diet.Name}}"></div>   
                                                </div>  </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="height-20"></div>
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold"  data-toggle="collapse" data-target="#lab_tests_div">Lab tests</span>                            
                            </div>     
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>							
                        </div>
                        <div class="portlet-body collapse in" id="lab_tests_div">  
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true">
                                    <div class="row">    
                                        <div class="col-sm-6"> 
                                            <label class="col-md-4 control-label">Lab Name</label>
                                            <div class="col-md-8">
                                                <div class="form-group form-md-line-input">
                                                    <select class="bs-select form-control">
                                                        <option selected="selected">Select Lab </option>
                                                        <option value="">Lab1</option>
                                                        <option value="">Lab2</option>
                                                        <option value="">Lab3</option>                                                        
                                                    </select> 
                                                </div>   
                                            </div>   
                                        </div>
                                    </div>
                                    <uib-accordion-group ng-repeat="(key, value) in LabtestDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Lab in value">
                                                <label class="col-md-4 control-label">{{ Lab.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="text" class="form-control" name="{{ Lab.Name}}" id="{{ Lab.Name}}"></div>   </div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                        </div>
                    </div>
                </div>    
				
				 <div class="col-md-12">
                    <div class="height-20"></div>
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold"  data-toggle="collapse" data-target="#genetic_tests_div"> Genetic Test</span>                            
                            </div>     
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>							
                        </div>
                        <div class="portlet-body collapse in" id="genetic_tests_div">  
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true">
                                    <div class="row">    
                                        <div class="col-sm-6"> 
                                            <label class="col-md-4 control-label">Lab Name</label>
                                            <div class="col-md-8">
                                                <div class="form-group form-md-line-input">
                                                    <select class="bs-select form-control">
                                                        <option selected="selected">Select Lab </option>
                                                        <option value="">Lab1</option>
                                                        <option value="">Lab2</option>
                                                        <option value="">Lab3</option>                                                        
                                                    </select> 
                                                </div>   
                                            </div>   
                                        </div>
                                    </div>
                                    <uib-accordion-group ng-repeat="(key, value) in GenetictestDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Lab in value">
                                                <label class="col-md-4 control-label">{{ Lab.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="text" class="form-control" name="{{ Lab.Name}}" id="{{ Lab.Name}}"></div>   </div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                        </div>
                    </div>
                </div>  
                <div class="col-md-12">
                    <div class="height-20"></div>
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold" data-toggle="collapse" data-target="#exercise_div">Exercise</span>                            
                            </div>     
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body collapse in" id="exercise_div">     
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in ExerciseDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Exercise in value">
                                                <label class="col-md-4 control-label">{{ Exercise.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="text" class="form-control" name="{{ Exercise.Name}}" id="{{ Exercise.Name}}"></div></div>
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                        </div>
                    </div> 
                </div>                                 
                <div class="col-md-12">
                    <div class="portlet box green margin-15-panel">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold" data-toggle="collapse"  data-target="#medication_div">Medication</span>                            
                            </div>          
                            <div class="tools">
                                <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div> 
                        <div class="portlet-body collapse in" id="medication_div pateint_meditaion_area">     
                            <div class="tabbable-line">
                                 <ul class="nav nav-tabs">                                   
                                    <li class="active"><a data-target="#tab_normal" data-toggle="tab" aria-expanded="true"> Outside Medication </a></li>
                                    <li><a data-target="#tab_selfcare" data-toggle="tab" aria-expanded="true">Selfcare Medication</a></li>
                                </ul>
                                <div class="tab-content">                                                                                              
                                    <div class="tab-pane active" id="tab_normal">                                                           
                                        <div class="portlet-body">
                                            <!--------<div class="col-md-12">                                                
                                                <div class="col-md-4">Name</div>
                                                <div class="col-md-4">Dosage</div>
                                                <div class="col-md-4">Remarks</div>                                                
                                            </div>-------------->                                            
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Name </span>
                                                <div class="form-group form-md-line-input">
                                                    <input type="text" class="form-control">
											</div>
											</div>
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Dosage </span>
                                                <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1">
                                            </div>     
											</div>								
                                            <div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Remark </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div>  
											</div>  
																					
                                        </div>
                                    </div>   
                                    <div class="tab-pane" id="tab_selfcare">  
                                        <div class="portlet-body">
                                            <!-----------<div class="col-md-12">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-1">Name</div>
                                                <div class="col-md-3">Dosage</div>
                                                <div class="col-md-3">Remarks</div>
                                                <div class="col-md-3">Reminder in</div>
                                            </div>--------------->
                                            <div class="col-md-4 no-space">
											<div class="col-md-6 labletext_medi">
												<span class="labletext_medi">Select  </span>
                                                <div class="form-group form-md-line-input">
                                                <select class="bs-select form-control">
                                                    <option value="">Select</option>
                                                    <option>Multi Vitamins</option>
                                                    <option>Vitamins</option>                            
                                                </select>
                                            </div>
											</div>
											<div class="col-md-6 labletext_medi">
											<span class="labletext_medi">Name </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div> </div>
											</div>
											<div class="col-md-8">
											<div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Dosage </span>
                                                <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control dosage_mask"  size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1"> <span class="minus_symbol"> - </span>
                                                <input type="text" class="form-control dosage_mask" size="1">
                                            </div></div>
											<div class="col-md-4 labletext_medi all_radio_followed">
											<span class="labletext_medi"> </span>
                                                <div class="form-group form-md-line-input">
                                                 <input type="radio" class="form-control"   size="1"> <span class="radio_text_folloed">Yes  </span>
                                                <input type="radio" class="form-control" size="1"> <span class="radio_text_folloed"> No </span>
                                               
                                            </div></div>
											<div class="col-md-4 labletext_medi">
											<span class="labletext_medi">Remark </span>
                                                <div class="form-group form-md-line-input">
											<input type="text" class="form-control">
											</div>  
											</div> 
											</div>  
                                                                                       
										
                                        </div>
                                    </div> 
                                    </div>  

                                </div>                                                                                             
                            </div>                                            
                        </div>  

												
												<div class="col-md-12">
                        <div class="col-md-6 no-space">
                            <label class="col-md-8 control-label"> Review Require <input type="checkbox" ng-model="review_require" class="radio_list_chekbox">  </label>
                            <div class="col-md-4"> 
                            </div>
                        </div>

                        <div class="col-md-6" ng-show="review_require"> 
                            <label class="col-md-4 control-label followedup_last_div" style="margin-top: 0px !important"> Review by </label>
                            <div class="col-md-8"> 
                                <select class="bs-select form-control" style="max-width: 90%;border: 1px solid #959595;">
                                    <option value="">Select</option>
                                    <option value="Shwetal">Shwetal</option>
                                    <option value="Simran">Simran</option>                            
                                </select>
                            </div>
                        </div>						
                    </div>                    
                </div>                           
                
               
                <div class="col-md-12 margin_top_bottom_brn">        
					<div class="all_patient_action">
                    <button type="submit" class="btn save-intense">Save Only</button>
                    <button type="button" class="btn save-intense">Save and Email</button>                  
                </div>
				</div>
            </div>           
        </div>        
    </form>
</div>

<script type="text/javascript">
    App.initAjax(); // do not delete    
</script>