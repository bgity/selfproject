<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active" id="tab_1_1">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area allfromgroup-sec">
                            <form class="form-horizontal" valid-submit="patientAdd()" name="frmPatient" novalidate>                
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption" data-toggle="collapse"  data-target="#personal_div">
                             Personal Information </div>                        
                    </div>
                    <div class="portlet-body form  padding-left-right  collapse in" id="personal_div"> 

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group required">
                                        <label class="col-md-4 control-label">Name</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">     
											<input type="text" class="form-control" placeholder="Enter your name" name="patient_name" id="patient_name" required ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Date Of Birth</label>                                     
                                         <div class="col-md-8"  ng-controller="DatepickerCtrl">
										<div class="form-group form-md-line-input">
                                            <input type="text" placeholder="Date of Birth" class="form-control input-inline"  datepicker-popup="{{ format}}" is-open="opened.openedDob" datepicker-options="dateOptions" close-text="Close" ng-model="frm.dob" >
                                            <span class="input-group-btn calendar_all_sec">
                                                <button type="button" class="btn btn-default" ng-click="open($event, 'openedDob')">
                                                    <i class="glyphicon glyphicon-calendar"></i>
                                                </button>
											
                                            </span>      
										</div>											
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Meal Type</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <select class="bs-select form-control" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                <option value="">Select Type </option>
                                                <option ng-repeat="meal in mealList" value="meal.value">{{ meal.text}}</option>
                                            </select> 
                                        </div>
										</div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Referred By</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter Referred By">
                                            </div>
                                          
                                        </div>
                                    </div>  
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Occupation</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your Occupation">
                                            </div>
                                          
                                        </div>
                                    </div>     

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Designation</label>
                                        <div class="col-md-8">
                                          
											<div class="form-group  form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your Designantion">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>    
                                    <div class="form-group required">
                                        <label class="col-md-4 control-label">Gender</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="male"  value="male" checked ng-model="frm.gender"> Male </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="female"  value="female" ng-model="frm.gender"> Female </label>
                                            </div>
											</div>
                                        </div>                                        
                                    </div>     
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Martial Status</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="martial_status" id="single" value="single" checked ng-model="frm.martial_status"> Single </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="martial_status" id="married" value="married" ng-model="frm.martial_status"> Married </label>
                                            </div>
											</div>
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Age</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your age">
                                                
                                            </div>
                                          
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Date of joining</label>
                                        <div class="col-md-8"  ng-controller="DatepickerCtrl">
										<div class="form-group form-md-line-input">
                                            <input type="text" placeholder="Date of joining" class="form-control input-inline"  datepicker-popup="{{ format}}" is-open="opened.openedStart" datepicker-options="dateOptions" close-text="Close" ng-model="frm.date_of_joining" >
                                            <span class="input-group-btn calendar_all_sec">
                                                <button type="button" class="btn btn-default" ng-click="open($event, 'openedStart')">
                                                    <i class="glyphicon glyphicon-calendar"></i>
                                                </button>
                                            </span>   
											</div>											
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>                       

                    </div>
                </div>
            </div>
            <!-- personal info ends-->
            <!-- Official info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption" data-toggle="collapse"  data-target="#official_div">
                            Official Information</div>                        
                    </div>
                    <div class="portlet-body form padding-left-right collapse in" id="official_div">

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Program</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <select class="bs-select form-control" name="program_type" id="program_type" ng-model="frm.program_type">
                                                <option value="">Select Program </option>
                                                <option ng-repeat="program in programList" value="program.value">{{ program.text}}</option>
                                            </select> 
                                        </div>
										</div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Nutritionist</label>
                                        <div class="col-md-8"> 
												<div class="form-group form-md-line-input">
                                            <select class="bs-select form-control" name="nutritionist" id="nutritionist" ng-model="frm.nutritionist">
                                                <option value="">Select Nutritionist </option>
                                                <option ng-repeat="nutritionist in nutritionistList" value="nutritionist.value">{{ nutritionist.text}}</option>
                                            </select> 
                                        </div>
										</div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Branch</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <select class="bs-select form-control" name="branch" id="branch" ng-model="frm.branch">
                                                <option value="">Select Branch </option>
                                                <option ng-repeat="branch in branchList" value="branch.value">{{ branch.text}}</option>
                                            </select>
											</div>											
                                        </div>
                                    </div>                                 
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">File No</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your File no.">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>  
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Some text</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your some text">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>     

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Username</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" placeholder="Enter your User name">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>    
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Password</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="password" class="form-control" id="form_control_1" placeholder="Enter your Password" name="password" ng-model="frm.password">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>   
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Confirm Password</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="password" class="form-control" id="form_control_1"  name="password" ng-model="frm.password" placeholder="Enter your Confirm Password">
                                                
                                            </div>
                                          
                                        </div>
                                    </div> 
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Status</label>
                                        <div class="col-md-8"> 
										<div class="form-group form-md-line-input">
										<input type="checkbox" class="make-switch" checked data-on-text="Active" data-off-text="Inactive" name="status" ng-model="frm.status"> 										
                                        </div>
										</div>
                                    </div>                                     
                                </div>
                            </div>
                        </div>                  
                    </div>
                </div>
            </div>
            <!-- Official info ends-->       
            <!-- contact info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption" data-toggle="collapse"  data-target="#contact_div">
                            Contact Information</div>                        
                    </div>
                    <div class="portlet-body form  padding-left-right collapse in" id="contact_div">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Address</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <textarea class="form-control text_area_section" rows="3" placeholder="Enter your Address"></textarea>
                                        </div>
										</div>
                                    </div>       
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Country</label>
                                        <div class="col-md-8">  
										<div class="form-group form-md-line-input">
											<form role="form">
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="country" ng-model="frm.country" placeholder="Enter your Country name">
                                            </div>
                                          		</div>								
                                            
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">State</label>
                                        <div class="col-md-8">                                           
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="state" ng-model="frm.state" placeholder="Enter your State name">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">City</label>
                                        <div class="col-md-8">                                           
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="city" ng-model="frm.city" placeholder="Enter your City name">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Pincode</label>
                                        <div class="col-md-8">                                           
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="pincode" ng-model="frm.pincode" placeholder="Enter your Pin code">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>                                                                        
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Email 1</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="email" ng-model="frm.email" placeholder="Enter your Email">
                                               
                                            </div>
                                          
                                        </div>
                                    </div>       
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Email 2</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="email2" ng-model="frm.email2" placeholder="Enter your Email 2">
                                              
                                            </div>
                                          
                                        </div>
                                    </div>     
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Mobile 1</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="mobile1" ng-model="frm.mobile1" placeholder="Enter your Mobile 1">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>    
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Mobile 2</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="mobile2" ng-model="frm.mobile2" placeholder="Enter your Mobile 2">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>   
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Home Phone</label>
                                        <div class="col-md-8">
                                           <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="homephone" ng-model="frm.homephone" placeholder="Enter your Home Phone no.">
                                                
                                            </div>
                                          
                                        </div>
                                    </div>                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- contact info ends-->
            <!-- social info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption" data-toggle="collapse"  data-target="#social_div">
                            Social Information</div>                        
                    </div>
                    <div class="portlet-body form">
                        <div class="form-body padding-left-right collapse in" id="social_div">
                            <div class="row">
                                <div class="col-md-6">                                    
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Facebook</label>
                                        <div class="col-md-8">                                           
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="facebook" ng-model="frm.facebook" placeholder="Enter your Facebook id">
                                                <!---<span class="help-block">Enter your name here...</span>-->
                                            </div>
                                          
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Twitter</label>
                                        <div class="col-md-8">                                           
                                          
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="twitter" ng-model="frm.twitter" placeholder="Enter your Twitter">
                                                <!---<span class="help-block">Enter your name here...</span>-->
                                            </div>
                                          
                                        </div>
                                    </div>                                                                                                          
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">LinkedIn</label>
                                        <div class="col-md-8">
										<form role="form">
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="linkedin" ng-model="frm.linkedin" placeholder="Enter your Linkedin">
                                                <!---<span class="help-block">Enter your name here...</span>-->
                                            </div>
                                          
                                            
                                        </div>
                                    </div>       
                                    <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Skype</label>
                                        <div class="col-md-8">
                                           
											<div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" id="form_control_1" name="skype" ng-model="frm.skype" placeholder="Enter your Skype">                                                
                                                <!---<span class="help-block">Enter your name here...</span>-->
                                            </div>                                          
                                        </div>
                                    </div>                                                                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- contact info ends--> 
            <div class="col-md-12">
                <div class="form-actions all_patient_action">                            
                    <button type="submit" class="btn save-intense">Save</button>                          
                    <a href="patients.html"class="btn cancel-intense">Cancel</a>
                </div>
            </div>
            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div></div>
