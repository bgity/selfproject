
    <div class="col-md-12 portlet light bordered allpoup_patient_area"> 
        <div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Exercise</span></div>
		<div class="actions"><a ng-click="Cancel()" class="btn btn-icon-only btn-default"><i class="fa fa-edit"></i></a></div>
        </div>
        <div class="portlet-body">                                        
            <div class="flip-scroll">
			<div class="scroller" style="height: 260px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                <table class="table table-striped table-condensed">
                    <thead class="flip-content thead-default">
                        <tr>
                            <th> Visit </th>
                            <th> Date  </th>
                            <th> Exercise 1  </th>
                            <th> Duration </th>
                            <th> Frequency </th>
                            <th> Exercise 2  </th>
                            <th> Duration </th>
                            <th> Frequency </th>
                            <th> Exercise 3  </th>
                            <th> Duration </th>
                            <th> Frequency </th>                        
                            <th> Remarks </th>
                        </tr>                    </thead>
                    <tbody>
                        <tr>
                            <td> 001 </td>
                            <td> 02/04/2016  </td>
                            <td> Walking </td>
                            <td> 45 Mins </td>
                            <td> 5 times/Wk </td>
                            <td> Cycling </td>
                            <td> 15 </td>
                            <td> 5 times/Wk </td>
                            <td> Running </td>
                            <td> 10 </td>
                            <td> 3 times/Wk </td>                            
                            <td> Not done </td>                                                   
                        </tr>              
                        <tr>
                            <td> 002 </td>
                            <td> 02/04/2016  </td>
                            <td> Walking </td>
                            <td> 45 Mins </td>
                            <td> 5 times/Wk </td>
                            <td> Cycling </td>
                            <td> 15 </td>
                            <td> 5 times/Wk </td>
                            <td> Running </td>
                            <td> 10 </td>
                            <td> 3 times/Wk </td>                            
                            <td> Not done </td>                                                   
                        </tr>              
                        <tr>
                            <td> 003 </td>
                            <td> 02/04/2016  </td>
                            <td> Walking </td>
                            <td> 45 Mins </td>
                            <td> 5 times/Wk </td>
                            <td> Cycling </td>
                            <td> 15 </td>
                            <td> 5 times/Wk </td>
                            <td> Running </td>
                            <td> 10 </td>
                            <td> 3 times/Wk </td>                            
                            <td> Not done </td>                                                   
                        </tr>              
                    </tbody>
                </table>
            </div> 
			</div> 			
        </div>
         <div class="modal-footer">                                    
                                    <button class="btn cancel-intense" ng-click="cancel()">Close</button>
                                </div>
    </div>  
