
    <div class="col-md-12 portlet light bordered allpoup_patient_area"> 
        <div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Medication</span></div>
		<div class="actions"><a ng-click="Cancel()" class="btn btn-icon-only btn-default"><i class="fa fa-edit"></i></a></div>
        </div>
        <div class="portlet-body">                                        
            <div class="flip-scroll">
			<div class="scroller" style="height: auto;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                <table class="table table-striped table-condensed">
                    <thead class="flip-content thead-default">
                        <tr>
                            <th> Visit </th>
                            <th> Date  </th>
                            <th> Medication  </th>
                            <th> Name </th>
                            <th> Dosage </th>
                            <th> Prescribed By  </th>
                            <th> Remarks </th>                               
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td> 001 </td>
                            <td> 02/04/2016  </td>
                            <td> Tablet </td>
                            <td> Crocin </td>
                            <td> 0-0-1 </td>
                            <td> Shenoy </td>
                            <td> 1 time </td>                                                                       
                        </tr>              
                        <tr>
                            <td>  </td>
                            <td>  </td>
                            <td> Tablet </td>
                            <td> Crocin </td>
                            <td> 1-0-1 </td>
                            <td> Shenoy </td>
                            <td> 1 time </td>                                                                       
                        </tr>              
                        <tr>
                            <td>  </td>
                            <td>  </td>
                            <td> Tablet </td>
                            <td> Crocin </td>
                            <td> 1-0-1 </td>
                            <td> Shenoy </td>
                            <td> 1 time </td>                                                                       
                        </tr>              
                        <tr>
                            <td> 002 </td>
                            <td> 02/04/2016  </td>
                            <td> Multi Vitamins </td>
                            <td> ABC </td>
                            <td> 0-0-1 </td>
                            <td> Shwetal </td>
                            <td> 1 month </td>                                                                       
                        </tr>                                     
                        <tr>
                            <td>  </td>
                            <td>  </td>
                            <td> Vitamin C </td>
                            <td> Ester C </td>
                            <td> 1-0-1 </td>
                            <td> Shwetal </td>
                            <td> 1 month </td>                                                                       
                        </tr>                                                  
                    </tbody>
                </table>
            </div> 
			</div> 			
        </div>
         <div class="modal-footer">                                    
                                    <button class="btn cancel-intense" ng-click="cancel()">Close</button>
                                </div>
    </div>  
