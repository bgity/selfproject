
    <div class="col-md-12 portlet light bordered allpoup_patient_area"> 
        <div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Lab Tests</span></div>
		<div class="actions"><a ng-click="Cancel()" class="btn btn-icon-only btn-default"><i class="fa fa-edit"></i></a></div>
        </div>
        <div class="portlet-body">                                        
            <div class="flip-scroll">
			<div class="scroller" style="height: auto;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                <table class="table table-striped table-condensed">
                    <thead class="flip-content thead-default">
                        <tr>
                            <th> Visit </th>
                            <th> Date  </th>
                            <th> Test1(Range) </th>
                            <th> Test2(Range) </th>
                            <th> Test3(Range) </th>                                                                     
                            <th> Remarks </th>
                        </tr>                   
                    </thead>
                    <tbody>
                        <tr>
                            <td> 001 </td>
                            <td> 02/04/2016  </td>
                            <td> 29(23-45) </td>
                            <td> 2.2 (2-4) </td>
                            <td> 4.1 (5-6) </td>
                            <td>  </td>                                                                         
                        </tr>              
                       <tr>
                            <td> 002 </td>
                            <td> 02/04/2016  </td>
                            <td> 35(23-45) </td>
                            <td> 3 (2-4) </td>
                            <td> 4.5 (5-6) </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td> 003 </td>
                            <td> 02/04/2016  </td>
                            <td> 32(23-45) </td>
                            <td> 3.1 (2-4) </td>
                            <td> 5(5-6) </td>
                            <td>  </td>                                                                         
                        </tr>                                                                                  
                    </tbody>
                </table>
            </div> 
			</div> 			
        </div>
         <div class="modal-footer"><button class="btn cancel-intense" ng-click="cancel()">Close</button></div>
    </div>  
