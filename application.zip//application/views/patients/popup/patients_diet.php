
    <div class="col-md-12 portlet light bordered allpoup_patient_area"> 
        <div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Diet</span></div>
		<div class="actions"><a ng-click="Cancel()" class="btn btn-icon-only btn-default"><i class="fa fa-edit"></i></a></div>
        </div>
        <div class="portlet-body">                                        
            <div class="flip-scroll">
			<div class="scroller" style="height: auto;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                <table class="table table-striped table-condensed">
                    <thead class="flip-content thead-default">
                        <tr>
                            <th> Visit </th>
                            <th> Date  </th>
                            <th> Time  </th>
                            <th> Meal </th>
                            <th> Option </th>                                               
                            <th> Remarks </th>
                        </tr>                   
                    </thead>
                    <tbody>
                        <tr>
                            <td> 001 </td>
                            <td> 02/04/2016  </td>
                            <td> 9am </td>
                            <td> Breakfast B </td>
                            <td> Bread/Idli </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td>  </td>
                            <td>  </td>
                            <td> 11am </td>
                            <td> Breakfast p </td>
                            <td> Eggs </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td> </td>
                            <td>  </td>
                            <td> 1pm </td>
                            <td> Lunch </td>
                            <td> 2 Roti and Sabji </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td> 002 </td>
                            <td> 10/04/2016  </td>
                            <td> 9am </td>
                            <td> Breakfast B </td>
                            <td> Bread/Idli </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td>  </td>
                            <td>  </td>
                            <td> 11am </td>
                            <td> Breakfast p </td>
                            <td> Eggs </td>
                            <td>  </td>                                                                         
                        </tr>              
                        <tr>
                            <td> </td>
                            <td>  </td>
                            <td> 1pm </td>
                            <td> Lunch </td>
                            <td> 2 Roti and Sabji </td>
                            <td>  </td>                                                                         
                        </tr>              
                    </tbody>
                </table>
            </div> 
			</div> 			
        </div>
         <div class="modal-footer"><button class="btn cancel-intense" ng-click="cancel()">Close</button></div>
    </div>  
