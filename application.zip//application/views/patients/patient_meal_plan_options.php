<div class="row" ng-controller="DietController">
	<div class="col-md-12">
		<div class="portlet box">
			<div class="portlet-title">
			<div class="caption bottom_bolow_meal_plan">
				<a class="btn noraml_meal_btn_sec" ng-class="{'red':selectedTab === 'client'}" ng-click="selectedTemplate.path = 'diet/clientDetails'; selectedTab='client';">Client Details</a>
				<a class="btn noraml_meal_btn_sec" ng-class="{'red':selectedTab === 'intake'}" ng-click="selectedTemplate.path = 'diet/intakeAllocation';selectedTab='intake';">Intake Allocation</a>
				<a class="btn noraml_meal_btn_sec" ng-class="{'red':selectedTab === 'plan'}" ng-click="selectedTemplate.path = 'diet/createPlans';selectedTab='plan';">Create Plans</a>
			</div>
			<div class="actions">
                    
			<a class="btn save-intense" ng-click="addClient();" style="color: #fff;">Add Existing Client</a>
                    
                </div>
				</div>
			<div class="portlet-body form" style="background-color: transparent;">
				<form id="dietform" name="dietform" ng-submit="processForm()">
					<div class="form-wizard">
						<div class="form-body meal_plan_area_all_first">
							<div ng-include="selectedTemplate.path"></div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
