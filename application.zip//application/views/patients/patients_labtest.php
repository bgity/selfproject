   <div class="col-md-12">
    <form class="form-horizontal patient_area_sec_no_bg"> 
                    <div class="height-20"></div>
                    <div class="green margin-15-panel">
                        <div class="portlet-body collapse in" id="lab_tests_div">  
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true">                                    
                                    <uib-accordion-group ng-repeat="(key, value) in LabtestDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Lab in value">
                                                <label class="col-md-4 control-label">{{ Lab.Name}}</label>
                                                <div class="col-md-8">
                                                    <div class="form-group form-md-line-input">
                                                        <input type="checkbox" class="form-control" name="{{ Lab.Name}}" id="{{ Lab.Name}}"></div>   </div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
							<div class="col-md-12">
							<div class="all_patient_action">
											<button class="btn save-intense" ng-click="sav_task()">Save</button>											
											</div>
											</div>
                        </div>
                    </div>
                    </form>
                </div> 