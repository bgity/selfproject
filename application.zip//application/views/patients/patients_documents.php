<div class="portlet-body">   
    <div class="table-responsive">
        <table class="table table-bordered table-advance programtab_details">
            <thead>
            <th style="background: #FFECE8 !important;">Date</th>
            <th style="background: #FFECE8 !important;">Name</th>
            <th style="background: #FFECE8 !important;">Nutritionist</th>
            <th style="background: #FFECE8 !important;">Action</th>            
            </thead>
            <tbody>                
                <tr>
                    <td>  09/03/2016 </td>
                    <td> Sheetal </td>
                    <td>Guidelines</td>
                    <td> <a><img src="assets/layouts/layout/self-images/pdf_file.png" class="left_text_self_icon"></a> </td>
                </tr>
                <tr>
                    <td>  29/03/2016 </td>
                    <td> Neha </td>
                    <td>Excel </td>
                    <td><a> <img src="assets/layouts/layout/self-images/pdf_file.png" class="left_text_self_icon"></a> </td>
                </tr>
                <tr>
                    <td>  09/03/2016 </td>
                    <td> Sheetal </td>
                    <td>Guidelines</td>
                    <td> <a><img src="assets/layouts/layout/self-images/pdf_file.png" class="left_text_self_icon"> </a></td>
                </tr>
                <tr>
                    <td>  19/03/2016 </td>
                    <td> Neha </td>
                    <td>Excel</td>
                    <td> <a><img src="assets/layouts/layout/self-images/pdf_file.png" class="left_text_self_icon"></a></td>
               </tr>
			   <tr>
                    <td>   Choose File for Upload </td>
                    <td> <input type="file"  class="btn-default"> </td>
                    <td> &nbsp; </td>
                    <td> &nbsp; </td>
               </tr>
            </tbody>
        </table>
        
        
    </div>
</div>
