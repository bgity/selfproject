
<!--- Started work on profile view ------>
<div class="patient_profile_details">
<div class="profile">
                        <div class="tabbable-line tabbable-full-width">
                            
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_1_1">
                                    <div class="row">
                                        <div class="col-md-2 no-space">
                                            <ul class="list-unstyled profile-nav profile-list">
                                                <li>
                                                    <img src="assets/layouts/layout/self-images/profile_picture.png" class="" alt="">
                                                    <a href="javascript:;" class="profile-edit"> </a>
                                                </li>
												<li class="star_images">
                                                    <a href="javascript:;"> Patient Dashboard </a>
                                                </li>
												<li class="patient_name_dash">
                                                    <a href="javascript:;"> <img src="assets/layouts/layout/self-images/agenda.png"> Jane Doe </a>
                                                </li>
                                                <li class="active">
                                                    <a href="javascript:;"> Patient Dashboard </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Patient Information
                                                       
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Medical History </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Program </a>
                                                </li>
												<li>
                                                    <a href="javascript:;"> Payment </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-10 no-space right_patient_text_area">
                                            <div class="row">
                                                <div class="col-md-8 profile-info">
                                                    <div class="portlet-body">
													<div class="row"> 
													<div class="col-md-4"> 
													<table class="table table-condensed">
                                                                
                                                                <tbody>
                                                                    <tr>
                                                                        <td>File No</td>
                                                                        <td> 1145 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Branch</td>
                                                                        <td> Tardev </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td>Program </td>
                                                                        <td>Platinum</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Age </td>
                                                                        <td> 40 Years </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Sex </td>
                                                                        <td> Male </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td> Height </td>
                                                                        <td>5.1f</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
													</div>
													<div class="col-md-5 no-space"> 
													<table class="table table-condensed ">
                                                                
                                                                <tbody>
                                                                    <tr>
                                                                        <td> Occupation </td>
                                                                        <td> Software </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Mobile</td>
                                                                        <td> 8080049990 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td>E-mial </td>
                                                                        <td>manoj.upadhyay@appetals.com</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    
																	<tr>
                                                                        <td>Country</td>
                                                                        <td> India </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Out Standing</td>
                                                                        <td> 15000 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td> Status </td>
                                                                        <td> Active </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	
                                                                </tbody>
                                                            </table>
													</div>
													<div class="col-md-3 no-space"> 
													<table class="table table-condensed ">
                                                                
                                                                <tbody>
                                                                    <tr>
                                                                        <td> Nutritionist </td>
                                                                        <td> 1254 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Meal Pref:</td>
                                                                        <td> Vegitarian </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td>Pregnancy </td>
                                                                        <td>no</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Cool Sculpt </td>
                                                                        <td> Yes </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Referal </td>
                                                                        <td> 6 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td> Visits Left </td>
                                                                        <td> 12 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
													</div>
													</div>
									
                                </div>
                                                </div>
                                                <!--end col-md-8-->
                                                <div class="col-md-4">
                                                    <div class="portlet sale-summary">
                                                        <div class="portlet-title">
                                                            <div class="caption font-red sbold"> Sales Summary </div>
                                                            <div class="tools">
                                                                <a class="reload" href="javascript:;" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <!--end col-md-4-->
                                            </div>
                                            <!--end row-->
                                            <div class="tabbable-line tabbable-custom-profile">
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a href="#tab_1_11" data-toggle="tab" aria-expanded="true"> Snapshot </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="#tab_1_22" data-toggle="tab" aria-expanded="true"> Follow Up </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_33" data-toggle="tab" aria-expanded="true"> Meal Plans </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_44" data-toggle="tab" aria-expanded="true"> Documents </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_55" data-toggle="tab" aria-expanded="true"> Comments </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_66" data-toggle="tab" aria-expanded="true"> Message History </a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_1_11">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <!--tab-pane-->
                                                    <div class="tab-pane" id="tab_1_22">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello cfgd
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													<div class="tab-pane" id="tab_1_33">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 33
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													<div class="tab-pane" id="tab_1_44">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 44
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													<div class="tab-pane" id="tab_1_55">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 55
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													<div class="tab-pane" id="tab_1_66">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 66
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													
													
													
                                                        </div>
                                                    </div>
                                                    <!--tab-pane-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
</div>


<!------ Started work on profile view ---------->