<div class="portlet-body">
   <?php include_once 'patients_info.php'; ?>
    <div class="table-responsive">
        <table class="table snapshort_table" cellpadding="0" cellspacing="1" width="100%">
            <tbody>
                <tr>
                    <td class="padding-left-15">09/04/2016</td>
                    <td> Sheetal </td>
                    <td> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropometric </button> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_diet')"> DietRecall </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_exercise')"> Exercise </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_medication')"> Medication </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_lab_tests')"> Lab Tests </button>
                    </td>
                    <td> <span popover="1:00pm - 1.15pm" popover-trigger="mouseenter">15:00 mins</span> </td>
                </tr>
                <tr>
                    <td class="padding-left-15">  19/04/2016 </td>
                    <td> Sheetal </td>
                    <td> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropometric </button> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_diet')"> DietRecall </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_exercise')"> Exercise </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_medication')"> Medication </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_lab_tests')"> Lab Tests </button>
                    </td>
                    <td> <span popover="2:00pm - 2.15pm" popover-trigger="mouseenter">15:00 mins</span> </td>
                </tr>
                <tr>
                    <td class="padding-left-15">  29/04/2016 </td>
                    <td> Sheetal </td>
                    <td>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropometric </button> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_diet')"> DietRecall </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_exercise')"> Exercise </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_medication')"> Medication </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_lab_tests')"> Lab Tests </button>    
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_lab_tests')"> Genetic Test </button>    
                    </td>
                    <td> <span popover="1:00pm - 1.45pm" popover-trigger="mouseenter">45:00 mins</span> </td>
                </tr>
                <tr>
                    <td class="padding-left-15">  04/05/2016 </td>
                    <td> Sheetal </td>
                    <td>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropometric </button> 
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_diet')"> DietRecall </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_exercise')"> Exercise </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_medication')"> Medication </button>
                    <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_lab_tests')"> Lab Tests </button>    
                    </td>
                    <td> <span popover="2:00pm - 2.15pm" popover-trigger="mouseenter">15:00 mins</span> </td>
 
               </tr>
            </tbody>
        </table>
    </div>
</div>
