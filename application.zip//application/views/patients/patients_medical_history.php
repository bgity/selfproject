<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active" id="tab_1_1">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">

                            <div class="row main-height_detail_pat">
                                <?php include_once 'patients_top.php'; ?>                                
                            </div>
                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a data-target="#tab_questionnaire" data-toggle="tab" aria-expanded="true"> Questionnaire </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#tab_diseases" data-toggle="tab" aria-expanded="true">Diseases </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#tab_diagnosis" data-toggle="tab" aria-expanded="true">Diagnosis</a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab_questionnaire">
                                        <div class=" allfromgroup-sec">
                                            <div class="row">
                                                <form class="form-horizontal" valid-submit="patientMedicalHistoryAdd()" novalidate name="frmMedical">

                                                    <!-- Default List-->
                                                    <div class="col-md-12">
                                                        <div class="portlet light bordered">
                                                            <div class="portlet-title">
                                                                <div class="caption" data-toggle="collapse" data-target="#default_list_div">
                                                                    Default List </div>

                                                            </div>
                                                            <div class="portlet-body form  padding-left-right collapse in" id="default_list_div">

                                                                <div class="form-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6 right_border_self">
                                                                            <div class="form-group required">
                                                                                <label class="col-md-4 control-label">Blood Group</label>
                                                                                <div class="col-md-8">     
                                                                                    <select class="bs-select form-control" required name="bloodGroup" id="bloodGroup" ng-model="frm.bloodGroup">
                                                                                        <option value="">Select Type </option>
                                                                                        <option ng-repeat="blood in bloodGroupList" value="{{ blood.value}}">{{ blood.text}}</option>
                                                                                    </select> 
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Paternal Medical History</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Paternal Medical History"  class="form-control input-inline input-large" ng-model="frm.paternal_history" name="paternal_history" id="paternal_history">  </div>                            
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Maternal Medical History</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Maternal Medical History"  class="form-control input-inline input-large" ng-model="frm.maternal_history" name="maternal_history" id="maternal_history">  </div>      
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Weight History</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Weight History"  class="form-control input-inline input-large"  ng-model="frm.weight_history" name="weight_history" id="weight_history">
                                                                                    </div>

                                                                                </div>
                                                                            </div>  
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Name of Gynaec</label>
                                                                                <div class="col-md-8">

                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Name of GP" class="form-control input-inline input-large"  ng-model="frm.name_of_gp" name="name_of_gp" id="name_of_gp">
                                                                                    </div>

                                                                                </div>
                                                                            </div>     
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Are you doing Kapalbharti</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Are you doing Kapalbharti" class="form-control input-inline input-large"  ng-model="frm.kapalbharti" name="kapalbharti" id="kapalbharti">
                                                                                    </div>                             
                                                                                </div>
                                                                            </div> 
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Hospitalization History</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group  form-md-line-input">
                                                                                        <input type="text" placeholder="Hospitalization History" class="form-control input-inline input-large"  ng-model="frm.hospitalization_history" name="hospitalization_history" id="hospitalization_history">
                                                                                    </div>

                                                                                </div>
                                                                            </div>    
                                                                            <div class="form-group required">
                                                                                <label class="col-md-4 control-label">Date of Hospitalization</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group  form-md-line-input">
                                                                                        <input type="text" placeholder="Date of Hospitalization" class="form-control input-inline input-large"  ng-model="frm.date_of_hospitalization" name="date_of_hospitalization" id="date_of_hospitalization">
                                                                                    </div>
                                                                                </div>                                        
                                                                            </div>     
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Drinks per week</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group  form-md-line-input">
                                                                                        <input type="text" placeholder="Drinks per week" class="form-control input-inline input-large"  ng-model="frm.drinks_per_week" name="drinks_per_week" id="drinks_per_week">
                                                                                    </div>
                                                                                </div>
                                                                            </div> 
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Obstetric History</label>
                                                                                <div class="col-md-8">

                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Obstetric History" class="form-control"  ng-model="frm.obstetric_history" name="obstetric_history" id="obstetric_history">
                                                                                    </div>

                                                                                </div>
                                                                            </div> 
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Awareness about cool sculpting</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Awareness about cool sculpting" class="form-control"  ng-model="frm.cool_sculpting" name="cool_sculpting" id="cool_sculpting">
                                                                                    </div>                             
                                                                                </div>
                                                                            </div> 

                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">DDC</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="radio-list">
                                                                                        <label class="radio-inline">
                                                                                            <input type="radio" name="ddc"  value="yes" checked  ng-model="frm.ddc"> Yes </label>
                                                                                        <label class="radio-inline">
                                                                                            <input type="radio" name="ddc"  value="no"  ng-model="frm.ddc"> No </label>
                                                                                    </div>                           
                                                                                </div>
                                                                            </div> 

                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Unjunked</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="radio-list">
                                                                                        <label class="radio-inline">
                                                                                            <input type="radio" name="unjunked"  value="yes" checked ng-model="frm.unjunked"> Yes </label>
                                                                                        <label class="radio-inline">
                                                                                            <input type="radio" name="unjunked"  value="no" ng-model="frm.unjunked"> No </label>
                                                                                    </div>                             
                                                                                </div>
                                                                            </div> 



                                                                        </div>
                                                                    </div>
                                                                </div>                       

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Default List-->
                                                    <!-- Medical History -->
                                                    <div class="col-md-12">
                                                        <div class="portlet light bordered">
                                                            <div class="portlet-title">
                                                                <div class="caption" data-toggle="collapse" data-target="#medical_div">
                                                                    Medical History </div>

                                                            </div>
                                                            <div class="portlet-body form  padding-left-right collapse in" id="medical_div">

                                                                <div class="form-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6 right_border_self">
                                                                            <div class="form-group required">
                                                                                <label class="col-md-4 control-label">Others details you want to specify</label>
                                                                                <div class="col-md-8">  
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Others details you want to specify" class="form-control" ng-model="frm.others" name="others" id="others">
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">How often do you catch Cold/Cough</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="How often do you catch Cold/Cough" class="form-control" ng-model="frm.cold_or_cough" name="cold_or_cough" id="cold_or_cough">  </div>                            
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <div class="col-md-6">

                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Lost Deworm</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Lost Deworm" class="form-control" ng-model="frm.lost_deworm" name="lost_deworm" id="lost_deworm">  </div>      
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Allergies</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Allergies" class="form-control" ng-model="frm.allergies" name="allergies" id="allergies">
                                                                                    </div>

                                                                                </div>
                                                                            </div>  

                                                                        </div>
                                                                    </div>
                                                                </div>                       

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Medical History-->    
                                                    <!-- High Calorie Foods -->
                                                    <div class="col-md-12">
                                                        <div class="portlet light bordered">
                                                            <div class="portlet-title">
                                                                <div class="caption" data-toggle="collapse" data-target="#high_div">
                                                                    High Calorie Foods </div>                        
                                                            </div>
                                                            <div class="portlet-body form  padding-left-right collapse in" id="high_div">

                                                                <div class="form-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6 right_border_self">
                                                                            <div class="form-group required">
                                                                                <label class="col-md-4 control-label">Alcohol Consumption</label>
                                                                                <div class="col-md-8">  
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <div class="radio-list">
                                                                                            <label class="radio-inline">
                                                                                                <input type="radio" name="alcohol_consumption"  value="yes" checked ng-model="frm.alcohol_consumption"> Yes </label>
                                                                                            <label class="radio-inline">
                                                                                                <input type="radio" name="alcohol_consumption"  value="no" ng-model="frm.alcohol_consumption"> No </label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Quantity</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Quantity" class="form-control input-inline input-large" ng-show="frm.alcohol_consumption == 'yes'"  ng-model="frm.alcohol_quantity"> </div>                            
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Carbonated Drinks</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Carbonated Drinks" class="form-control input-inline input-large" ng-model="frm.carbonated_drinks" name="carbonated_drinks" id="carbonated_drinks"> </div>                            
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Junk Food</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Junk Food" class="form-control input-inline input-large"  name="junk_food" id="junk_food" ng-model="frm.junk_food">
                                                                                    </div>

                                                                                </div>
                                                                            </div> 
                                                                        </div>
                                                                        <div class="col-md-6">

                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Chocolates</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Chocolates" class="form-control input-inline input-large" name="chocolates" id="chocolates" ng-model="frm.chocolates">  </div>      
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Cake</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Cake" class="form-control input-inline input-large" ng-model="frm.cake" name="cake" id="cake">
                                                                                    </div>

                                                                                </div>
                                                                            </div> 
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Sweets/Mithai</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Sweets/Mithai" class="form-control input-inline input-large" name="sweets_or_mithai" id="sweets_or_mithai" ng-model="frm.sweets_or_mithai">
                                                                                    </div>

                                                                                </div>
                                                                            </div> 
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Fried Food</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Fried Food" class="form-control input-inline input-large"  name="fried_food" id="fried_food" ng-model="frm.fried_food">
                                                                                    </div>

                                                                                </div>
                                                                            </div> 




                                                                        </div>
                                                                    </div>
                                                                </div>                       

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- High Calorie Foods-->
                                                    <!-- General Dietary Habits -->
                                                    <div class="col-md-12">
                                                        <div class="portlet light bordered">
                                                            <div class="portlet-title" >
                                                                <div class="caption"  data-toggle="collapse" data-target="#general_div">
                                                                    General Dietary Habits </div>                       
                                                            </div>
                                                            <div class="portlet-body form  padding-left-right collapse in" id="general_div">

                                                                <div class="form-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6 right_border_self">
                                                                            <div class="form-group required">
                                                                                <label class="col-md-4 control-label">Frequency of Meal-outs</label>
                                                                                <div class="col-md-8">  
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Frequency of Meal-outs" class="form-control"  name="meal_outs" id="meal_outs" ng-model="frm.meal_outs">
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Which oil do you use</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Which oil do you use" class="form-control" name="oil_used" id="oil_used" ng-model="frm.oil_used"> </div>                            
                                                                                </div>
                                                                            </div>


                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Ghee Consumption</label>                                     
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <div class="radio-list">
                                                                                            <label class="radio-inline">
                                                                                                <input type="radio" name="ghee_consumption"  value="yes" checked id="ghee_consumption" ng-model="frm.ghee_consumption"> Yes </label>
                                                                                            <label class="radio-inline">
                                                                                                <input type="radio" name="ghee_consumption"  value="no"  id="ghee_consumption" ng-model="frm.ghee_consumption"> No </label>
                                                                                        </div> </div>                            
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label class="col-md-4 control-label">Quantity</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Quantity" class="form-control input-inline input-large" ng-show="frm.ghee_consumption == 'yes'" id="ghee_quantity" ng-model="frm.ghee_quantity" name="ghee_quantity">
                                                                                    </div>

                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label
                                                                                    class="col-md-4 control-label">Current Medication</label>
                                                                                <div class="col-md-8">
                                                                                    <div class="form-group form-md-line-input">
                                                                                        <input type="text" placeholder="Current Medication" class="form-control input-inline input-large" id="current_medication" ng-model="frm.current_medication" name="current_medication">  </div>      
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>                       

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- General Dietary Habits-->
													<div class="col-md-12">
                                                    <div class="form-actions all_patient_action">                            
                                                    <button type="submit" class="btn save-intense">Save</button>                            
                                                    <button type="button" class="btn cancel-intense">Cancel</button>
                                                    </div>
													</div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab_diseases">
                                        <div class="portlet-body desies_tab_pateint">                                                             
                                            <uib-accordion close-others="oneAtATime">
                                                <uib-accordion-group ng-repeat="(DiseaseGroup, Diseases) in PatientsDiseasesList" is-open="$first"  heading="{{DiseaseGroup}}">
                                                    <div class="row" ng-repeat="(key,disease) in Diseases">
                                                        <div class="col-sm-12">
                                                            <input type="checkbox" class="checkbox checkbox-inline"  ng-model="frm.ids[key]" name="group" id="diseases{{key}}" /> 
                                                            {{ disease}}
                                                        </div>
                                                    </div>
                                                    <br>          
                                                </uib-accordion-group>
                                            </uib-accordion>
                                            <div class="col-md-12">
                                                <div class="form-actions all_patient_action">                            
                                                    <button type="submit" class="btn save-intense">Save</button>                            
                                                    <button type="button" class="btn cancel-intense">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane" id="tab_diagnosis">
                                        <div class="portlet-body desies_tab_pateint">                                                             
                                            <uib-accordion close-others="oneAtATime">
                                                <uib-accordion-group ng-repeat="(DiseaseGroup, Diseases) in PatientsDiseasesList" is-open="$first"  heading="{{DiseaseGroup}}">
                                                    <div class="row" ng-repeat="(key,disease) in Diseases">
                                                        <div class="col-sm-12">
                                                            <input type="checkbox" class="checkbox checkbox-inline"  ng-model="frm.ids[key]" name="group" id="diseases{{key}}" /> 
                                                            {{ disease}}
                                                        </div>
                                                    </div>
                                                    <br>          
                                                </uib-accordion-group>
                                            </uib-accordion>
                                            <div class="col-md-12">
                                                <div class="form-actions all_patient_action">                            
                                                    <button type="submit" class="btn save-intense">Save</button>                            
                                                    <button type="button" class="btn cancel-intense">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!--tab-pane-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active" id="tab_1_1">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">
                            <div class="portlet-body form">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div></div>
