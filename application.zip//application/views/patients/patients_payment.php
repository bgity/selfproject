<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">

                            <div class="row main-height_detail_pat">
                                <?php include_once 'patients_top.php'; ?>                                
                            </div>
                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a data-target="#tab_billing_history" data-toggle="tab" aria-expanded="true"> Billing History </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#tab_add_payment" data-toggle="tab" aria-expanded="true"> Add Payment </a>
                                    </li>                                   
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab_billing_history">
                                        <div class="portlet-body">
                                            <table class="table table-bordered table-advance programtab_details">
                                                <thead>
                                                    <tr>
                                                        <th style="background: #FFECE8 !important;"> Date <a ng-click="sort('fileno')"><i class="fa fa-sort"></i></a> </th>
                                                        <th style="background: #FFECE8 !important;"> Discription </th>
                                                        <th style="background: #FFECE8 !important;"> Charges</th>
                                                        <th style="background: #FFECE8 !important;"> Payment </th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td> 12/01/2015 </td>
                                                        <td> Payment By Cash </td>
                                                        <td> 1500 </td>
                                                        <td> 154200 </td>
                                                    </tr>
                                                    <tr>
                                                        <td> 18/06/2016 </td>
                                                        <td> Payment By Cheque </td>
                                                        <td> 700 </td>
                                                        <td> 895689 </td>
                                                    </tr>
                                                    <tr>
                                                        <td> 05/11/2016 </td>
                                                        <td> By Cash </td>
                                                        <td>0 </td>
                                                        <td> 500 </td>
                                                    </tr>
                                                </tbody>
                                            </table>
											<div class="col-md-12">
                                            <div class="all_patient_action">
                                                <button class="btn outstandin_addpay" ng-click="sav_task()">Outstanding : 15000</button>
                                                <button class="btn outstandin_addpay" ng-click="cacel_task()">Add Payment</button>
                                            </div>
											</div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab_add_payment">
                                        <div class="portlet-body">
                                            <table class="table table-bordered table-advance programtab_details">

                                                <tbody>
                                                    <tr>
                                                        <td> <div class="form-group">
                                                                <div class="col-md-12">
                                                                    <div class="form-group form-md-line-input pull-right">   
                                                                        <span class="outstanding_details">Outstanding
                                                                            <span class="outstading_bg_det"> 
                                                                                <span class="red_outstanding"> 8000 <span> 
                                                                                        <span class="date_outstanding"> 20/03/2016 </span>
                                                                                    </span>
                                                                                </span> 
                                                                                </div>
                                                                                </div>
                                                                                </div> </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space"> Category </label>
                                                                                            <div class="col-md-9">
                                                                                                <div class="form-group form-md-line-input">   
                                                                                                    <select class="bs-select form-control ng-pristine ng-valid ng-touched ng-untouched" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                                                                        <option value=""> Program </option>
                                                                                                        <option value="">Weight 1 </option>
                                                                                                        <option value="">Weight 2 </option>
                                                                                                    </select> 
                                                                                                </div>
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space"> Program Name </label>
                                                                                            <div class="col-md-9">
                                                                                                <div class="form-group form-md-line-input">   
                                                                                                    <select class="bs-select form-control ng-pristine ng-valid ng-touched ng-untouched" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                                                                        <option value=""> plt4 consulting 5kg </option>
                                                                                                        <option value="">Weight 1 </option>
                                                                                                        <option value="">Weight 2 </option>
                                                                                                    </select> 
                                                                                                </div>
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> 
                                                                                        <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space">Amount</label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">     
                                                                                                    <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Amount 15000" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">

                                                                                                </div>  
                                                                                            </div>
                                                                                        </div> 
                                                                                    </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space">Program mode</label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">     
                                                                                                    <div class="radio-list">
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="cash" id="cash"  value="cash" checked ng-model="frm.cash"> Cash </label>
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="cheque" id="cheque"  value="cheque" checked ng-model="frm.cheque"> Cheque </label>
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="credit_card" id="credit_card"  value="credit_card" ng-model="frm.credit_card"> Credit Card </label>
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="bank_deposit" id="bank_deposit"  value="bank_deposit" ng-model="frm.bank_deposit"> Bank Deposit </label>
                                                                                                    </div>

                                                                                                </div>  
                                                                                            </div>
                                                                                        </div>  </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space">Adjust Type</label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">    <div class="radio-list">
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="discount" id="discount"  value="discount" checked ng-model="frm.discount"> Discount </label>
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="adcahrges" id="adcahrges"  value="adcahrges" checked ng-model="frm.adcahrges"> Additional Charges </label>
                                                                                                        <label class="radio-inline">
                                                                                                            <input type="radio" name="none" id="none"  value="none" ng-model="frm.none"> None </label>

                                                                                                    </div>
                                                                                                </div>  
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space">Adjustment Amount </label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">                                                
                                                                                                    <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Current" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">

                                                                                                </div>  
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>

                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space"> Net </label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">                                                
                                                                                                    <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Current" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">

                                                                                                </div>  
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>
                                                                                <tr>
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space"> Bill No. </label>
                                                                                            <div class="col-md-9">                                            
                                                                                                <div class="form-group form-md-line-input">                                                
                                                                                                    <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Current" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">

                                                                                                </div>  
                                                                                            </div>
                                                                                        </div> </td>

                                                                                </tr>

                                                                                <tr height="150px;">
                                                                                    <td> <div class="form-group">
                                                                                            <label class="col-md-3 control-label no-space"> Remark </label>
                                                                                            <div class="col-md-9"> 
                                                                                                <div class="form-group form-md-line-input">   
                                                                                                    <textarea class="form-control text_area_section" rows="3" placeholder="Enter your Remark"></textarea>
                                                                                                </div> 

                                                                                            </div>
                                                                                        </div> </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>
																					<div class="col-md-4 no-space pull-right">
                                                                                            <div class="all_patient_action">
                                                                                                <button class="btn save-intense" ng-click="sav_task()">Save</button>
                                                                                                <button class="btn cancel-intense" ng-click="cacel_task()">Cancel</button>
                                                                                            </div> </div> </td>
                                                                                </tr>

                                                                                </tbody>
                                                                                </table>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                <!--tab-pane-->
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>
                                                                                </div>  </div>  </div>
