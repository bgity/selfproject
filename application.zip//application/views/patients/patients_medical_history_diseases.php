<div class="page-content-inner">
    <div class="row">
        <!-- questionnaire starts-->
        <div class="col-md-12">
            <!-- BEGIN ACCORDION PORTLET-->
            <form novalidate valid-submit="patientMedicalHistoryDiseasesAdd()" name="frmDiseases">
            <div class="portlet box red">                
                <div class="portlet-title">
                    <div class="caption"> Medical History </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>                                               
                    </div>
                </div>
                <div class="portlet box green margin-15-panel">                                                             
                    <uib-accordion close-others="oneAtATime">
                        <uib-accordion-group ng-repeat="(DiseaseGroup, Diseases) in PatientsDiseasesList" is-open="$first"  heading="{{DiseaseGroup}}">
                            <div class="row" ng-repeat="(key,disease) in Diseases">
                                <div class="col-sm-12">
                                    <input type="checkbox" class="checkbox checkbox-inline"  ng-model="frm.ids[key]" name="group" id="diseases{{key}}" /> 
                                    {{ disease}}
                                </div>
                            </div>
                            <br>          
                        </uib-accordion-group>
                    </uib-accordion>
                    <div>
                        <div class="form-actions text-center">                            
                            <button type="submit" class="btn green-meadow">Save</button>                            
                            <button type="button" class="btn grey-cascade">Cancel</button>
                        </div>
                    </div>                                        
                </div>            
            </div>
            </form>
            <!-- END ACCORDION PORTLET-->
        </div>
        <!-- questionnaire ends-->        
    </div>
</div>