<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">

                            <div class="row main-height_detail_pat">
                                <?php include_once 'patients_top.php'; ?>                                
                            </div>
                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a data-target="#tab_program_history" data-toggle="tab" aria-expanded="true"> Program History </a>
                                    </li>
                                    <li class="">
                                        <a data-target="#tab_add_program" data-toggle="tab" aria-expanded="true"> Add Program </a>
                                    </li>                                    
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab_program_history">
                                        <div class="portlet-body">
                                            <table class="table table-bordered table-advance programtab_details">
                                                <thead>
                                                <tr>
                                                    <th style="background: #FFECE8 !important;"> No. </th>
                                                    <th style="background: #FFECE8 !important;"> Program </th>
                                                    <th style="background: #FFECE8 !important;"> Category</th>
                                                    <th style="background: #FFECE8 !important;"> Start Date </th>
                                                    <th style="background: #FFECE8 !important;"> End Date </th>
                                                    
                                                </tr>
                                            </thead>
											<tbody>
                                                <tr>
                                                    <td> 1 </td>
                                                    <td> Weight Loss </td>
                                                    <td> Platinum </td>
                                                    <td> 01/02/2016 </td>
                                                    <td> 01/05/2016 </td>
                                                </tr>
												<tr>
                                                    <td> 1 </td>
                                                    <td> Weight Loss </td>
                                                    <td> Platinum </td>
                                                    <td> 01/02/2016 </td>
                                                    <td> 01/05/2016 </td>
                                                </tr>
												<tr>
                                                    <td> 1 </td>
                                                    <td> Weight Loss </td>
                                                    <td> Platinum </td>
                                                    <td> 01/02/2016 </td>
                                                    <td> 01/05/2016 </td>
                                                </tr>
                                            </tbody>
                                            </table>
											<div class="col-md-12">
											<div class="all_patient_action">
											<a href="#tab_1_22"><button class="btn add_programm_patient" ng-click="add_task()">Add Program</button></a>
											
											</div>
											</div>
                                        </div>
                                    </div>
                                    <!--tab-pane-->
                                    <div class="tab-pane" id="tab_add_program">
                                        <div class="portlet-body">
                                            <table class="table table-bordered table-advance programtab_details">
                                                <tbody>
                                                <tr>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space"> Program Type</label>
                                        <div class="col-md-8">
                                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                <option value="">Weight Loss </option>
                                                <!-- ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Non Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Jain</option><!-- end ngRepeat: meal in mealList -->
                                            </select> 
                                        </div>
                                    </div> </td>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">Program Name</label>
                                        <div class="col-md-8">
                                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                <option value="">Weight Loss </option>
                                                <!-- ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Non Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Jain</option><!-- end ngRepeat: meal in mealList -->
                                            </select> 
                                        </div>
                                    </div> </td>
                                                </tr>
												<tr>
                                                <td> 
												<div class="form-group">
                                        <label class="col-md-4 control-label no-space">KGS</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Weight" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> 
									</td>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">Program Category</label>
                                        <div class="col-md-8">
                                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" name="meal_type" id="meal_type" ng-model="frm.meal_type">
                                                <option value="">Weight Loss </option>
                                                <!-- ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Non Vegetarian</option><!-- end ngRepeat: meal in mealList --><option ng-repeat="meal in mealList" value="meal.value" class="ng-binding ng-scope">Jain</option><!-- end ngRepeat: meal in mealList -->
                                            </select> 
                                        </div>
                                    </div> </td>
                                                </tr>
												<tr>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">No of Visits</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your No of Visits" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div>  </td>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space"> Cost</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Cost" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> </td>
                                                </tr>
												<tr>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">Duration(weeks)</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Duration" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> </td>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space"> Target date</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Target date" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> </td>
                                                </tr>
												<tr>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">Current Weight</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Current" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> </td>
                                                <td> <div class="form-group">
                                        <label class="col-md-4 control-label no-space">Target Weight</label>
                                        <div class="col-md-8">                                            
                                            <div class="form-group form-md-line-input">                                                
                                                 <input type="text" class="form-control ng-pristine ng-untouched ng-invalid ng-invalid-required" placeholder="Enter your Target Weight" name="patient_name" id="patient_name" required="" ng-model="frm.patient_name">
                                                
                                           </div>  
                                        </div>
                                    </div> </td>
                                                </tr>
                                                </tbody>
                                            </table>
											<div class="col-md-12">
											<div class="all_patient_action">
											<button class="btn save-intense" ng-click="sav_task()">Save</button>
											<button class="btn cancel-intense" ng-click="cacel_task()">Cancel</button>
											</div>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--tab-pane-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div></div>
