<!-- BEGIN PAGE HEADER-->

<!-- END PAGE HEADER-->
<!-- BEGIN PAGE CONTENT-->
<div class="row">
	<div class="col-md-12 tabformeal_area_plaan">
    <div class="mealplan_box">
		<div class="portlet box">
         <ul class="nav nav-tabs plan_head">                           
			<li ng-repeat="tab in advised_plan_tabs" ng-class="{active: $index == subcurrentTab}" ng-click="loadsubTabContent($index)">
				<a data-toggle="tab" aria-expanded="true">{{ tab.title}} </a>    
			</li>
			
		</ul>
         <div class="tab-content mealplan_box_tab_area">                                    
			<div  ng-repeat="tab in advised_plan_tabs" ng-class="{active: $index == subcurrentTab}">                                                
				<ng-include src="tab.content" ng-if="$index == subcurrentTab"></ng-include>
			</div>                                    
		</div>                                   
                                    
                              
	
		</div>

        </div>
	</div>
</div>
<!-- END PAGE CONTENT-->
	