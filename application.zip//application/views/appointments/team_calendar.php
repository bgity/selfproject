<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div dhx-schedulerunit data="events | filter:search" style="height:800px; width:100%;">
        <div class="dhx_cal_prev_button">&nbsp;</div>
        <div class="dhx_cal_next_button">&nbsp;</div>
        <div class="dhx_cal_today_button"></div>
        <div class="dhx_cal_date"></div>    
</div>
</div>
</div>
<div style="display:none;" id="my_form" class="ng-scope portlet light poup_all_self_area" onload="init()">
	<div class="portlet-title">
		<div class="caption">
		<span class="caption-subject bold uppercase"> 
		        <b> Appointment</b>
		</span>
		</div>
		<div class="actions">
            <a ng-click="Cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
	</div>
	<div class="portlet-body">
		<div class="col-md-12 pad-top-10 pad-0 col-xs-12" style="float: left;">
		<form class="form-horizontal ng-pristine ng-invalid ng-invalid-required" ng-init="init();submitted=false;" role="form" novalidate name="SchedAppointmentForm">
								<div class="form-group">
					<label class="col-md-3 control-label">Patient </label>
					<div class="col-sm-9 col-md-7 col-lg-7">
					<div class="form-group form-md-line-input">
						<input type="text" name="PatientName" id="PatientName" ng-disabled="editable" typeahead-editable="true" ng-model="Appointment.PatientName" typeahead="refer.name for refer in people | filter:{name:$viewValue} | limitTo:10" typeahead-template-url="customRatingTemplate.html" class="form-control" typeahead-on-select="$root.IsValidName = false;setPatientId($item);DisplayPatientInfo(Appointment.PatientId);" ng-blur="IsValidName(Appointment,$root.isCPCollapsed);" ng-focus="$root.IsValidName = false" required placeholder="Patient name">
                         <input type="hidden" id="PatientId" name="PatientId"  ng-model="Appointment.PatientId" required  />
						<!-- <span class="error" ng-show="submitted && SchedAppointmentForm.PatientName.$error.required">Patient is required.</span>-->
						 </div>
						 </div>
                                <div class="col-lg-2 col-sm-2 col-md-2 pad-top-cancel" >
                                    <a ng-if="mode === 'Create'"  class="active-item" href="#" ng-click="$root.isCPCollapsed=!$root.isCPCollapsed;$root.newPatientInit(Appointment);IsValidName(Appointment,$root.isCPCollapsed);" prevent-click><span ng-if="!$root.isCPCollapsed"><img src="assets/layouts/layout/self-images/add-user.png"></span><span ng-if="$root.isCPCollapsed"> <img src="assets/layouts/layout/self-images/no-user.png">  </span></a>
                                    <div ng-init="$root.isCPCollapsed=false" collapse="!$root.isCPCollapsed" class="text-center pad-right-0 cpModal" style="margin-left:-14px;">
                                      <!--  <div class="" ng-include="'../appointment/SchCreateNewPatient.html'"></div>-->
                                    </div>
                                </div>                   
				</div>				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" style="margin-top: -5px;" for="gender"></span>
					<div class="col-sm-7 col-md-7 col-lg-7" style="width: 180px;">
					<dd>
					<label class="new-ui-radio" style="width: 75px;">
					<input id="rdoM" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" value="Male" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Male</span>
					</label>
					<label class="new-ui-radio" style="width: 70px;">
					<input id="rdoF" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" checked="" value="Female" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Female</span>
					</label>
					</dd>
					<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.gender.$error.required" style="float: left;">Gender is required</span>-->
					</div>
				</div>

				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mealType">Meal Type</span>
					<div class="col-sm-9 col-md-7 col-lg-7">
					<div class="form-group form-md-line-input">
					<select class="form-control dropdownHeight ng-pristine ng-valid ng-valid-required" ng-required="$root.isCPCollapsed==true" ng-model="Appointment.MealType" name="mealtype" required="required">
					<option style="display: none;" selected="" disabled="" value="">Select Meal Type</option>
					<option class="ng-scope ng-binding" value="UNKNOWN" >Unknown</option>
					<option class="ng-scope ng-binding" value="Vegetarian" >Vegetarian</option>
					<option class="ng-scope ng-binding" value="Jain Vegetarian">Jain Vegetarian</option>
					<option class="ng-scope ng-binding" value="Vegan">Vegan</option>
					<option class="ng-scope ng-binding" value="Eggetarian">Eggetarian</option>
					<option class="ng-scope ng-binding" value="Non Vegetarian">Non Vegetarian</option>
					</select>
					<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.mealtype.$error.required" style="float: left;">Meal type is required</span>-->
					</div>
				</div></div>
				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mobile">Mobile</span>
					<div class="col-sm-9 col-md-7 col-lg-7 datediv">
					<div class="form-group form-md-line-input">
					<div class="input-group input-group-sm">
					<span class="input-group-addon phone_data_icons">
					<img src="http://localhost/selfcare/assets/layouts/layout/self-images/telephone.png">
					</span>
					<input class="form-control ng-pristine ng-valid" type="text" only-selected="" restrict-paste="" mobile-number="" name="mobileno1" ng-model="Appointment.Mobile1" style="border-left: 0px;border-top-left-radius: 0px !important;border-bottom-left-radius: 0px !important;">
					</div>
					<!--<span class="error ng-hide" ng-show="SchedAppointmentForm.mobileno1.$error.mobile" style="float: left;">Invalid mobile number</span>-->
					</div>
				</div>
				</div>
				
				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Nutritionist">Nutritionist</span>
					<div class="col-sm-9 col-md-7 col-lg-7 datediv">
					<div class="form-group form-md-line-input">
						<select id="NutritionistId" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-change="selectBranch(Appointment.NutritionistId);IsAppointmentExist(Appointment)" ng-model="Appointment.NutritionistId" name="NutritionistId" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Nutritionist</option>
						<option ng-repeat="oldcn in nutritionist | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.NutritionistName.$error.required">Nutritionist is required.</span>-->
					</div>
				</div>
				</div>

				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Branch">Branch</span>
						<div class="col-sm-9 col-md-7 col-lg-7 datediv">
					<div class="form-group form-md-line-input">
							<select id="Branch" class="form-control dropdownHeight" required="" name="Branch">
							<option style="display: none;" selected="" disabled="" value="">Select Branch</option>
							<option ng-repeat="branch in branchLists | orderBy:'Name'" value="{{branch.id}}">{{branch.name}}</option>
							</select>
							<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.Branch.$error.required">Branch is required.</span>-->
						</div>
						</div>
				</div>
				
				<div class="form-group">
                    <label class="control-label col-md-3">Date</label>
                    <div class="col-md-7">
                        <div class="date form_datetime form-group form-md-line-input">
                            <input type="text" id="Sch_CreateDate" class="form-control input-inline" datepicker-popup="{{app_date_format}}" ng-model="Appointment.AppointmentDate" is-open="opened" datepicker-options="dateOptions" ng-required="false" close-text="Close" />
                            <span class="input-group-btn calendar_all_sec">
                                <button type="button" class="btn btn-default" ng-click="open($event)">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
                            </span>
                        </div>
                        <!-- /input-group -->
                    </div>
                </div>
				
				<div class="form-group">
                    <label class="control-label col-md-3">Time</label>
                    <div class="col-md-7">
					<div class="form-group form-md-line-input">
                        <span class="col-sm-5 col-md-5 col-lg-5 time_block">
                                <input id="timepicker4" class="form-control input-inline" type="text" restrict-paste="" required="" placeholder="00:00 AM" ng-blur="IsAppointmentExist(Appointment); IsValidStrtTimeLimit(Appointment)" ng-focus="appointmentExist = false;
                                                                IsStartTimeValid = false;
                                                                IsEndTimeValid = false;" ng-model="Appointment.StartTime" name="AppointmentStartTime">
                                <span class="input-group-btn time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
                        </span>

                        <span class="col-sm-1 col-md-1 col-lg-1 tome_to_block">
                            <label for="to"> To </label>
                        </span>

                        <span class="col-sm-5 col-md-5 col-lg-5 time_block">
                                <input id="timepicker3" class="form-control input-inline" type="text" restrict-paste="" required="" placeholder="00:00 AM" ng-blur="IsAppointmentExist(Appointment); IsValidStrtTimeLimit(Appointment)" ng-focus="appointmentExist = false;
                                                                IsStartTimeValid = false;
                                                                IsEndTimeValid = false;" ng-model="Appointment.StartTime" name="AppointmentStartTime">
                                <span class="input-group-btn time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
                        </span>
                        <span class="error" ng-show="submitted && SchedAppointmentForm.AppointmentEndTime.$error.required && SchedAppointmentForm.AppointmentStartTime.$error.required || IsStartTimeValid || IsEndTimeValid">Appointment time is required.</span>
                        <span class="error" id="error" ng-show="SchedAppointmentForm.AppointmentEndTime.$error.validtime && !IsStartTimeValid && !IsEndTimeValid">End time should be greater than start time.</span>
                        <span class="error" ng-show="SchedAppointmentForm.AppointmentStartTime.$error.required == false && IsStartTimeValid == false && IsStartLimitInValid == true">Invalid start time.</span>
                        <span class="error" ng-show="SchedAppointmentForm.AppointmentEndTime.$error.required == false && IsEndTimeValid == false && IsEndLimitInValid == true">Invalid end time.</span>
                    </div>
					</div>
                </div> 
				
				<div class="form-group">
					<label class="control-label col-md-3">Type</label>
					<div class="col-sm-9 col-md-7 col-lg-7 datediv">
					<div class="form-group form-md-line-input">
						<select id="appointment_type" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-model="Appointment.AppointmentTypeID" required="" name="AppointmentType" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Appointment Type</option>
						<option ng-repeat="oldcn in typeList | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AppointmentType.$error.required">Attended By is required.</span>-->
						
					</div>
					</div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Attended By</label>
					<div class="col-sm-9 col-md-7 col-lg-7 datediv">
					<div class="form-group form-md-line-input">
						<select id="attended_by" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" " ng-model="Appointment.attended_by" required="" name="AttendedByName" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Person</option>
						<option ng-repeat="oldcn in people | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AttendedByName.$error.required">Attended By is required.</span>-->
					</div>
					</div>
				</div>
				
				<div class="form-group" style="display:none" id="patient_checked_in">
					<input type="checkbox" value="1" ng-model="Appointment.patient_checked_in" >
					<div class="col-sm-7 col-md-7 col-lg-7">
					Patient Checked In
					</div>
				</div>
				
				<div class="form-group" style="display:none" id="appointment_complete" >
					<input type="checkbox" value="1" ng-model="Appointment.appointment_complete">
					<div class="col-sm-7 col-md-7 col-lg-7">
					Appointment Complete
					</div>
				</div>
				
				<div class="col-md-12 padding_bottom_tw">
					<div class="all_patient_action">
					<button class="btn save-intense" ng-click="save(Appointment,SchedAppointmentForm.$valid);submitted=true;" type="submit">Save</button>
					<button class="btn cancel-intense" id="cancel_appointment_button" ng-click="save('','',1)" type="submit">Cancel Appointment</button>
					<button class="btn cancel-intense" ng-click="Cancel()" value="Cancel" type="button">Cancel</button>
					</div>
				</div>
		</form>
	</div>
	</div>
</div>

<script type="text/ng-template" id="customRatingTemplate.html">
   <a tabindex="-1">
	  <div ng-bind-html="match.model.name"></div>
	  <small ng-bind-html="match.model.email"></small>
   </a>
</script>
