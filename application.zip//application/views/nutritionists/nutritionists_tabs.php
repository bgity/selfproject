<div class="portlet">
    <div class="portlet-body flip-scroll shorting_table_area">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
            <tr>
                <th class="name"> Name <a ng-click="sort('name')"><i class="fa fa-sort"></i></a></th>
                <th class="branch"> Branch <a ng-click="sort('branch')"><i class="fa fa-sort"></i></a></th>
               <!------ <th class="qualification"> Qualification <a ng-click="sort('qualification')"><i class="fa fa-sort"></i></a>
                </th> ->
                <!------<th class="joindate"> Joinnig Date <a ng-click="sort('joindate')"><i class="fa fa-sort"></i></a></th> -->
                <th class="mobileno"> Mobile Number <a ng-click="sort('mobileno')"><i class="fa fa-sort"></i></a></th>
                <th class="email"> Email <a ng-click="sort('email')"><i class="fa fa-sort"></i></a></th>
                <th class="role"> Role <a ng-click="sort('role')"><i class="fa fa-sort"></i></a></th>
                <th class="type"> Type <a ng-click="sort('type')"><i class="fa fa-sort"></i></a></th>
                <!------<th class="exitdate"> Date Of Exit <a ng-click="sort('exitdate')"><i class="fa fa-sort"></i></a></th> ---->
                <th class="activepatient"> Active Patients <a ng-click="sort('activepatient')"><i
                            class="fa fa-sort"></i></a></th>
                <th class="outstanding"> Outstanding <a ng-click="sort('outstanding')"><i class="fa fa-sort"></i></a>
                </th>
                <th class="collection"> Total Collections <a ng-click="sort('collection')"><i
                            class="fa fa-sort"></i></a></th>
            </tr>
            </thead>
            <tbody>
            <tr ng-repeat="nutr in nutritionistList">
                <td> <a href="nutritionists-details.html">{{ nutr.name}}</a></td>
                <td>{{nutr.branch}}</td>
                <!------<td>{{nutr.qualification}}</td>
                <td>{{nutr.graduation_year}}</td>  ----->
                <td>{{nutr.mobile_number}}</td>
                <td> {{nutr.email}}</td>
                <td> {{nutr.role}}</td>
                <td> {{nutr.type}}</td>
                <!------<td> {{nutr.date_of_exit}}</td> -------->
                <td> {{nutr.active_patients}}</td>
                <td> {{nutr.outstanding}}</td>
                <td> {{nutr.total_collections}}</td>
            </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="nutritionistListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="nutritionistListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>