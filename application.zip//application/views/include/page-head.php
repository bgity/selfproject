<div class="page-head">
    <div class="container-fluid header_subfull_ttilename header_sub_sec">
        <div class="row">
            <div class="col-md-12">
                <div class="page-title">
                    <h1>
                        <span data-ng-bind="$state.current.data.pageTitle"></span>
                        <small data-ng-bind="$state.current.data.pageSubTitle"></small>
                    </h1>
                </div>
            </div>       
        </div>
    </div> 
</div> 