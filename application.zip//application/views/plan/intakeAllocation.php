<div class="intakechart_meal_plan">
<div class="form-group text-center intk_top"> 
	Proteins: <input type="text" class="form-control input-inline input-xsmall blk" name="rec_protien" ng-model="formData.rec_protien" ng-disabled="true">
    Fats: <input type="text" class="form-control input-inline input-xsmall blk" name="rec_fat" ng-model="formData.rec_fat" ng-disabled="true">
    Carbs: <input type="text" class="form-control input-inline input-xsmall blk" name="rec_carbs" ng-model="formData.rec_carbs" ng-disabled="true">
	ICC %: <input type="text" class="form-control input-inline input-xsmall blk" name="icc_adjusted" ng-model="formData.icc_adjusted" ng-disabled="true">
    Total CD: <input type="text" class="form-control input-inline input-xsmall" name="total_cd" ng-model="formData.total_cd" ng-disabled="true">	
</div>
<div class="intakechart_meal_plan_header">
<h3 class="text-center main_head">Intake Chart</h3>
 <div class="portlet-body">
   
		<table class="table">
		<thead>
		<tr>
			<th width="25%">
				 Categories
			</th>
			<th  width="10%">
				 No. of Serving
			</th>
			<th width="15%">
				 Amt/Serving
			</th>
			<th width="10%">
				 Protein
			</th>
			<th width="10%">
				 Fat
			</th>
			<th width="10%">
				 Carbs
			</th>
			<th width="10%">
				 Calories
			</th>
			<th width="10%">
				 Calcium
			</th>
		</tr>
		</thead>
		</table>
	   <div class="table-responsive fixed_height">
		<table class="table tblnew">
		<tbody>
		<tr ng-repeat="food in foods | toArray | orderObjectBy:'order_by'" >
			<td width="25%">
				{{food.name}}
			</td>
			<td width="10%">
				<input class="form-control input-xsmall" type="text" name="no_of_serving" ng-model="formData.foods[food.id].no_of_serving" value="0" ng-change="updateIntake(food.id)" />
			</td>
			<td width="15%">
				{{food.weight_per_serving}}
			</td>
			<td width="10%">
				 <input class="form-control input-inline input-xsmall" type="text" ng-model="formData.foods[food.id].prot_per_serving" ng-disabled=true />
			</td>
			<td width="10%">
				 <input class="form-control input-inline input-xsmall" type="text" ng-model="formData.foods[food.id].fat_per_serving" ng-disabled=true />
			</td>
			<td width="10%">
				 <input class="form-control input-inline input-xsmall" type="text" ng-model="formData.foods[food.id].chol_per_serving" ng-disabled=true />
			</td>
			<td width="10%">
				 <input class="form-control input-inline input-xsmall" type="text" ng-model="formData.foods[food.id].calo_per_serving" ng-disabled=true />
			</td>
			<td width="10%">
				 <input class="form-control input-inline input-xsmall" type="text" ng-model="formData.foods[food.id].calc_per_serving" ng-disabled=true />
			</td>
		</tr>
		
		</tbody>
		</table>
		
		
	</div>
	<table class="table">
		 <tr>
			<td width="25%">&nbsp;</td>
			<td  width="10%"></td>
			<td width="15%"><b>Total</b></td>
			<td width="10%"><b>{{prot_tot | number:2}}</b></td>
			<td width="10%"><b>{{fat_tot | number:2}}</b></td>
			<td width="10%"><b>{{chol_tot | number:2}}</b></td>
			<td width="10%"><b>{{calo_tot | number:2}}</b></td>
			<td width="10%"><b>{{calc_tot | number:2}}</b></td>
		</tr>
	</table>
</div></div>
</div>
<div class="form-group">
	<div class="row">
		<div class="col-md-12">
			<div class="all_patient_action">
				<a class="btn save-intense" ng-click="selectedTemplate.path = 'diet/mealExchange';setTab('meal');"> Next </a> OR
				<button class="btn save-intense"> Save </button>
			</div>
		</div>
	</div>
</div>