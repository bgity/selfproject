<script type="text/ng-template" id="frameSizeMaster" >
<div  class="modal-dialog modal-sm">
<table  class="table table-bordered table-condensed table-responsive">
    <thead>
        <tr>
			<td>Operator</td>
			<td>Size</td>
        </tr>
    </thead>
    <tbody>
        <tr ng-repeat="size in framesize">
          <td>{{size.operator}}</td>
          <td>{{size.value2}} - {{size.value1}}</td>
        </tr>
    </tbody>
</table>
</div>
</script>