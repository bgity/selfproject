<div class="portlet light poup_all_self_area">
<div class="portlet-title">
        <div class="caption">
            <span class="caption-subject bold uppercase"> 
                <b> {{title}}</b>
            </span>
        </div>
        <div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
    </div>
<div class="modal-body portlet-body">
    <form class="form-horizontal form-bordered" valid-submit="addGroupItem();" name="frmgroupitemadd" id="frmgroupitemadd" novalidate>
        <div class="form-body">
            <div class="form-group">
                <label class="control-label col-md-3">Label</label>
                <div class="col-md-8">
                    <div class="form-group form-md-line-input">
                        <input type="text" class="form-control" name="item_lable" id="item_lable"
                               ng-model="formData.item_lable" ng-required="true" autocomplete="off">
                        <div class="custom-error"
                             ng-show="frmgroupitemadd.item_lable.$invalid">
                            <span
                                ng-show="frmgroupitemadd.$submitted && frmgroupitemadd.item_lable.$error.required">Name is Required.</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label">Field type</label>
                <div class="col-md-8">
                    <div class="form-group form-md-line-input">
                        <select class="layout-style-option form-control input-sm" ng-model="formData.field_type"
                                name="field_type" id="field_type"
                                ng-options="fieldtype.fieldId as fieldtype.fieldType for fieldtype in fieldTypes"
                                ng-required="true" ng-change="changeOptionItem();">
                            <option value="">Select Field Type</option>
                        </select>
                         <div class="custom-error" ng-show="frmgroupitemadd.field_type.$invalid">
                            <span ng-show="frmgroupitemadd.$submitted && frmgroupitemadd.field_type.$error.required">Select Field Type.</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group" ng-if="formData.field_type == 'range'">
                <div class="col-md-12">
                    <div class="col-md-3">
                        <button class="btn btn-sm" ng-click="addRangeOptions(formData);">+ Add Option</button>
                    </div>
                    <div class="col-md-8 no-space">

                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Name:</label>
                                <input type="text" class="form-control" name="rangename" id="rangename" placeholder="name"
                                       ng-model="formData.rangeoptionvalue[0].rangename">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Start:</label>
                                <input type="text" class="form-control"  name="start_range" id="start_range" placeholder="Range"
                                       ng-model="formData.rangeoptionvalue[0].rangeoptionval">
                                <div class="custom-error"
                                     ng-show="frmgroupitemadd.start_range.$invalid">
                                    <span ng-show="frmgroupitemadd.$submitted && frmgroupitemadd.start_range.$error.required">Start Range is Required.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>End:</label>
                                <input type="text" class="form-control"  name="rangeoptionval" id="rangeoptionval" placeholder="Range"
                                       ng-model="formData.rangeoptionvalue[0].rangeoptionval">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Unit:</label>
                                <select class="layout-style-option form-control input-sm" ng-model="formData.unit_type"
                                        name="unit_type" id="unit_type"
                                        ng-options="unittype.unitId as unittype.unitType for unittype in unitMeasurement"
                                        ng-required="true">
                                    <option value="">Select Unit</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Selfcare Range:</label>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Start:</label>
                                <input type="text" class="form-control"  name="rangeoptionval" id="rangeoptionval" placeholder="Range"
                                       ng-model="formData.rangeoptionvalue[0].rangeoptionval">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>End:</label>
                                <input type="text" class="form-control"  name="rangeoptionval" id="rangeoptionval" placeholder="Range"
                                       ng-model="formData.rangeoptionvalue[0].rangeoptionval">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group form-md-line-input">
                                <label>Unit:</label>
                                <select class="layout-style-option form-control input-sm" ng-model="formData.unit_type"
                                        name="unit_type" id="unit_type"
                                        ng-options="unittype.unitId as unittype.unitType for unittype in unitMeasurement"
                                        ng-required="true">
                                    <option value="">Select Unit</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-9 col-md-offset-3" ng-repeat="rangeOptions in resultValue = (formData.rangeoptionvalue) track by $index" ng-animate="animate">
                        <div class="col-md-12">    
                            <div class="col-md-6">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control" name="rangename" id="rangename"
                                           ng-model="formData.rangeoptionvalue[$index + 1].rangename">
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control"  name="rangeoptionval" id="rangeoptionval"
                                           ng-model="formData.rangeoptionvalue[$index + 1].rangeoptionval">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <a style="padding: 10px;" ng-click="formData.rangeoptionvalue.splice(i, 1);"><i class="fa fa-close"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group" ng-if="formData.field_type == 'dropdown' || formData.field_type == 'radio' || formData.field_type == 'checkbox' || formData.field_type == 'multiplecheck'">
                <div class="col-md-12">
                    <div class="col-md-3">
                        <button class="btn btn-sm" ng-click="addoptions(formData);">+ Add Option</button>
                    </div>
                    <div class="col-md-9 col-md-offset-3" ng-repeat="options in resultValue = (formData.optionvalue) track by $index" ng-animate="animate">
                        <div class="col-md-12">    
                            <div class="col-md-7">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control" name="optionval" id="optionval"
                                           ng-model="formData.optionvalue[$index].optionval">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <a style="padding: 10px;" ng-click="formData.optionvalue.splice(i, 1);"><i class="fa fa-close"></i></a>
                            </div>
                            <div class="col-md-4"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group" ng-if="formData.field_type != 'range' && formData.field_type != 'radio' && formData.field_type != 'dropdown' && formData.field_type != 'checkbox' && formData.field_type != 'multiplecheck'">
                <label class="col-md-3 control-label">Units</label>
                <div class="col-md-8">
                    <div class="form-group form-md-line-input">
                        <select class="layout-style-option form-control input-sm" ng-model="formData.unit_type"
                                name="unit_type" id="unit_type"
                                ng-options="unittype.unitId as unittype.unitType for unittype in unitTypes"
                                ng-required="true">
                            <option value="">Select Unit Type</option>
                        </select>
                         <div class="custom-error" ng-show="frmgroupitemadd.unit_type.$invalid">
                            <span ng-show="frmgroupitemadd.$submitted && frmgroupitemadd.unit_type.$error.required">Select Unit Type.</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-12">
                    <div class="divbtn_add_left">
                        <button class="btn save-intense" ng-click="addExtraOptions(formData);"> + Add Extra Field </button>
                    </div>
                    <div class="col-md-9 col-md-offset-3" ng-repeat="extraoptions in resultValue = (formData.extraoptionvalue) track by $index"  ng-animate="animate">
                        <div class="col-md-12 no-space">    
                            <div class="col-md-7 no-space">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control form-md-line-input" name="extraoptionval" id="extraoptionval" ng-model="formData.extraoptionvalue[$index].extraoptionval" style="float: left;">
									<div class="cancel_popup_master">   <a class="form-cross_all_popup" ng-click="formData.extraoptionvalue.splice(i, 1);"><i class="fa fa-close"></i></a> </div>
									
                                </div>
                            </div>
                            <div class="col-md-1">
                              
                            </div>
                            <div class="col-md-4">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" padding_bottom_tw all_patient_action">
                <button type="submit" value="Submit" class="btn save-intense">Save</button>
                <button class="btn cancel-intense" ng-click="cancel()">Cancel</button>
            </div>
        </div>
    </form>
</div>
</div>
