<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="mareting_list_view row">
<div class="col-md-12 form-horizontal_marketing">
<div class="left_view_marketing col-md-4">
<div class="form-group form-md-line-input col-md-12">	
		<select id="type_id" class="form-control" ng-model="Marketing.typeID" required="" name="TypeID">
			<option style="display: none;" selected="" disabled="" value="">Select Type</option>
			<option value="email" selected="selected">Email</option>
			<option value="sms">SMS</option>
		</select>
</div>

<div class="form-group form-md-line-input col-md-12">
		<select id="template_id" class="form-control" ng-model="Marketing.template" required="" name="template">
			<option style="display: none;" selected="" disabled="" value="">Select Template</option>
			<option value="1">Template 1</option>
			<option value="2">Template 2</option>
		</select>
</div>

	
	<div class="col-md-12 form-group form-md-line-input">
	<label class="form_group_text">Scheduler</label>
									<div class="eamilmarketing_date"  ng-controller="DatepickerCtrl">
										<div class="form-group form-md-line-input">
                                            <input type="text" placeholder="Schedule your date" class="form-control input-inline"  datepicker-popup="{{ format}}" is-open="opened.openedDob" datepicker-options="dateOptions" close-text="Close" ng-model="frm.dob" >
                                            <span class="input-group-btn calendar_all_sec">
                                                <button type="button" class="btn btn-default" ng-click="open($event, 'openedDob')">
                                                    <i class="glyphicon glyphicon-calendar"></i>
                                                </button>
											
                                            </span>      
										</div>											
                                        </div>
		<!-- /input-group -->
	</div>
	<div class="form-group form-md-line-input col-md-12">
			<input type="text" class="form-control timepicker timepicker-default"> </div>

<div class="form-group form-md-line-input col-md-12">
		<select id="frequency" class="form-control" ng-model="Marketing.frequency" required="" name="frequency">
			<option style="display: none;" selected="" disabled="" value="">Select Frequency</option>
			<option value="weekly">Weekly</option>
			<option value="monthly">Monthly</option>
		</select>
</div>


	
	<div class="col-md-12 form-group form-md-line-input" >
	<label class="form_group_text" for="Recipients">Recipients</label>
		<select id="group" class="form-control" ng-model="Marketing.group" required="" name="group">
			<option style="display: none;" selected="" disabled="" value="">Select Group</option>
			<option value="1" selected="selected">Group 1</option>
			<option value="2">Group 2</option>
		</select>
	</div>
	
	<div class="col-md-12 form-group form-md-line-input" >
		<select id="subgroup" class="form-control" ng-model="Marketing.subgroup" required="" name="subgroup">
			<option style="display: none;" selected="" disabled="" value="">Select Patient Type</option>
			<option value="1" selected="selected">Platinum</option>
			<option value="2">Gold</option>
		</select>
	</div>
	<div class="col-md-12 form-group form-md-line-input" style="text-align:centre;" >
	OR
	</div>
	<div class="col-md-12 form-group form-md-line-input" >
		<input type="text" name="PatientName" id="PatientName" ng-disabled="editable" typeahead-editable="true" ng-model="Marketing.PatientName" typeahead="refer.name for refer in people | filter:{name:$viewValue} | limitTo:10" typeahead-template-url="customRatingTemplate.html" class="form-control" typeahead-on-select="$root.IsValidName = false;setPatientId($item);" required placeholder="Patient name">
	</div>


<script type="text/ng-template" id="customRatingTemplate.html">
    <a tabindex="-1">
    <div ng-bind-html="match.model.name"></div>
    <small ng-bind-html="match.model.email"></small>
    </a>
</script>
</div>
<div class="right_view_marketing col-md-8">
 <div class="form-group col-md-12">
	 <textarea name="editor1"></textarea>
    <script>
        CKEDITOR.replace( 'editor1' );
    </script>

</div>

<div class="col-md-12">
                <div class="all_patient_action">                            
                    <button type="submit" class="btn save-intense">Save</button>                          
                    <a href="patients.html"class="btn cancel-intense">Cancel</a>
                </div>
            </div>

</div>
</div>
</div>
</div>
</div>


