<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="portlet">                                        
	<div class="portlet-body flip-scroll shorting_table_area">
		<table class="table table-bordered table-striped table-condensed flip-content">
			<thead class="flip-content thead-default">
				<tr>
					<th class="srno"> Sr No <a ng-click="sort('srno')"><i class="fa fa-sort"></i></a> </th>
					<th class="date"> Date <a ng-click="sort('date')"><i class="fa fa-sort"></i></a> </th>
					<th class="status"> Status <a ng-click="sort('status')"><i class="fa fa-sort"></i></a> </th>
					<th class="to"> To <a ng-click="sort('to')"><i class="fa fa-sort"></i></a> </th>
					<th class="type"> Type <a ng-click="sort('type')"><i class="fa fa-sort"></i></a> </th>
					<th class="category"> Category <a ng-click="sort('category')"><i class="fa fa-sort"></i></a> </th>
					<th class="template"> Template <a ng-click="sort('template')"><i class="fa fa-sort"></i></a> </th>
					<th class="subject"> Subject <a ng-click="sort('subject')"><i class="fa fa-sort"></i></a> </th>
					<th class="options"> Options <a ng-click="sort('options')"><i class="fa fa-sort"></i></a> </th>
				</tr>
			</thead>
			<tbody>
				<tr ng-repeat="single_item in MarketingList" class="MarketingList_td">
					<td> {{ single_item.srno}} </td>
					<td> {{ single_item.date}} </td>                                                     
					<td> {{ single_item.status}} </td>                                                     
					<td> {{ single_item.to}} </td>                                                     
					<td> {{ single_item.type}} </td>                                                     
					<td> {{ single_item.category}} </td>                                                     
					<td> {{ single_item.template}} </td>                                                     
					<td> {{ single_item.subject}} </td>                                                                                            
					<td> Resend / Delete </td>                                                                                                     
			</tr>                                              
			</tbody>
		</table>
	</div>
</div></div>
</div>