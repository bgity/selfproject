<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="portlet-body">
	<div class="row"> 
		<form class="form-horizontal" valid-submit="" name="frmAddCalendarSetting" novalidate>           
			<div class="col-md-12">
			<div class="callender_show_design_all">
				<div class="addnewsection_calender"><button class="btn btn-danger" ng-click="isCollapsed = !isCollapsed">Add New Calendar Setting</button></div>
				
	<div class="callender_show_design">
		<form name="frmCalendarView" id="frmCalendarView"> 
			<label class="callender_show_text ">Calendar View</label>
			<div class="callender_show_select">
				<select class="bs-select form-control" name="calendar_view" id="calendar_view" ng-model="frm.calendar_view">
					<option value="">Select</option>
					<option value="default">Default</option>
					<option value="day">Day</option>
					<option value="week">Week</option>
					<option value="month">Month</option>
				</select> 
			</div>
			<div class="callender_show_btn"><button class="btn save-intense" ng-click="" type="submit">Save</button></div>
		</form>
	</div>
	</div>
				</br></br>
				<div collapse="isCollapsed" class="form-horizontal_marketing">
					<div class="form-group col-md-4 ">
						<label
							class="col-md-4 collasped_calendar_name">Branch</label>
						<div class="col-md-8">
							<select class="bs-select form-control" name="branch" id="branch" ng-model="frm.branch">
								<option value="">Select Branch </option>
								<option ng-repeat="branch in branchList" value="branch.value">{{ branch.text}}</option>
							</select> 
						</div>
					</div>
					<div class="col-md-12" >
						<table class="table table-bordered table-condensed flip-content">
							<thead class="flip-content thead-default">
								<tr>
									<th> Days </th>
									<th> Open / Closed </th>
									<th> Time </th>
								</tr>
							</thead>
							<tbody>
								<tr ng-repeat="day in week_days">
									<td class="inbox-small-cells col-md-2"><span><input type="checkbox" name="" class="mail-checkbox"></span>
									<span class="meal_checkbox_plan_meal"> {{day.text}} </span></td>
									<td class="col-md-5 margin_left_right"><select class="bs-select form-control" name="branch_status" id="branch_status" >
										<option value="">Select Type </option>
										<option value="0">Closed</option>
										<option value="1">Open</option>
										</select>
									</td>
									<td class="col-md-5">
										<div class="col-md-5">
											<div class="form-group form-md-line-input">
												<input id="timepicker4" class="form-control input-inline ng-pristine ng-valid ng-valid-required ng-touched" type="text" restrict-paste="" required="" placeholder="10:00 AM" ng-model="Appointment.StartTime" name="AppointmentStartTime">
																<span class="input-group-btn  time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
											</div>
										</div>
										<div class="col-sm-2 col-md-2 col-lg-2 allto_sec">
											 To 
										</div>
										<div class="col-md-5">
											<div class="form-group form-md-line-input">
												<input id="timepicker4" class="form-control input-inline ng-pristine ng-valid ng-valid-required ng-touched" type="text" restrict-paste="" required="" placeholder="10:00 AM" ng-model="Appointment.StartTime" name="AppointmentStartTime">
																<span class="input-group-btn  time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
											</div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
						<br>
						<div class="col-md-12">
                <div class="all_patient_action">              
		<button class="btn save-intense" ng-click="" type="submit">Save</button>
		</div> </div>
					</div>
				</div>
			</div>
		</form>
	</div>

			
    <form name="frmFollowup" id="frmFollowup">           
        <div class="form-body usersetting_area">
            <div class="row">
                <div class="col-md-12">
                    <div class="height-20"></div>               
                    <div class="portlet light bordered">
                        <div class="portlet-body collapse in" id="">   
                            <div class="col-md-12 no-space">
                                <uib-accordion close-others="true"> 
                                    <uib-accordion-group ng-repeat="branch in branchList" heading="{{branch.text}}">                   
									   <table class="table table-bordered table-striped table-condensed flip-content">
											<thead class="flip-content thead-default">
												<tr>
													<th> Days </th>
													<th> Open / Closed </th>
													<th> Time </th>
												</tr>
											</thead>
											<tbody>
												<tr ng-repeat="day in week_days">
													<td class="inbox-small-cells col-md-2"><span><input type="checkbox" name="" class="mail-checkbox"></span><span class="meal_checkbox_plan_meal"> {{day.text}}</span></td>
													<td class="col-md-5 margin_left_right"><select class="bs-select form-control" name="branch_status" id="branch_status" >
														<option value="">Select Type </option>
														<option value="0">Closed</option>
														<option value="1">Open</option>
														</select>
													</td>
													<td class="col-md-5">
														<div class="col-md-5 no-space">
											<div class="form-group form-md-line-input">
												<input id="timepicker4" class="form-control input-inline ng-pristine ng-valid ng-valid-required ng-touched" type="text" restrict-paste="" required="" placeholder="10:00 AM" ng-model="Appointment.StartTime" name="AppointmentStartTime">
																<span class="input-group-btn  time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
											</div>
										</div>
														<div class="col-sm-2 col-md-2 col-lg-2 allto_sec_saved">
											 To 
										</div>
														<div class="col-md-5 no-space">
											<div class="form-group form-md-line-input">
												<input id="timepicker4" class="form-control input-inline ng-pristine ng-valid ng-valid-required ng-touched" type="text" restrict-paste="" required="" placeholder="10:00 AM" ng-model="Appointment.StartTime" name="AppointmentStartTime">
																<span class="input-group-btn  time_all_sec">
                                <button type="button" class="btn btn-default">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </button>
								</span>
											</div>
										</div>
													</td>
												</tr>
											</tbody>
										</table>
										<div class="col-md-12">
                <div class="all_patient_action">              
		<button class="btn save-intense" ng-click="" type="submit">Save</button>
		</div> </div>
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </form>
	
</div>
</div>
</div>


