<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="portlet">                                        
	<div class="portlet-body flip-scroll">
        <div class="portlet-title">
			<div class="actions actionrole_settingpage">
				<a href="#" class="btn save-intense" ng-click="addNewGroup();"> Add User Role </a>
			</div>
		<form novalidate="" name="user_management_setting" class="ng-pristine ng-valid">
		<table class="table table-bordered table-striped table-condensed">
			<thead class="flip-content">
				<tr>
					<th width="10%"> Modules </th>
					<th ng-mouseenter="showEdit = true" ng-mouseleave="showEdit = false" ng-repeat="single_role in roles" class="role" width="{{table_width}}%"> 
					<div ng-init="currentIndex = $index" ng-hide="editingGroup && $root.editingGroupLock && currentIndex === $root.previousGroupIndex" class="rowHeight group-top-margin">
						 {{single_role.role_name}}
						<a ng-click="editGroup();"  ng-show="showEdit && $root.showEditOther;"><i class="fa fa-edit"></i></a>
					</div> </th>
				</tr>
			</thead>
			<tbody>
				<tr ng-repeat="single_module in listdata"><td colspan="{{total_roles}}" style="padding:0;">
				   <table width="100%" class="table">
					<tr>
						<td style="font-weight: bold;" width="10%"> {{ single_module.group }} </td>
						<td  width="{{table_width}}%" ></td>                                                     
					</tr>
					
					<tr ng-repeat="single_level in single_module.access_level" style="background: #FBFCFD;">
						<td width="10%" style="padding-left: 30px;border: 1px solid #e7ecf1;"> {{ single_level.name }} </td>
						<td  width="{{table_width}}%" style=" text-align: left;border: 1px solid #e7ecf1;" ng-repeat="single_role in roles"> <span><input type="checkbox" class="mail-checkbox"></span>  </td>
					</tr>
				   </table>
				</td></tr>				
			</tbody>
		</table>
		 <div class="col-md-12">
                <div class="all_patient_action">              
		<button class="btn save-intense" ng-click="" type="submit">Save</button>
		</div> </div>
		</form>
	</div>

	
</div>
</div></div></div>

<script type="text/ng-template" id="add-new-group">
    <div class="modal-header">
    <h3 class="modal-title col-md-11 no-space">Add a New User Role</h3>
    <a ng-click="cancel()" class="btn btn-icon-only btn-default col-md-1">
    <i class="fa fa-times"></i>
    </a>
    </div>
    <div class="modal-body">
    <form class="form-horizontal form-bordered" valid-submit="addGroup();" name="frmaddGroup" novalidate>
    <div class="form-body">
	<div class="form-group">
		<label class="control-label col-md-4">Status</label>
		<div class="col-md-8"><input type="checkbox" class="accordion-icn"></div>
	</div>
    <div class="form-group">
		<label class="control-label col-md-4">User Role Name</label>
		<div class="col-md-8">
			<input type="text" alphabets-only="" ng-maxlength="30" ng-minlength="2" required=""
			autocomplete="off"
			placeholder="Enter Group" ng-model="groupFrm.groupname"
			class="form-control input-inline input-medium ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-valid-minlength"
			name="groupname" id="groupname" only-names="" restrict-paste="">
			<div class="custom-error" ng-show="frmaddGroup.groupname.$invalid">
				<span ng-show="frmaddGroup.$submitted && frmaddGroup.groupname.$error.required" class="error ng-hide">Name is Required.</span>
				<span ng-show="frmaddGroup.groupname.$error.minlength" class="error ng-hide">Group name can accept minimum 2 characters.</span>
				<span ng-show="frmaddGroup.groupname.$error.maxlength" class="error ng-hide">Group name can accept maximum 30 characters.</span>
			</div>
		</div>
    </div>
    <div class="modal-footer">
    <button type="submit" value="Submit" class="btn green-meadow">Save</button>
    <button class="btn red-intense" ng-click="cancel()">Cancel</button>
    </div>
    </div>
    </form>
    </div>

</script>