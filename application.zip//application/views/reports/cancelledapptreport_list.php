<div class="page-head">
    <div class="container-fluid header_subfull_ttilename header_sub_sec">
        <div class="row">
            <div class="col-md-6 header_page_title_all">
                <div class="page-title">
                    <h1>
                        <span data-ng-bind="$state.current.data.pageTitle"></span>
                        <small data-ng-bind="$state.current.data.pageSubTitle"></small>
                    </h1>
                </div>
            </div>
            <div class="col-md-6 search_area_section">
                <div class="row">
                        <div class="col-md-12 no-space center-alignment">
                            <div class="input-group area_nextbtn_with_earch">
                                <input type="text" class="form-control global_search_area" name="typeahead_example_1"
                                       placeholder="Search" id="typeahead_example_1" ng-model="searchText">
                            </div>
							<div class="pull-right right-alignment header_right_align_area">
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/excel_file.png" class="filter_1_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/pdf_file.png" class="filter_3_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/print_file.png" class="filter_3_img">
                    </a>
                </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div class="page-content">
    <div class="container-fluid">
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="whitebg2">
                <div class="col-md-12 no-space">
                    <div class="form-group header_search_sec">
                        <label class="control-label" for="form_control_1">Show record all matches</label>
                        <select class="form-control" id="form_control_1">
                            <option value="Show all"> Show all</option>
                            <option value="">Option 1</option>
                            <option value="">Option 2</option>
                            <option value="">Option 3</option>
                            <option value="">Option 4</option>
                        </select>
                        <label class="control-label" for="form_control_1">Of the following criteria</label>
                    </div>
                </div>
                <div class="col-md-6 allfromgroup-sec selct-search-ara-box no-space"
                     ng-repeat="row in searchRows track by $index">
                    <div class="form-group form-md-line-input">
                        <div class="col-md-4">
                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" required
                                    name="nutritionistType" id="nutritionistType"
                                    ng-change="setAdvSearchOption($index, row.advSearchOption)"
                                    ng-model="row.advSearchOption">
                                <option value="">Select Type</option>
                                <option ng-repeat="newpatreportSrch in patientBillingSearchList"
                                        value="{{newpatreportSrch.srch_value}}">{{ newpatreportSrch.srch_text}}
                                </option>
                            </select>
                        </div>
                        <div class="col-md-8" ng-if="row.advSearchOption != 'programdate'">
                            <div class="col-md-11">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control"
                                           ng-change="setAdvSearchText($index, row.advSearchText)"
                                           ng-model="row.advSearchText">
                                </div>
                            </div>
                            <div class="col-md-1 no-space">
                                <span ng-click="removeCriteria($index)"><i
                                        class="fa fa-trash trash_with_search"></i></span>
                            </div>
                        </div>

                        <div class="col-md-8" ng-if="row.advSearchOption == 'programdate'">
                            <div class="col-md-4">
                                <select class="bs-select form-control ng-pristine ng-valid ng-touched" ng-model="dateSelected"
                                        ng-options="count.id as count.name for count in dateOption" ng-change="onchange(dateOption[dateSelected-1])">
                                </select>
                            </div>
                            <div class="col-md-7"> <div  ng-controller="DatepickerCtrl">
                                    <div class="form-group form-md-line-input">
                                        <input type="text" placeholder="Date of Birth"
                                               class="form-control input-inline"
                                               datepicker-popup="{{ format}}" is-open="opened.openedDob"
                                               datepicker-options="dateOptions" close-text="Close"
                                               ng-change="setAdvSearchDate($index, row.advSearchDate)"
                                               ng-model="row.advSearchDate">
                                    <span class="input-group-btn calendar_all_sec">
                                        <button type="button" class="btn btn-default"
                                                ng-click="open($event, 'openedDob')">
                                            <i class="glyphicon glyphicon-calendar"></i>
                                        </button>
                                    </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1 no-space">
                                <span ng-click="removeCriteria($index)"><i
                                        class="fa fa-trash trash_with_search"></i></span>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-12 border-top-patient_filter no-space">
						<div class="all_patient_action">
                            <a class="help-block btn save-intense" ng-click="addCriteria();">add another criteria</a>
                            <button type="button" class="help-block btn cancel-intense" ng-click="searchAll()"> Show Result </button>
                        </div>
						</div>
            </div>
        </div>
    </div>
    <div class="portlet">
        <div class="portlet-body flip-scroll shorting_table_area">
            <table class="table table-bordered table-striped table-condensed flip-content">
                <thead class="flip-content thead-default">
                    <tr>
                        <th class="name"> Name <a ng-click="sort('name')"><i class="fa fa-sort"></i></a></th>
                        <th class="nutritionist"> Nutritionist <a ng-click="sort('nutritionist')"><i class="fa fa-sort"></i></a></th>
                        <th class="branch"> Branch <a ng-click="sort('branch')"><i class="fa fa-sort"></i></a></th>
                        <th class="createdon"> Created On <a ng-click="sort('createdon')"><i class="fa fa-sort"></i></a></th>
                        <th class="reference"> Reference <a ng-click="sort('reference')"><i class="fa fa-sort"></i></a></th>
                        <th class="lastapp"> Last Appointment <a ng-click="sort('lastapp')"><i class="fa fa-sort"></i></a></th>
                        <th class="occupation"> Occupation <a ng-click="sort('occupation')"><i class="fa fa-sort"></i></a></th>
                        <th class="city"> City <a ng-click="sort('city')"><i class="fa fa-sort"></i></a></th>
                        <th class="country"> Country <a ng-click="sort('country')"><i class="fa fa-sort"></i></a></th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-repeat="patientbillreport in cancelledApptList">
                        <td>{{patientbillreport.name}}</td>
                        <td>{{patientbillreport.nutritionist}}</td>
                        <td>{{patientbillreport.branch}}</td>
                        <td>{{patientbillreport.created_on}}</td>
                        <td>{{patientbillreport.reference}}</td>
                        <td>{{patientbillreport.last_appointment}}</td>
                        <td>{{patientbillreport.occupation}}</td>
                        <td>{{patientbillreport.city}}</td>
                        <td>{{patientbillreport.country}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="pagi_wrap" ng-if="PatientBillingReportListTotal > itemsPerPage">
            <div class="dataTables_paginate paging_simple_numbers">
                <uib-pagination total-items="PatientBillingReportListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                                page="$parent.currentPage" boundary-links="true" max-size="3"
                                class="pagination-sm"></uib-pagination>
            </div>
        </div>
    </div>
</div>
        </div>
    </div>


