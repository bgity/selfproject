<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            Add Body Weight
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							  <div class="form-group ">
                                        <label class="col-md-4 control-label">Gender</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="female"  value="female" checked ng-model="frm.gender"> Female </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="male"  value="male" ng-model="frm.gender"> Male </label>
                                            </div>
											</div>
                                        </div>                                        
								</div>   
							<div class="form-group">
								<label class="control-label col-md-3">Height In Feet</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="name" id="name"
										ng-model="frm.name" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.name.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.name.$error.required">Name is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Height In Cm</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="serving" id="serving"
										ng-model="frm.serving" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.serving.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.serving.$error.required">Amt/Serving is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Height In Inches</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="protein" id="protein"
										ng-model="frm.protein" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.protein.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.protein.$error.required">Protein is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Height In Sq. Meter</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="fat" id="fat"
										ng-model="frm.fat" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.fat.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.fat.$error.required">Fat is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">I.B.W. FOR SMALL FRAME</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="cholestrol" id="cholestrol"
										ng-model="frm.cholestrol" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.cholestrol.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.cholestrol.$error.required">Cholestrol is Required.</span>
										</div>
									</div>
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="cholestrol" id="cholestrol"
										ng-model="frm.cholestrol" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.cholestrol.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.cholestrol.$error.required">Cholestrol is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">I.B.W. FOR MEDIUM FRAME </label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calorie" id="calorie"
										ng-model="frm.calorie" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calorie.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calorie.$error.required">Calorie is Required.</span>
										</div>
									</div>
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calorie" id="calorie"
										ng-model="frm.calorie" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calorie.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calorie.$error.required">Calorie is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">I.B.W. FOR LARGE FRAME</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calcium" id="calcium"
										ng-model="frm.calcium" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calcium.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calcium.$error.required">Calcium is Required.</span>
										</div>
									</div>
										<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calcium" id="calcium"
										ng-model="frm.calcium" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calcium.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calcium.$error.required">Calcium is Required.</span>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>