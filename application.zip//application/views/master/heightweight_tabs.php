<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
                <tr>
					<th class="age" rowspan="2"> Age <a ng-click="sort('age')"><i class="fa fa-sort"></i></a></th>
					<th colspan="3" style="border-bottom:#fff solid 2px; border-right:#fff solid 1px; text-align:center;">Boys</th>
					<th colspan="3" style="border-bottom:#fff solid 2px; text-align:center;">Girls</th>
				</tr>
				<tr>
                    
                    <th class="height"> Height(cms)  <a ng-click="sort('height')"><i class="fa fa-sort"></i></a></th>
                    <th class="weight"> Weight(kg)  <a ng-click="sort('weight')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
					<th class="height"> Height(cms)  <a ng-click="sort('height')"><i class="fa fa-sort"></i></a></th>
                    <th class="weight"> Weight(kg)  <a ng-click="sort('weight')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="(key, value) in HeightWeightList">
                    <td>{{key}}</td>
                    <td>{{value[0].height_in_cms }}</td>
                    <td>{{value[0].weight_in_kgs}}</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></td>
					<td>{{value[1].height_in_cms }}</td>
                    <td>{{value[1].weight_in_kgs}}</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>