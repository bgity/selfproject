<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                             Add Frame Size
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							  <div class="form-group ">
                                        <label class="col-md-4 control-label">Gender</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="boy"  value="boy" checked ng-model="frm.gender"> Boy </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="girl"  value="girl" ng-model="frm.gender"> Girl </label>
                                            </div>
											</div>
                                        </div>                                        
                            </div>   
							<div class="form-group">
								<label class="control-label col-md-3">Operator</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="operator" id="operator"
										ng-model="frm.operator" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.operator.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.operator.$error.required">Operator is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Value</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="value1" id="value1"
										ng-model="frm.value1" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.value1.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.value1.$error.required">Start Value is Required.</span>
										</div>
										
										<input type="text" class="form-control" name="value2" id="value2"
										ng-model="frm.value2" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.value2.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.value2.$error.required">End Value is Required.</span>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>