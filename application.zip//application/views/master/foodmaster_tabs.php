<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
               	<tr>
                    
                    <th class="food_groups"> Food Groups <a ng-click="sort('food_groups')"><i class="fa fa-sort"></i></a></th>
                    <th class="serving"> Amt/Serving <a ng-click="sort('serving')"><i class="fa fa-sort"></i></a></th>
                   <th class="protein"> Protein <a ng-click="sort('protein')"><i class="fa fa-sort"></i></a></th>
					<th class="fat"> Fat  <a ng-click="sort('fat')"><i class="fa fa-sort"></i></a></th>
                    <th class="cholestrol"> Cholestrol <a ng-click="sort('cholestrol')"><i class="fa fa-sort"></i></a></th>
                    <th class="calories"> Calories <a ng-click="sort('calories')"><i class="fa fa-sort"></i></a></th>
                    <th class="calcium"> Calcium <a ng-click="sort('calcium')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="food in FoodMasterList">
                   <td>
						{{food.name}}
						</td>
						<td class="text-center">
						{{food.weight_per_serving}}
						</td>
						<td class="text-center">
						{{food.prot_per_serving}}
						</td>
						<td class="text-center">
						{{food.fat_per_serving}}
						</td>
						<td class="text-center">
						{{food.chol_per_serving}}
						</td>
						<td class="text-center">
						{{food.calo_per_serving}}
						</td>
						<td class="text-center">
						{{food.calc_per_serving}}
						</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>