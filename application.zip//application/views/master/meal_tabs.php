<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
 				<tr>
                    <th class="name"> Name  <a ng-click="sort(name)"><i class="fa fa-sort"></i></a></th>
					<th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="meal in MealList">
					<td>{{meal.time}}</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>
</div>