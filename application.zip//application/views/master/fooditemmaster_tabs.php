<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
               	<tr>
                    
                    <th class="food_item"> Food Item <a ng-click="sort('food_item')"><i class="fa fa-sort"></i></a></th>
                    <th class="serving"> Category <a ng-click="sort('serving')"><i class="fa fa-sort"></i></a></th>
                   <th class="macro_nut"> Macro Nut <a ng-click="sort('macro_nut')"><i class="fa fa-sort"></i></a></th>
					<th class="calorie_calc_base"> Calorie Calc Base  <a ng-click="sort('calorie_calc_base')"><i class="fa fa-sort"></i></a></th>
                    <th class="calc_base"> Calc Base <a ng-click="sort('calc_base')"><i class="fa fa-sort"></i></a></th>
                    <th class="number"> Number <a ng-click="sort('number')"><i class="fa fa-sort"></i></a></th>
                    <th class="cup"> Cup <a ng-click="sort('cup')"><i class="fa fa-sort"></i></a></th>
                    <th class="gm"> Gm/Ml <a ng-click="sort('gm')"><i class="fa fa-sort"></i></a></th>
                    <th class="protein"> Protein <a ng-click="sort('protein')"><i class="fa fa-sort"></i></a></th>
                    <th class="fat"> Fat <a ng-click="sort('fat')"><i class="fa fa-sort"></i></a></th>
                    <th class="carbs"> Carbs <a ng-click="sort('carbs')"><i class="fa fa-sort"></i></a></th>
                    <th class="kcal"> Kcal <a ng-click="sort('kcal')"><i class="fa fa-sort"></i></a></th>
                    <th class="fibre"> Fibre <a ng-click="sort('fibre')"><i class="fa fa-sort"></i></a></th>
                    <th class="calcium"> Calcium <a ng-click="sort('calcium')"><i class="fa fa-sort"></i></a></th>
                    <th class="iron"> Iron <a ng-click="sort('iron')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="food in FoodItemList">
                  	<td>
						{{food.name}}
						</td>
						<td class="text-center">
						{{food.category}}
						</td>
						<td class="text-center">
						{{food.macro_nut}}
						</td>
						<td class="text-center">
						{{food.calorie_calc_base}}
						</td>
						<td class="text-center">
						{{food.calc_base}}
						</td>
						<td class="text-center">
						{{food.number_meas}}
						</td>
						<td class="text-center">
						{{food.cup_meas}}
						</td>
						<td class="text-center">
						{{food.gm_ml_meas}}
						</td>
						<td class="text-center">
						{{food.protein}}
						</td>
						<td class="text-center">
						{{food.fat}}
						</td>
						<td class="text-center">
						{{food.carbs}}
						</td>
						<td class="text-center">
						{{food.kcal}}
						</td>
						<td class="text-center">
						{{food.fibre}}
						</td>
						<td class="text-center">
						{{food.calcium}}
						</td>
						<td class="text-center">
						{{food.iron}}
						</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="TotalRecords > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="TotalRecords" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>