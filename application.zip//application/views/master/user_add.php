<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                             Add User
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							<div class="form-group">
								<label class="control-label col-md-3">Username</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="username" id="username"
										ng-model="frm.username" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.username.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.username.$error.required">Username is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Email</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="email" id="email"
										ng-model="frm.email" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.email.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.email.$error.required">Email is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Password</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="password" class="form-control" name="password" id="password"
										ng-model="frm.password" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.password.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.password.$error.required">Password is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Confirmed Password</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="password" class="form-control" name="conf_password" id="conf_password"
										ng-model="frm.conf_password" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.conf_password.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.conf_password.$error.required">Confirmed Password is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Role</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
											<select class="bs-select form-control" name="user_role" id="user_role" ng-model="frm.user_role">
                                                <option value="">Select Role </option>
                                                <option ng-repeat="role in roleList" value="role.value">{{ role.text}}</option>
                                            </select> 
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>