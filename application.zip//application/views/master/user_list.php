<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="whitebg">
                <div class="col-md-12 no-space">
                    <div class="form-group header_search_sec">
                        <label class="control-label" for="form_control_1">Show record all matches</label>

                        <select class="form-control" id="form_control_1">
                            <option value="Show all"> Show all</option>
                            <option value="">Option 1</option>
                            <option value="">Option 2</option>
                            <option value="">Option 3</option>
                            <option value="">Option 4</option>
                        </select>
                        <label class="control-label" for="form_control_1">Of the following criteria</label>
                    </div>
                </div>
                <div class="col-md-6 allfromgroup-sec selct-search-ara-box no-space"
                     ng-repeat="row in searchRows track by $index">
                    <div class="form-group form-md-line-input">
                        <div class="col-md-6">
                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" required
                                    name="nutritionistType" id="nutritionistType"
                                    ng-change="setAdvSearchOption($index, row.advSearchOption)"
                                    ng-model="row.advSearchOption">
                                <option value="">Select Type</option>
                                <option ng-repeat="programSrch in programsrcList"
                                        value="{{programSrch.srch_value}}">{{ programSrch.srch_text}}
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-11">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control"
                                           ng-change="setAdvSearchText($index, row.advSearchText)"
                                           ng-model="row.advSearchText">
                                </div>
                            </div>
                            <div class="col-md-1 no-space">
                                <span ng-click="removeCriteria($index)"><i
                                        class="fa fa-trash trash_with_search"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12  margin-10 no-space">
                    <div class="col-md-4">
                        <a class="help-block btn red-intense" ng-click="addCriteria();">add another criteria</a>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <button type="button" class="btn red-intense" ng-click="searchAll()">Show Result</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
        <uib-tabset>
            <uib-tab heading="Active" active="ActiveFlag" ng-click="getHeightWeightList('active')">
                <div ng-include="'master/usermasterTab'"></div>
            </uib-tab>
            <uib-tab heading="Inactive" active="InactiveFlag" ng-click="getHeightWeightList('inactive');">
                <div ng-include="'master/usermasterTab'"></div>
            </uib-tab>
        </uib-tabset>
    </div>
</div>
</div>
