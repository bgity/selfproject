<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
 				<tr>
                    
                    <th class="name"> Name  <a ng-click="sort(name)"><i class="fa fa-sort"></i></a></th>
                    <th class="email"> Email  <a ng-click="sort(email)"><i class="fa fa-sort"></i></a></th>
                    <th class="role"> Role  <a ng-click="sort(role)"><i class="fa fa-sort"></i></a></th>
					<th> Action</th>
                    
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="user in UserList">
					<td>{{user.username}}</td>
					<td class="text-center">{{user.email}}</td>
					<td class="text-center">
						<span ng-if="user.admin==1">Admin</span>
						<span ng-if="user.admin!=1">--</span>
					</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>
</div>