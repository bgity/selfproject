<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
				<tr>
                    <th class="short_desc"> Short Description <a ng-click="sort('short_desc')"><i class="fa fa-sort"></i></a></th>
                  	<th class="long_desc"> Long Description <a ng-click="sort('long_desc')"><i class="fa fa-sort"></i></a></th>
                  	<th class="created_on"> Created on <a ng-click="sort('created_on')"><i class="fa fa-sort"></i></a></th>
                  	<th class="edited_on"> Edited  on <a ng-click="sort('edited_on')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="foodpf in FoodPrefList">
					<td class="text-center">
						{{foodpf.sdesc}}
					</td>
					<td class="text-center">
						{{foodpf.ldesc}}
					</td>
					<td class="text-center">
						{{foodpf.created_date}}
					</td>
					<td class="text-center">
						{{foodpf.edited_date}}
					</td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>