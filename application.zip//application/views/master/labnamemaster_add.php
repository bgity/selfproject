<div class="page-content-inner allfromgroup-sec">
    <div class="row">
        <form class="form-horizontal" valid-submit="addProgramMaster()" name="frmlabadd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            {{title}}
                        </div>
                        <div class="actions">
                            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body form  padding-left-right">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-12 ">
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Name</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" name="lab_name" id="lab_name"
                                                       ng-model="frm.lab_name" ng-required="true">
                                                <div class="custom-error" ng-show="frmlabadd.lab_name.$invalid">
                                                    <span ng-show="frmlabadd.$submitted && frmlabadd.lab_name.$error.required">Lab Name is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                            class="col-md-3 control-label">Address</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <textarea class="form-control text_area_section" rows="3"
                                                          placeholder="Enter your Address" name="lab_address" id="lab_address"
                                                          ng-model="frm.lab_address" ng-required="true"></textarea>
                                                <div class="custom-error" ng-show="frmlabadd.lab_address.$invalid">
                                                    <span ng-show="frmlabadd.$submitted && frmlabadd.lab_address.$error.required">Address is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Pincode</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" name="lab_pincode" id="lab_pincode"
                                                       ng-model="frm.lab_pincode" ng-required="true">
                                                <div class="custom-error" ng-show="frmlabadd.lab_pincode.$invalid">
                                                    <span ng-show="frmlabadd.$submitted && frmlabadd.lab_pincode.$error.required">Pincode is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Status</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <select class="layout-style-option form-control input-sm" ng-model="frm.status"
                                                        name="status" id="status"
                                                        ng-options="statustype.statustypeId as statustype.statusType for statustype in statusTypes"
                                                        ng-required="true">
                                                    <option value="">Select Type</option>
                                                </select>
                                                <div class="custom-error" ng-show="frmlabadd.status.$invalid">
                                                    <span ng-show="frmlabadd.$submitted && frmlabadd.status.$error.required">Select status.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- personal info ends-->


            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
                <div class="height-20px"></div>
            </div>

        </form>
    </div>
</div>