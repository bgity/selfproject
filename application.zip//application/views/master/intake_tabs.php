<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
				<tr>
                    <th class="gender">Gender <a ng-click="sort('gender')"><i class="fa fa-sort"></i></a></th>
                  	<th class="age_limit"> Age Limit  <a ng-click="sort('age_limit')"><i class="fa fa-sort"></i></a></th>
                  	<th class="height_in_cm"> Height in Cm  <a ng-click="sort('height_in_cm')"><i class="fa fa-sort"></i></a></th>
                  	<th class="wt_kg">  Weight in Kgs <a ng-click="sort('wt_kg')"><i class="fa fa-sort"></i></a></th>
                  	<th class="kcal_day">  Kcal/Day <a ng-click="sort('kcal_day')"><i class="fa fa-sort"></i></a></th>
                  	<th class="kcal_kg">  Kcal/Kg <a ng-click="sort('kcal_kg')"><i class="fa fa-sort"></i></a></th>
                  	<th class="kcal_cm">   Kcal/Cm  <a ng-click="sort('kcal_cm')"><i class="fa fa-sort"></i></a></th>
                  	<th class="prot_day">   Prot gm/day  <a ng-click="sort('prot_day')"><i class="fa fa-sort"></i></a></th>
                  	<th class="prot_cm">   Prot gm/cm <a ng-click="sort('prot_cm')"><i class="fa fa-sort"></i></a></th>
                  	<th class="prot_kg">   Prot gm/kg <a ng-click="sort('prot_kg')"><i class="fa fa-sort"></i></a></th>
                  	<th class="calc_mg">   Calc mg/day <a ng-click="sort('calc_mg')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="intake in IntakeList">
					 <td>
                                        {{intake.gender}}
                                    </td>

                                    <td>
                                        {{intake.age_from}} - {{intake.age_to}}
                                    </td>
                                    <td>
                                        {{intake.height_in_cm}}
                                    </td>
                                    <td>
                                        {{intake.weight_in_kgs}} 
                                    </td>
                                    <td>
                                        {{intake.kcal_daily}}
                                    </td>
                                    <td>
                                        {{intake.kcal_per_kg}} 
                                    </td>

                                    <td>
                                        {{intake.kcal_per_cm}} 
                                    </td>

                                    <td>
                                        {{intake.prot_gram_per_day}} 
                                    </td>
                                    <td>
                                        {{intake.prot_gram_per_cm}} 
                                    </td>
                                    <td>
                                        {{intake.prot_gram_per_kg}} 
                                    </td>
                                    <td>
                                        {{intake.calc_mg_daily}} 
                                    </td>
                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>