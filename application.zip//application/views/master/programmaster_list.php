<div class="page-head">
    <div class="container-fluid header_subfull_ttilename header_sub_sec">
        <div class="row">
            <div class="col-md-2 header_page_title_all">
                <div class="page-title">
                    <h1>
                        <span data-ng-bind="$state.current.data.pageTitle"></span>
                        <small data-ng-bind="$state.current.data.pageSubTitle"></small>
                    </h1>
                </div>
            </div>
            <div class="col-md-10 search_area_section">
                <div class="row">
                    <div class="col-md-8 no-space">
                        <div class="col-md-12 no-space center-alignment">
                            <div class="input-group area_nextbtn_with_earch">
                                <input type="text" class="form-control global_search_area" name="typeahead_example_1"
                                       placeholder="Search" id="typeahead_example_1" ng-model="searchText">
                            </div>
                            <div class="form-group new_section_btn">
                                <div class="default_patient">
                                    <a class="btn" href="add-nutritionists.html"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 no-space pull-right right-alignment header_right_align_area">
                        <a class="filter_img" href="javascript:;">
                            <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/excel_file.png"
                                 class="filter_1_img">
                        </a>
                        <a class="filter_img" href="javascript:;">
                            <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/pdf_file.png"
                                 class="filter_3_img">
                        </a>
                        <a class="filter_img" href="javascript:;">
                            <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/print_file.png"
                                 class="filter_3_img">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="page-content">
    <div class="container-fluid">
        <div class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="whitebg">
                        <div class="col-md-12 no-space">
                            <div class="form-group header_search_sec">
                                <label class="control-label" for="form_control_1">Show record all matches</label>
                                <select class="form-control" id="form_control_1">
                                    <option value="Show all"> Show all</option>
                                    <option value="">Option 1</option>
                                    <option value="">Option 2</option>
                                    <option value="">Option 3</option>
                                    <option value="">Option 4</option>
                                </select>
                                <label class="control-label" for="form_control_1">Of the following criteria</label>
                            </div>
                        </div>
                        <div class="col-md-6 allfromgroup-sec selct-search-ara-box no-space"
                             ng-repeat="row in searchRows track by $index">
                            <div class="form-group form-md-line-input">
                                <div class="col-md-6">
                                    <select class="bs-select form-control ng-pristine ng-valid ng-touched" required
                                            name="nutritionistType" id="nutritionistType"
                                            ng-change="setAdvSearchOption($index, row.advSearchOption)"
                                            ng-model="row.advSearchOption">
                                        <option value="">Select Type</option>
                                        <option ng-repeat="prgSearch in ProgramMasterSearchList"
                                                value="{{prgSearch.srch_value}}">{{ prgSearch.srch_text}}
                                        </option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <div class="col-md-11">
                                        <div class="form-group form-md-line-input">
                                            <input type="text" class="form-control"
                                                   ng-change="setAdvSearchText($index, row.advSearchText)"
                                                   ng-model="row.advSearchText">
                                        </div>
                                    </div>
                                    <div class="col-md-1 no-space">
                                <span ng-click="removeCriteria($index)"><i
                                        class="fa fa-trash trash_with_search"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 border-top-patient_filter">
                            <div class="col-md-6"></div>
                            <div class="col-md-6">
                                <div class="col-md-6 no-space">
                                    <a class="help-block btn save-intense" ng-click="addCriteria();">add another
                                        criteria</a>
                                </div>
                                <div class="col-md-6  show_res_area">
                                    <div class="form-group">
                                        <button type="button" class="help-block btn red-intense" ng-click="searchAll()">
                                            Show Result
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="portlet">
                <div class="portlet-body flip-scroll">
                    <table class="table table-bordered table-striped table-condensed flip-content">
                        <thead class="flip-content thead-default">
                        <tr>
                            <th class="name"> Name <a ng-click="sort('name')"><i class="fa fa-sort"></i></a></th>
                            <th class="address"> Address <a ng-click="sort('address')"><i class="fa fa-sort"></i></a>
                            </th>
                            <th class="pincode"> Pincode <a ng-click="sort('pincode')"><i class="fa fa-sort"></i></a>
                            </th>
                            <th class="status"> Status <a ng-click="sort('status')"><i class="fa fa-sort"></i></a></th>
                            <th> Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr ng-repeat="branch in programMainMaster">
                            <td>{{branch.name}}</td>
                            <td>{{branch.address}}</td>
                            <td>{{branch.pincode}}</td>
                            <td>{{branch.status}}</td>
                            <td><a class="fa fa-edit" ng-click="editBranch();" tooltip-placement="bottom"
                                   tooltip="Edit Branch"></a>&nbsp;&nbsp;<a class="fa fa-trash"
                                                                            tooltip-placement="bottom"
                                                                            tooltip="Delete Branch"
                                                                            ng-click="delBranch();"></a></td>
                            <t
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="pagi_wrap" ng-if="branchListTotal > itemsPerPage">
                    <div class="dataTables_paginate paging_simple_numbers">
                        <uib-pagination total-items="branchListTotal" items-per-page="itemsPerPage"
                                        ng-model="currentPage"
                                        page="$parent.currentPage" boundary-links="true" max-size="3"
                                        class="pagination-sm"></uib-pagination>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



