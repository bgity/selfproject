<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                             Add Height Weight
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							  <div class="form-group ">
                                        <label class="col-md-4 control-label">Gender</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="boy"  value="boy" checked ng-model="frm.gender"> Boy </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="girl"  value="girl" ng-model="frm.gender"> Girl </label>
                                            </div>
											</div>
                                        </div>                                        
                            </div>   
							<div class="form-group">
								<label class="control-label col-md-3">Age in years</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="age" id="age"
										ng-model="frm.age" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.age.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.age.$error.required">Age is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Height in cms</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="height" id="height"
										ng-model="frm.height" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.height.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.height.$error.required">Height is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Weight in kg</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Weight is Required.</span>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>