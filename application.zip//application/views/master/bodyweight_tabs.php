<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
               	<tr>
                    <th class="gender"> Gender <a ng-click="sort('gender')"><i class="fa fa-sort"></i></a></th>
					<th class="height_in_feet"> Height in feet  <a ng-click="sort('height_in_feet')"><i class="fa fa-sort"></i></a></th>
					<th class="height_in_cm"> Height in cm  <a ng-click="sort('height_in_cm')"><i class="fa fa-sort"></i></a></th>
					<th class="height_in_meter"> Height in inches <a ng-click="sort('height_in_meter')"><i class="fa fa-sort"></i></a></th>
					<th class="gender"> Height in sq. meter <a ng-click="sort('gender')"><i class="fa fa-sort"></i></a></th>
					<th class="ibw_small"> I.B.W. FOR SMALL FRAME  <a ng-click="sort('ibw_small')"><i class="fa fa-sort"></i></a></th>
					<th class="ibw_medium">  I.B.W. FOR MEDIUM FRAME <a ng-click="sort('ibw_medium')"><i class="fa fa-sort"></i></a></th>
					<th class="ibw_large"> I.B.W. FOR LARGE FRAME <a ng-click="sort('ibw_large')"><i class="fa fa-sort"></i></a></th>
				
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="client in BodyWeightList">
                   <td>
                                        {{client.gender}}
                                    </td>

                                    <td>
                                        {{client.height_in_feet}}
                                    </td>
                                    <td>
                                        {{client.height_in_cm}}
                                    </td>
                                    <td>
                                        {{client.height_in_inches}} 
                                    </td>
                                    <td>
                                        {{client.height_in_meter}}
                                    </td>
                                    <td>
                                        {{client.bw_small_frame}} - {{client.bw_small_frame_maxval}}
                                    </td>

                                    <td>
                                        {{client.bw_medium_frame}} - {{client.bw_medium_frame_maxval}}
                                    </td>

                                    <td>
                                        {{client.bw_large_frame}} - {{client.bw_large_frame_maxval}}
                                    </td>

                    <td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="TotalRecords > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="TotalRecords" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>