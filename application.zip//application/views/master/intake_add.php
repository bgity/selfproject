<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                           Add Intake
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							  <div class="form-group ">
                                    <label class="col-md-4 control-label">Gender</label>
									<div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <div class="radio-list">
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="children"  value="children" checked ng-model="frm.gender"> Children </label>
												<label class="radio-inline">
                                                    <input type="radio" name="gender" id="boy"  value="boy" checked ng-model="frm.gender"> Male </label>
                                                <label class="radio-inline">
                                                    <input type="radio" name="gender" id="girl"  value="girl" ng-model="frm.gender"> Female </label>
                                            </div>
										</div>
                                    </div>                                        
                            </div>   
							<div class="form-group">
								<label class="control-label col-md-3">Age Limit</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="value1" id="value1"
										ng-model="frm.value1" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.value1.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.value1.$error.required">Age From is Required.</span>
										</div>
										
										<input type="text" class="form-control" name="Value2" id="Value2"
										ng-model="frm.Value2" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.Value2.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.Value2.$error.required">Age To is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Height in cms</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="height" id="height"
										ng-model="frm.height" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.height.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.height.$error.required">Height is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Weight in kg</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Weight is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Kcal per day</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Kcal per day is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Kcal per kg</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Kcal per kg is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Kcal per cm</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Kcal per cm is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Protein gram per day</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Protein gram per day is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Protein gram per cm</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Protein gram per cm is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Protein gram per kg
</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Protein gram per kg is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Calcium mg per day</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="weight" id="weight"
										ng-model="frm.weight" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.weight.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.weight.$error.required">Calcium mg per day is Required.</span>
										</div>
									</div>
								</div>
							</div>

							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>