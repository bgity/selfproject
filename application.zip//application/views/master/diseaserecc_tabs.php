<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table ">
					
					<tr>
					<td>
						<table class="table">
							<thead>	
						<!--<th ng-click="sort_by('disease_name');">
							Disease <span class="glyphicon sort-icon" ng-show="predicate=='disease_name'" ng-class="{'glyphicon-chevron-down':reverse,'glyphicon-chevron-up':!reverse}"></span>
						</th>-->
						<th class="text-center" width="60%">
							Recommendation
						</th>
						<th class="text-center">
							Created on
						</th>
						<th class="text-center">
							Edited on
						</th>
						
                        <th class="hidden-xs">
                            Action
                        </th>
						</thead>
					</table>
					</td>
					</tr>
					
					<tbody>
					<!--<tr ng-repeat="diseasr in filtered = (diseasrs | filter:search | orderBy : predicate :reverse) filter:customFilter">-->
					<tr>
						<td ><b>Acidity</b> 
						<table class="table ">
							<tr>
								<td width="60%">							
									 Have 1 glass of warm water with 5-6 drops of lime and 1 tsp honey on an empty stomach. 						
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
							</tr>
							<tr>
								<td width="60%">							
									 Avoid plums and prunes. 			
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
							</tr>
					  </table>
					  </td>		
					</tr>
					<tr>
						<td ><b>Anemia</b> 
						<table class="table ">
							<tr>
								<td width="60%">							
									Include iron supplement. 					
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
							</tr>
							<tr>
								<td width="60%">							
									Have 2-3 dates daily. 			
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td class="text-center">
								29-09-2015 
								</td>
								<td><i class="fa fa fa-edit"></i>&nbsp;<i class="fa fa-trash trash_with_search"></i></i></td>
							</tr>
					  </table>
					  </td>		
					</tr>
					</tbody>
					</table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>