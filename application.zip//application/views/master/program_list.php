<div class="page-head">
    <div class="container-fluid header_subfull_ttilename header_sub_sec">
        <div class="row">
            <div class="col-md-6 header_page_title_all">
                <div class="page-title">
                    <h1>
                        <span data-ng-bind="$state.current.data.pageTitle"></span>
                        <small data-ng-bind="$state.current.data.pageSubTitle"></small>
                    </h1>
                </div>
            </div>
            <div class="col-md-6 search_area_section">
                 <div class="row">
                    <div class="col-md-12 no-space center-alignment">
                        <div class="input-group area_nextbtn_with_earch">
                            <input type="text" class="form-control global_search_area" name="typeahead_example_1"
                                   placeholder="Search" id="typeahead_example_1" ng-model="searchText">
                        </div>
                        <div class="form-group new_section_btn">
                            <div class="default_patient">
                                <a class="btn"  ng-click="addProgram();"></a>
                            </div>
                        </div>
						<div class="pull-right right-alignment header_right_align_area">
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/excel_file.png" class="filter_1_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/pdf_file.png" class="filter_3_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="<?php echo base_url(); ?>assets/layouts/layout/self-images/print_file.png" class="filter_3_img">
                    </a>
                </div>
                    </div>
                 </div>
            </div>
        </div>
    </div>
</div>
<div class="page-content">
    <div class="container-fluid">
        <div class="content">
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="whitebg">
                <div class="col-md-12 no-space">
                    <div class="form-group header_search_sec">
                        <label class="control-label" for="form_control_1">Show record all matches</label>
                        <select class="form-control" id="form_control_1">
                            <option value="Show all"> Show all</option>
                            <option value="">Option 1</option>
                            <option value="">Option 2</option>
                            <option value="">Option 3</option>
                            <option value="">Option 4</option>
                        </select>
                        <label class="control-label" for="form_control_1">Of the following criteria</label>
                    </div>
                </div>
                <div class="col-md-6 allfromgroup-sec selct-search-ara-box no-space"
                     ng-repeat="row in searchRows track by $index">
                    <div class="form-group form-md-line-input">
                        <div class="col-md-6">
                            <select class="bs-select form-control ng-pristine ng-valid ng-touched" required
                                    name="nutritionistType" id="nutritionistType"
                                    ng-change="setAdvSearchOption($index, row.advSearchOption)"
                                    ng-model="row.advSearchOption">
                                <option value="">Select Type</option>
                                <option ng-repeat="prgSearch in ProgramMasterSearchList"
                                        value="{{prgSearch.srch_value}}">{{ prgSearch.srch_text}}
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-11">
                                <div class="form-group form-md-line-input">
                                    <input type="text" class="form-control"
                                           ng-change="setAdvSearchText($index, row.advSearchText)"
                                           ng-model="row.advSearchText">
                                </div>
                            </div>
                            <div class="col-md-1 no-space">
                                <span ng-click="removeCriteria($index)"><i
                                        class="fa fa-trash trash_with_search"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                 <div class="col-md-12 border-top-patient_filter no-space">
						<div class="all_patient_action">
                            <a class="help-block btn save-intense" ng-click="addCriteria();">add another criteria</a>
                            <button type="button" class="help-block btn cancel-intense" ng-click="searchAll()"> Show Result </button>
                        </div>
						</div>
            </div>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
        <uib-tabset>
            <uib-tab heading="Active" active="programActiveFlag" ng-click="getProgramList('active')">
                <div ng-include="'Master/programtabList'"></div>
            </uib-tab>
            <uib-tab heading="Inactive" active="programInactiveFlag" ng-click="getProgramList('inactive');">
                <div ng-include="'Master/programtabList'"></div>
            </uib-tab>
        </uib-tabset>
    </div>
</div>
</div>
            </div>
        </div>
