<div class="page-content-inner allfromgroup-sec">
    <div class="row">
       <form class="form-horizontal" valid-submit="addHeightWeight()" name="frmheightweightdd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                             Add Food
                        </div>
						<div class="actions">
            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                <i class="fa fa-times"></i>
            </a>
        </div>
                        
                    </div>
				<div class="portlet-body form  padding-left-right">
					<div class="form-body">
						<div class="row">
							<div class="col-md-12 ">
							 
							<div class="form-group">
								<label class="control-label col-md-3">Name</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="name" id="name"
										ng-model="frm.name" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.name.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.name.$error.required">Name is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Amt/Serving</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="serving" id="serving"
										ng-model="frm.serving" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.serving.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.serving.$error.required">Amt/Serving is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Protein</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="protein" id="protein"
										ng-model="frm.protein" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.protein.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.protein.$error.required">Protein is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Fat</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="fat" id="fat"
										ng-model="frm.fat" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.fat.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.fat.$error.required">Fat is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Cholestrol</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="cholestrol" id="cholestrol"
										ng-model="frm.cholestrol" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.cholestrol.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.cholestrol.$error.required">Cholestrol is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Calorie</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calorie" id="calorie"
										ng-model="frm.calorie" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calorie.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calorie.$error.required">Calorie is Required.</span>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-md-3">Calcium</label>
								<div class="col-md-6">
									<div class="form-group form-md-line-input">
										<input type="text" class="form-control" name="calcium" id="calcium"
										ng-model="frm.calcium" ng-required="true">
										<div class="custom-error" ng-show="frmprogramadd.calcium.$invalid">
										<span ng-show="frmprogramadd.$submitted && frmprogramadd.calcium.$error.required">Calcium is Required.</span>
										</div>
									</div>
								</div>
							</div>
							 <div class="form-group">
                                        <label
                                            class="col-md-4 control-label">Food Preference</label>
                                        <div class="col-md-8">
										<div class="form-group form-md-line-input">
                                            <select class="bs-select form-control" name="food_preference" id="food_preference" ng-model="frm.food_preference">
                                                <option value="">Select Type </option>
                                                <option ng-repeat="meal in mealList" value="meal.value">{{ meal.text}}</option>
                                            </select> 
                                        </div>
										</div>
                                    </div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
            <!-- personal info ends-->
           
            
            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
				<div class="height-20px"></div>
            </div>
			
        </form>
    </div>
</div>