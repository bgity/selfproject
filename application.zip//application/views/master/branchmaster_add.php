<div class="page-content-inner allfromgroup-sec">
    <div class="row">
        <form class="form-horizontal" valid-submit="addProgramMaster()" name="frmprogramadd" novalidate>
            <!-- personal info starts-->
            <div class="col-md-12">
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            {{title}}
                        </div>
                        <div class="actions">
                            <a ng-click="cancel()" class="btn btn-icon-only btn-default">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body form  padding-left-right">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-12 ">
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Name</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" name="branch_name" id="branch_name"
                                                       ng-model="frm.branch_name" ng-required="true">
                                                <div class="custom-error" ng-show="frmprogramadd.branch_name.$invalid">
                                                    <span ng-show="frmprogramadd.$submitted && frmprogramadd.branch_name.$error.required">Branch name is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label
                                            class="col-md-3 control-label">Address</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <textarea class="form-control text_area_section" rows="3"
                                                          placeholder="Enter your Address" name="branch_address" id="branch_address"
                                                          ng-model="frm.branch_pincode" ng-required="true"></textarea>
                                                <div class="custom-error" ng-show="frmprogramadd.branch_address.$invalid">
                                                    <span ng-show="frmprogramadd.$submitted && frmprogramadd.branch_address.$error.required">Address is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Pincode</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <input type="text" class="form-control" name="branch_pincode" id="branch_pincode"
                                                       ng-model="frm.branch_pincode" ng-required="true">
                                                <div class="custom-error" ng-show="frmprogramadd.branch_pincode.$invalid">
                                                    <span ng-show="frmprogramadd.$submitted && frmprogramadd.branch_pincode.$error.required">Pincode is Required.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Status</label>
                                        <div class="col-md-6">
                                            <div class="form-group form-md-line-input">
                                                <select class="layout-style-option form-control input-sm" ng-model="frm.status"
                                                        name="status" id="status"
                                                        ng-options="statustype.statustypeId as statustype.statusType for statustype in statusTypes"
                                                        ng-required="true">
                                                    <option value="">Select Type</option>
                                                </select>
                                                <div class="custom-error" ng-show="frmprogramadd.status.$invalid">
                                                    <span ng-show="frmprogramadd.$submitted && frmprogramadd.status.$error.required">Select branch status.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- personal info ends-->


            <div class="col-md-12">
                <div class="form-actions text-center">
                    <button type="submit" class="btn green-meadow">Save</button>
                    <a href="programmaster-list.html" class="btn grey-cascade"  ng-click="cancel()">Cancel</a>
                </div>
                <div class="height-20px"></div>
            </div>

        </form>
    </div>
</div>