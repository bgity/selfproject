<div class="modal-header">
    <h3 class="modal-title col-md-11 no-space">{{title}}</h3>
    <a ng-click="cancel()" class="btn btn-icon-only btn-default">
        <i class="fa fa-times"></i>
    </a>
</div>
<div class="modal-body">
    <form class="form-horizontal form-bordered" valid-submit="addGroup();" name="frmaddGroup" novalidate>
        <div class="form-body">
            <div class="form-group required" >
                <label class="control-label col-md-4">Group Name</label>
                <div class="col-md-8">
                    <div class="form-group form-md-line-input">
                    <input type="text" alphabets-only="" ng-maxlength="30" ng-minlength="2" required=""
                           autocomplete="off"
                           placeholder="Enter Group" ng-model="groupFrm.groupname"
                           class="form-control input-inline input-medium ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-valid-minlength"
                           name="groupname" id="groupname" only-names="" restrict-paste="">
                    <div class="custom-error" ng-show="frmaddGroup.groupname.$invalid">
                        <span ng-show="frmaddGroup.$submitted && frmaddGroup.groupname.$error.required" class="error ng-hide">Name is Required.</span>
                        <span ng-show="frmaddGroup.groupname.$error.minlength" class="error ng-hide">Group name can accept minimum 2 characters.</span>
                        <span ng-show="frmaddGroup.groupname.$error.maxlength" class="error ng-hide">Group name can accept maximum 30 characters.</span>
                    </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" value="Submit" class="btn green-meadow">Save</button>
                <button class="btn red-intense" ng-click="cancel()">Cancel</button>
            </div>
        </div>
    </form>
</div>