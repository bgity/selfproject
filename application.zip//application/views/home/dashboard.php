<!--<tabset>
	<tab heading="My Dashboard">Static content</tab>
	<tab heading="My Patients">Static content</tab>
	<tab heading="My Tasks">Static content</tab>
	<tab heading="Activity">Static content</tab>
	<tab heading="Notifications">Static content</tab>
	<tab heading="Inbox">Static content</tab>
</tabset>

<div class="portlet-title text-center">
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_dashboard'; selectedTab='my_dashboard';">My Dashboard</a>
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_patients'; selectedTab='my_dashboard';">My Patients</a>
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_dashboard'; selectedTab='my_dashboard';">My Tasks</a>
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_dashboard'; selectedTab='my_dashboard';">Activity</a>
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_dashboard'; selectedTab='my_dashboard';">Notifications</a>
	<a class="btn btn-primary grey" ng-class="{'red':selectedTab === 'my_dashboard'}" ng-click="selectedTemplate.path = 'home/my_dashboard'; selectedTab='my_dashboard';">Inbox</a>
</div>-->
<div class="portlet-body form">
	<div class="form-wizard">
		<div class="form-body">
			<div ng-include="selectedTemplate.path"></div>
		</div>
	</div>
</div>
				