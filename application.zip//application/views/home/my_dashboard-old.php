<div class="row margin-bottom-20">
<div class="white_tiels">
                        <div class="col-md-2 no-space self_no_padding">
                            <!-- BEGIN Active Patients THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-blue">
                                            <tr>
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/activate_patient.png"class="right-alignment"></td>
                                                <td class="numeric white"> 
												<div class="left-alignment tiles-nmbr">50 </div>
												<div class="left-alignment">Active Patients</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END Active Patients THUMB -->
</div>
                        <div class="col-md-2 no-space self_no_padding">
                            <!-- BEGIN New Patients THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-green">
                                            <tr class="white">
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/new_patient.png"class="right-alignment"></td>
                                                <td class="numeric white">
												<div class="left-alignment tiles-nmbr">40</div>
												<div class="left-alignment">New Patients</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END New Patients THUMB -->
</div>
                        <div class="col-md-2 no-space self_no_padding">
                            <!-- BEGIN Collections THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-magenta">
                                            <tr>
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/collation.png"class="right-alignment"></td>
                                                <td class="numeric white"> 
												<div class="left-alignment tiles-nmbr">35 </div>
												<div class="left-alignment">Collections</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END Collections THUMB -->
</div>
                        <div class="col-md-2 no-space self_no_padding">
                            <!-- BEGIN Outstanding THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-hardblue">
                                            <tr>
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/outstanding.png"class="right-alignment"></td>
                                                <td class="numeric white"> 
												<div class="left-alignment tiles-nmbr">80 </div>
												<div class="left-alignment">Outstanding</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END Outstanding THUMB -->
</div>
						<div class="col-md-2 no-space self_no_padding">
                            <!-- BEGIN Missed Appointments THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-self">
                                            <tr>
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/appointment.png"class="right-alignment"></td>
                                                <td class="numeric white"> 
												<div class="left-alignment tiles-nmbr"> 100 </div>
												<div class="left-alignment">Missed Appointments</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END Missed Appointments THUMB -->
</div>
						<div class="col-md-2 no-space">
                            <!-- BEGIN Graph THUMB -->
                            <table class="table table-striped table-condensed center-alignment white">
                                       <tbody class="border-bottom-last-graph">
                                            <tr>
                                               <td class="center-alignment white"> <img src="assets/layouts/layout/self-images/map.png"class="right-alignment"></td>
                                                <td class="numeric white">
												<div class="left-alignment tiles-nmbr">35 </div> 
												<div class="left-alignment">Graph</div>
												</td>
                                            </tr>
                                        </tbody>
</table>
                            <!-- END Graph THUMB -->
</div>
                    </div>
                    </div>

<div style="display:none;top:60px;" id="my_form" class="ng-scope" onload="init()">
	<div class="" style="background:#e35b5a;padding:1px">
		<h5 style="color:white;margin-left:10px;">
		<b class="ng-binding">Create Appointment</b>
		<a style="color: white;" ng-click="Cancel()">
		<i class="fa fa-times pull-right control-group margin-right-5"></i>
		</a>
		</h5>
	</div>
	<div class="col-lg-12 col-md-12 col-sm-12 pad-0" style="height:480px;overflow:auto">
		<div class="col-lg-8 col-md-8 col-sm-8 pad-top-10 pad-0" style="float: left;">
		<form class="form-horizontal ng-pristine ng-invalid ng-invalid-required" ng-init="init();submitted=false;" role="form" novalidate="" name="SchedAppointmentForm">
				<div class="form-group">
					<label class="col-md-3 control-label">Patient</label>
					<div class="col-sm-7 col-md-7 col-lg-7">
						<input type="text" name="PatientName" id="PatientName" ng-disabled="editable" typeahead-editable="true" ng-model="Appointment.PatientName" typeahead="refer.name for refer in people | filter:{name:$viewValue} | limitTo:10" typeahead-template-url="customRatingTemplate.html" class="form-control" typeahead-on-select="$root.IsValidName = false;setPatientId($item);" ng-blur="IsValidName(Appointment,$root.isCPCollapsed);" ng-focus="$root.IsValidName = false" required placeholder="Patient name">
                         <input type="hidden" id="PatientId" name="PatientId"  ng-model="Appointment.PatientId" required  />
 
                                <div class="col-lg-12 col-sm-12 col-md-12 pad-top-0" >
                                    <a ng-if="mode === 'Create'"  class="active-item " style="margin-left:-14px;" href="#" ng-click="$root.isCPCollapsed=!$root.isCPCollapsed;$root.newPatientInit(Appointment);IsValidName(Appointment,$root.isCPCollapsed);" prevent-click><span ng-if="!$root.isCPCollapsed">new patient</span><span ng-if="$root.isCPCollapsed">cancel</span></a>
                                    <div ng-init="$root.isCPCollapsed=false" collapse="!$root.isCPCollapsed" class="text-center pad-right-0 cpModal" style="margin-left:-14px;">
                                      <!--  <div class="" ng-include="'../appointment/SchCreateNewPatient.html'"></div>-->
                                    </div>
                                </div>                                
                                
                                <span class="error" ng-show="submitted && SchedAppointmentForm.PatientName.$error.required">Patient is required.</span>
                                <span class="error" ng-show="$root.IsValidName && !SchedAppointmentForm.PatientName.$error.required">Invalid patient name.</span>
                            </div>
				</div>
				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" style="margin-top: -5px;" for="gender"></span>
					<div class="col-sm-7 col-md-7 col-lg-7" style="width: 180px;">
					<dd>
					<label class="new-ui-radio" style="width: 75px;">
					<input id="rdoM" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" value="Male" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Male</span>
					</label>
					<label class="new-ui-radio" style="width: 66px;">
					<input id="rdoF" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" checked="" value="Female" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Female</span>
					</label>
					</dd>
					<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.gender.$error.required" style="float: left;">Gender is required</span>
					</div>
				</div>

				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mealType">Meal Type</span>
					<div class="col-sm-7 col-md-7 col-lg-7">
					<select class="form-control dropdownHeight ng-pristine ng-valid ng-valid-required" ng-required="$root.isCPCollapsed==true" ng-model="Appointment.MealType" name="mealtype" required="required">
					<option style="display: none;" selected="" disabled="" value="">Select Meal Type</option>
					<option class="ng-scope ng-binding" value="UNKNOWN" >UNKNOWN</option>
					<option class="ng-scope ng-binding" value="Vegetarian" >Vegetarian</option>
					<option class="ng-scope ng-binding" value="Jain Vegetarian">Jain Vegetarian</option>
					<option class="ng-scope ng-binding" value="Vegan">Vegan</option>
					<option class="ng-scope ng-binding" value="Eggetarian">Eggetarian</option>
					<option class="ng-scope ng-binding" value="Non Vegetarian">Non Vegetarian</option>
					</select>
					<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.mealtype.$error.required" style="float: left;">Meal type is required</span>
					</div>
				</div>
				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mobile">Mobile</span>
					<div class="col-sm-7 col-md-7 col-lg-7 datediv">
					<div class="input-group input-group-sm">
					<span class="input-group-addon">
					<i class="fa fa-phone icons_height_width"></i>
					</span>
					<input class="form-control ng-pristine ng-valid" type="text" only-selected="" restrict-paste="" mobile-number="" name="mobileno1" ng-model="Appointment.Mobile1">
					</div>
					<span class="error ng-hide" ng-show="SchedAppointmentForm.mobileno1.$error.mobile" style="float: left;">Invalid mobile number</span>
					</div>
				</div>

				<!--<div class="form-group">
					<label class="control-label col-md-3">Nutritionist</label>
					<div class="col-md-6">
						<ui-select ng-model="person.selected">
								<ui-select-match placeholder="Select a person in the list">{{$select.selected.name}}</ui-select-match>
								<ui-select-choices repeat="person in people | filter: $select.search">
									<div ng-bind-html="person.name"></div>
									<small ng-bind-html="person.email"></small>
								</ui-select-choices>
						</ui-select>
					</div>
				</div>-->
				
				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Nutritionist">Nutritionist</span>
					<div class="col-sm-7 col-md-7 col-lg-7">
						<select id="NutritionistId" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-change="selectBranch(Appointment.NutritionistId);IsAppointmentExist(Appointment)" ng-model="Appointment.NutritionistId" required="" name="NutritionistName" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Nutritionist</option>
						<option ng-repeat="oldcn in people | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.NutritionistName.$error.required">Nutritionist is required.</span>
					</div>
				</div>

				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Branch">Branch</span>
						<div class="col-sm-7 col-md-7 col-lg-7">
							<select id="Branch" class="form-control dropdownHeight" required="" name="Branch">
							<option style="display: none;" selected="" disabled="" value="">Select Branch</option>
							<option ng-repeat="branch in branchLists | orderBy:'Name'" value="{{branch.id}}">{{branch.name}}</option>
							</select>
							<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.Branch.$error.required">Branch is required.</span>
						</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Date</label>
					<div class="col-md-6">
						<div class="input-group date form_datetime">
							<input type="text" id="Sch_CreateDate" class="form-control" datepicker-popup="{{app_date_format}}" ng-model="Appointment.AppointmentDate" is-open="opened" min-date="minDate" max-date="" datepicker-options="dateOptions" date-disabled="disabled(date, mode)" ng-required="false" close-text="Close" />
							<span class="input-group-btn">
								<button type="button" class="btn btn-default" ng-click="open($event)">
									<i class="glyphicon glyphicon-calendar"></i>
								</button>
							</span>     
						</div>
						<!-- /input-group -->
					</div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Time</label>
					<div class="col-md-6">
                        <span class="col-sm-5 col-md-5 col-lg-5" style="padding: 0px;">
						<span class="input-group timediv">
						<input id="timepicker4" class="form-control input-small ng-pristine ng-animate ng-valid-remove ng-invalid-add ng-valid-required-remove ng-valid-remove-active ng-invalid ng-invalid-add-active ng-valid-required-remove-active ng-invalid-required" type="text" restrict-paste="" required="" placeholder="00:00 AM" ng-blur="IsAppointmentExist(Appointment); IsValidStrtTimeLimit(Appointment)" ng-focus="appointmentExist=false;IsStartTimeValid=false;IsEndTimeValid=false;" ng-model="Appointment.StartTime" style="width: 100%;" start-timepicker-scheduler="" name="AppointmentStartTime">
						<span class="input-group-addon" style="padding-left: 9px; padding-right: 11px;">
						</span>
						</span>
						</span>
						
						<span class="col-sm-2 col-md-2 col-lg-2" style="padding: 5px 5px 0px 5px; width: 11%;">
						<label for="to">To</label>
						</span>
						
						<span class="col-sm-5 col-md-5 col-lg-5" style="padding: 0px; width: 42%;">
						<span class="input-group timediv">
						<input id="timepicker3" class="form-control input-small ng-pristine ng-animate ng-valid-validtime ng-valid-remove ng-invalid-add ng-valid-required-remove ng-valid-remove-active ng-invalid ng-invalid-add-active ng-valid-required-remove-active ng-invalid-required" type="text" restrict-paste="" end-timepicker-scheduler="" required="" placeholder="00:00 AM" ng-blur="IsValidEndTimeLimit(Appointment)" ng-focus="IsStartTimeValid=false;IsEndTimeValid=false" ng-model="Appointment.EndTime" style="width: 100%;" name="AppointmentEndTime">
						<span class="input-group-addon" style="padding-left: 9px; padding-right: 11px;">
						<i class="fa fa-clock-o icons_height_width"></i>
						</span>
						</span>
						</span>
                     </div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Type</label>
					<div class="col-md-6">
						<select id="appointment_type" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-model="Appointment.AppointmentTypeID" required="" name="AppointmentType" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Appointment Type</option>
						<option ng-repeat="oldcn in typeList | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AppointmentType.$error.required">Attended By is required.</span>
						
					</div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Attended By</label>
					<div class="col-md-6">
						<select id="attended_by" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" " ng-model="Appointment.attended_by" required="" name="AttendedByName" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Person</option>
						<option ng-repeat="oldcn in people | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AttendedByName.$error.required">Attended By is required.</span>
					</div>
				</div>
				
				<div class="form-group">
					<div class="row col-sm-7 col-md-7 col-lg-7 col-sm-offset-3 col-md-offset-3 col-lg-offset-3" style="text-align: center;">
					<button class="btn red-intense" style="margin-bottom: 0.5%; margin-top: 0.5%; margin-right:0.5%;" ng-click="save(Appointment,SchedAppointmentForm.$valid);submitted=true;SchedAppointmentForm.AppointmentDate.$error.validDate=IsAppointmentDateValid(Appointment.AppointmentDate);" type="button">Save</button>
					<button class="btn btn-w-md btn-gap-v btn-default BodyFont" style="margin-bottom: 0.5%; margin-top: 0.5%;" ng-click="Cancel()" value="Cancel" type="button">Cancel</button>
					</div>
				</div>
		</form>
	</div>
	</div>

</div>

<script type="text/ng-template" id="customRatingTemplate.html">
   <a tabindex="-1">
	  <div ng-bind-html="match.model.name"></div>
	  <small ng-bind-html="match.model.email"></small>
   </a>
</script>

<div class="row margin-bottom-20">
<div class="col-md-7">
	<div dhx-scheduler data="events" style="height:700px; width:100%;">
		<div class="dhx_cal_prev_button">&nbsp;</div>
		<div class="dhx_cal_next_button">&nbsp;</div>
		<div class="dhx_cal_today_button"></div>
		<div class="dhx_cal_date"></div>
		<div class="dhx_cal_tab" name="day_tab" style="right:204px;"></div>
		<div class="dhx_cal_tab" name="week_tab" style="right:140px;"></div>
		<div class="dhx_cal_tab" name="month_tab" style="right:76px;"></div>    
	</div>
</div>
<div class="col-md-5">
	<!-- BEGIN PORTLET-->
	<div class="portlet light bordered tasks-widget">
		<div class="portlet-title">
			<div class="caption">
				<span class="caption-subject bold uppercase">MY TO DO</span>
				<span class="caption-helper">16 pending</span>			   
				<!-----<select class="bs-select form-control" ng-model="selectedItem.id" ng-change="updateValue()" ng-init="taskfilters" ng-options="s.id as s.name for s in taskfilters" name="taskfilters" ><option value='' disabled selected>Filter</option></select>-------->																
			</div>
			<div class="actions">
                                                <div class="btn-group">
                                                                        <button type="button" class="btn btn-default">Show all</button>
                                                                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false" >
                                                                            <i class="select_custom_icon"></i>
                                                                        </button>
                                                                        <ul class="dropdown-menu" role="menu">
                                                                            <li ng-click="updateValue('date')">
                                                                                <a href="javascript:;"> Order By Date </a>
                                                                            </li>
                                                                            <li ng-click="updateValue('incomplete')">
                                                                                <a href="javascript:;"> Incompleted </a>
                                                                            </li>
                                                                            <li ng-click="updateValue('complete')">
                                                                                <a href="javascript:;"> Completed </a>
                                                                            </li>
                                                                            <li class="divider"> </li>
                                                                            <li ng-click="updateValue('all')">
                                                                                <a href="javascript:;"> Show All </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
												
												<button class="btn red-intense" ng-click="add_task()">Add another Task to-do</button>
                                            </div>
		</div>
		<div class="scroller" style="height: 282px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
			<table class="table table-striped table-condensed">
                                        <thead class="flip-content">
                                            <tr>
                                                <th width="10%"> <img src="assets/layouts/layout/self-images/dustbin.png" class="dashboard-icons-to-do-list"> </th>
                                                <th> LIST </th>
                                                <th class="numeric"> DUE DATE </th>
                                                <th class="numeric"> TIME </th>
                                                
                                            </tr>
                                        </thead>
										
                                        <tbody ng-repeat="single_task in task_list" >
                                            <tr>
                                                <td> <label class="checkbox">
													<div class="checker" id="uniform-accordion_demo_toggle"><span class=""><input type="checkbox" id="accordion_demo_toggle" checked="" ng-model="oneAtATime" class="ng-valid ng-dirty ng-valid-parse ng-touched"></span></div> </label> </td>
                                                <td> {{single_task.name}} </td>
                                                <td class="numeric"> {{single_task.due_date}} </td>
                                                <td class="numeric"> {{single_task.time}} </td>
                                                
                                            </tr>
                                        </tbody>
						
                                    </table>
		   
		</div>
	</div>
	<!-- END PORTLET-->
</div>
</div>
<div class="row margin-bottom-20">
<div class="col-md-6">

										<div class="portlet light ">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <img src="assets/layouts/layout/self-images/activity.png" class="dashboard-icons-single">
                                                <span class="caption-subject bold">Acitivity</span>
												<span class="caption-helper activity-green">16</span>
                                            </div>
                                            
                                        </div>
                                        <div class="portlet-body">
                                            <table class="table table-hover table-striped no-bordered">
                                                <tbody><tr>
                                                    <td> Shwetal added another task </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 28 Days </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> Shwetal added new patient </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 18 Days </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
                                                  
                                            </tbody></table>
                                            
                                        </div>
                                    </div>

   <div class="portlet light ">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <img src="assets/layouts/layout/self-images/notification.png" class="dashboard-icons-single">
                                                <span class="caption-subject bold">Notification</span>
												<span class="caption-helper notification-magenta">16</span>
                                            </div>
                                            
                                        </div>
                                        <div class="portlet-body">
										
										<div class="scroller" style="height: 282px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                                            <table class="table table-hover table-striped no-bordered">
                                                <tbody><tr>
                                                    <td> Shwetal added another task </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 28 Days </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> Shwetal added new patient </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 18 Days </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
                                                  <tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr><tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td> Shwetal added new patient to all </td>
                                                    <td>
                                                        <div class="self_activity_days pull-right"> 5 Days </div>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                            </div>
                                        </div>
                                    </div>
	
	
</div>
<div class="col-md-6">
<div class="portlet light bordered tasks-widget">
<div class="portlet-title">
                                            <div class="caption">
                                                <img src="assets/layouts/layout/self-images/inbox.png" class="dashboard-icons-single">
                                                <span class="caption-subject bold">Inbox </span>
												<span class="caption-helper activity-green">16</span>
                                            </div>
                                            
                                        </div>
    <div class="inbox-body">
                                    
                                    <div class="inbox-content portlet-body"><table class="table table-striped table-advance table-hover">
    <thead>
        <tr>
            <th colspan="3">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox mail-group-checkbox"></span></div>
                <div class="btn-group input-actions">
                    <a class="btn btn-sm blue btn-outline dropdown-toggle sbold" href="javascript:;" data-toggle="dropdown"> Actions
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="javascript:;">
                                <i class="fa fa-pencil"></i> Mark as Read </a>
                        </li>
                        <li>
                            <a href="javascript:;">
                                <i class="fa fa-ban"></i> Spam </a>
                        </li>
                        <li class="divider"> </li>
                        <li>
                            <a href="javascript:;">
                                <i class="fa fa-trash-o"></i> Delete </a>
                        </li>
                    </ul>
                </div>
            </th>
            <th class="pagination-control" colspan="3">
                <span class="pagination-info"> 1-30 of 789 </span>
                <a class="btn btn-sm blue btn-outline">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="btn btn-sm blue btn-outline">
                    <i class="fa fa-angle-right"></i>
                </a>
            </th>
        </tr>
    </thead>
    <tbody >
        <tr class="unread" data-messageid="1">
            <td class="inbox-small-cells">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox"></span></div> </td>
            <td class="inbox-small-cells">
                <i class="fa fa-star"></i>
            </td>
            <td class="view-message hidden-xs"> Petronas IT </td>
            <td class="view-message "> New server for datacenter needed </td>
            <td class="view-message inbox-small-cells">
                <i class="fa fa-paperclip"></i>
            </td>
            <td class="view-message text-right"> 16:30 PM </td>
        </tr>
        <tr class="unread" data-messageid="2">
            <td class="inbox-small-cells">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox"></span></div> </td>
            <td class="inbox-small-cells">
                <i class="fa fa-star"></i>
            </td>
            <td class="view-message hidden-xs"> Daniel Wong </td>
            <td class="view-message"> Please help us on customization of new secure server </td>
            <td class="view-message inbox-small-cells"> </td>
            <td class="view-message text-right"> March 15 </td>
        </tr>
        <tr data-messageid="3">
            <td class="inbox-small-cells">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox"></span></div> </td>
            <td class="inbox-small-cells">
                <i class="fa fa-star"></i>
            </td>
            <td class="view-message hidden-xs"> John Doe </td>
            <td class="view-message"> Lorem ipsum dolor sit amet </td>
            <td class="view-message inbox-small-cells"> </td>
            <td class="view-message text-right"> March 15 </td>
        </tr>
        <tr data-messageid="4">
            <td class="inbox-small-cells">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox"></span></div> </td>
            <td class="inbox-small-cells">
                <i class="fa fa-star"></i>
            </td>
            <td class="view-message hidden-xs"> Facebook </td>
            <td class="view-message"> Dolor sit amet, consectetuer adipiscing </td>
            <td class="view-message inbox-small-cells"> </td>
            <td class="view-message text-right"> March 14 </td>
        </tr>
        <tr data-messageid="5">
            <td class="inbox-small-cells">
                <div class="checker"><span><input type="checkbox" class="mail-checkbox"></span></div> </td>
            <td class="inbox-small-cells">
                <i class="fa fa-star inbox-started"></i>
            </td>
            <td class="view-message hidden-xs"> John Doe </td>
            <td class="view-message"> Lorem ipsum dolor sit amet </td>
            <td class="view-message inbox-small-cells"> </td>
            <td class="view-message text-right"> March 15 </td>
        </tr>
        
    </tbody>
</table></div>
                                </div>
	</div>
 </div>
</div>


<script type="text/ng-template" id="customRatingTemplate.html">
   <a tabindex="-1">
	  <div ng-bind-html="match.model.name"></div>
	  <small ng-bind-html="match.model.email"></small>
   </a>
</script>

<script type="text/ng-template" id="add-new-task">
	<div class="modal-header">
		<h3 class="modal-title">Add a New Task</h3>
	</div>
	<div class="modal-body">
		<form action="#" class="form-horizontal form-bordered">
			<div class="form-body">
				<div class="form-group">
					<label class="col-md-3 control-label">Status</label>
					<div class="col-md-6">
						<ui-select ng-model="single_tasks_status.selected">
								<ui-select-match placeholder="Select status">{{$select.selected.title}}</ui-select-match>
								<ui-select-choices repeat="single_tasks_status in task_status | filter: $select.search">
									<div ng-bind-html="single_tasks_status.title"></div>
								</ui-select-choices>
						</ui-select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Description</label>
					<div class="col-md-6">
						<input type="text" class="form-control" name="description" id="maxlength_defaultconfig">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Due Date</label>
					<div class="col-md-6">
						<div class="input-group date form_datetime">
							<input type="text" class="form-control" datepicker-popup="{{format}}" ng-model="dt" is-open="opened" min-date="minDate" max-date="" datepicker-options="dateOptions" date-disabled="disabled(date, mode)" ng-required="true" close-text="Close" />
							<span class="input-group-btn">
								<button type="button" class="btn btn-default" ng-click="open($event)">
									<i class="glyphicon glyphicon-calendar"></i>
								</button>
							</span>     
						</div>
						<!-- /input-group -->
					</div>
                </div>
				<div class="form-group">
					<label class="control-label col-md-3">Assigned To</label>
					<div class="col-md-6">
						<ui-select ng-model="person.selected">
								<ui-select-match placeholder="Select a person in the list">{{$select.selected.name}}</ui-select-match>
								<ui-select-choices repeat="person in people | filter: $select.search">
									<div ng-bind-html="person.name"></div>
									<small ng-bind-html="person.email"></small>
								</ui-select-choices>
						</ui-select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Assign Client</label>
					<div class="col-md-6">
						<ui-select ng-model="client.selected">
								<ui-select-match placeholder="Select a person in the list">{{$select.selected.name}}</ui-select-match>
								<ui-select-choices repeat="client in people | filter: $select.search">
									<div ng-bind-html="client.name"></div>
									<small ng-bind-html="client.email"></small>
								</ui-select-choices>
						</ui-select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Assign Nutritionist</label>
					<div class="col-md-6">
						<ui-select ng-model="nutritionist.selected">
								<ui-select-match placeholder="Select a person in the list">{{$select.selected.name}}</ui-select-match>
								<ui-select-choices repeat="nutritionist in people | filter: $select.search">
									<div ng-bind-html="nutritionist.name"></div>
									<small ng-bind-html="nutritionist.email"></small>
								</ui-select-choices>
						</ui-select>
					</div>
				</div>
			</div>
		</form>
	</div>
	<div class="modal-footer">
		<button class="btn red-intense" ng-click="ok()">OK</button>
		<button class="btn red-intense" ng-click="cancel()">Cancel</button>
	</div>
</script>
