<?php include_once APPPATH.'/views/include/page-head.php'; ?>
<div class="page-content">
    <div class="container-fluid">
<div class="page-content-inner">
    <div class="row profile">
        <div class="col-md-12">
            <div class="self_page_nut">
                <div class="portlet-body">
                    <div class="tab-content">
                        <div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
							<div class="portlet-body profile_sec_all_nut">
								<div class="row">
								<div class="col-md-2 no-space all_sale_img_profile_area">
								<div class="list-unstyled profile-nav nutrition_pro_pic left_profile_area">
                                <img src="assets/layouts/layout/self-images/profile_picture.png" class="img-responsive pic-bordered" alt="">
								<div class="nameprofile_nutri"> Manoj Upadhyay </div>
                                </div>
									<div class="portlet sale-summary rightsection_nutrition left_profile_area white_self_nut">
                                                        <div class="portlet-title">
                                                            <div class="caption font-red sbold"> Sales Summary </div>
                                                            <div class="tools">
                                                                <a class="reload" href="javascript:;" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <ul class="list-unstyled">
                                                                <li>
                                                                    <span class="sale-info"> Active Patients
                                                                        <i class="fa fa-img-up"></i>
                                                                    </span>
                                                                    <span class="sale-num"> 10 </span>
                                                                </li>
                                                                <li>
                                                                    <span class="sale-info"> New Patients
                                                                        <i class="fa fa-img-down"></i>
                                                                    </span>
                                                                    <span class="sale-num"> 25 </span>
                                                                </li>
                                                                <li>
                                                                    <span class="sale-info"> Collections </span>
                                                                    <span class="sale-num"> 2377 </span>
                                                                </li>
																<li>
                                                                    <span class="sale-info"> Outstanding </span>
                                                                    <span class="sale-num"> 2377 </span>
                                                                </li>
																<li>
                                                                    <span class="sale-info"> Missed Appointments </span>
                                                                    <span class="sale-num"> 2377 </span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
													
									</div>
									<div class="col-md-10 right_profile_area no-space">
										
											 <div class="nutrition_profile_user"> 
											 <div class="mt-element-list">
                                        
                                        <div class="mt-list-container list-todo">
                                            
                                            <ul>
                                                <li class="mt-list-item">
                                                    
                                                    <div class="list-todo-item white_self_nut">
                                                        
                                                        <div class="task-list panel-collapse collapse in" id="task-1-1" aria-expanded="true">
                                                            <ul>
																<li class="task-list-item done">
                                                                    
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">DOB </div>
																		<div class="col-md-7"> 01/02/87 </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li> 
                                                                <li class="task-list-item done">
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Sex</div>
																		<div class="col-md-7"> Male </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li>
																
																<li class="task-list-item done">
                                                                    
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">DOJ </div>
																		<div class="col-md-7"> 01/02/2010 </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li> 
																
																<li class="task-list-item done">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Desgnation </div>
																		<div class="col-md-7"> Web Developer </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li> 
																
																<li class="task-list-item done">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Role </div>
																		<div class="col-md-7"> Doctor </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li> 
																
																<li class="task-list-item done">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Qualification </div>
																		<div class="col-md-7"> B. E. </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
																		
                                                                    </div>
                                                                </li> 
																
                                                                <li class="task-list-item">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Status</div>
																		<div class="col-md-7"> Single </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
                                                                    </div>
                                                                </li>
                                                                <li class="task-list-item">
                                                                    
                                                                    <div class="task-content">
                                                                      <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Branch </div>
																		<div class="col-md-7"> Juhu </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
																		
                                                                    </div>
                                                                </li>
																<li class="task-list-item done">
                                                                    
                                                                    <div class="task-content">
                                                                       <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">Some Text</div>
																		<div class="col-md-7"> Any thing </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
                                                                    </div>
                                                                </li>
																<li class="task-list-item done">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4  header_profile_sec">User Name</div>
																		<div class="col-md-7"> ManojUp7 </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
                                                                    </div>
                                                                </li>
																<li class="task-list-item">
                                                                    
                                                                    <div class="task-content">
                                                                        <div class="row">
																		
																		<div class="col-md-12 no-space">
																		<div class="namedetails">
																		<div class="col-md-4 header_profile_sec">Change Pass</div>
																		<div class="col-md-7"> ************* </div>
																		<div class="col-md-1 text-right">
                                                                        <a class="done" href="javascript:;">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                        <a class="pending" href="javascript:;">
                                                                            <i class="fa fa-close"></i>
                                                                        </a>
																		</div>
																		</div>
																		</div>
																		</div>
                                                                    </div>
                                                                </li>
																
                                                            </ul>
                                                            
                                                        </div>
                                                    </div>
                                                </li>
                                                
                                                
                                            </ul>
                                        </div>
                                    </div>
											
											 </div>
									</div>
										
									
								</div>
							</div>



                         </div>
                    </div>
                    <div class="clearfix margin-bottom-20"></div>
                </div>
            </div>
        </div>
    </div>
</div></div>
</div>

<script type="text/ng-template" id="reset-password">
	<div class="modal-header">
		<h3 class="modal-title">Reset Password</h3>
	</div>
	<div class="modal-body">
		<form action="#" class="form-horizontal form-bordered">
			<div class="form-body">
				<div class="form-group">
					<label class="col-md-3 control-label">Old Password</label>
					<div class="col-md-6">
					<input type="password" placeholder="Old Password" class="form-control input-inline input-medium"></div>
				</div>
				<div class="form-group">
					<label class="col-md-3 control-label">New Password</label>
					<div class="col-md-6">
					<input type="password" placeholder="New Password" class="form-control input-inline input-medium"></div>
				</div>
				<div class="form-group">
					<label class="col-md-3 control-label">Confirm <br/>Password</label>
					<div class="col-md-6">
						<input type="password" placeholder="Confirm Password"
							   class="form-control input-inline input-medium"></div>
				</div>
			</div>
		</form>
	</div>
	<div class="modal-footer">
		<button class="btn red-intense" ng-click="ok()">OK</button>
		<button class="btn red-intense" ng-click="cancel()">Cancel</button>
	</div>
</script>