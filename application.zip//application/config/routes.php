<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//html url starts
$route['(:any).html'] = 'home';
//html url ends

//url routing for base starts  
$route['dashboard']="home/dashboard";
$route['my-dashboard']="home/my_dashboard";
$route['my-patients']="home/my_patients";
$route['my_profile']="home/my_profile";
$route['my-appointments']="appointment/my_appointments";
$route['team-calendar']="appointment/team_calendar";

$route['patients']="patients";
$route['patients_add']="patients/patientsViews/patients_add";
$route['patient_details']="patients/patientsViews/patient_details";
$route['patients_snapshot']="patients/patientsViews/patients_snapshot";
$route['patients_followup']="patients/patientsViews/patients_followup";
$route['patients_meal_plans']="patients/patientsViews/patients_meal_plans";
$route['patient_meal_plan_options']="patients/patientsViews/patient_meal_plan_options";
$route['patients_documents']="patients/patientsViews/patients_documents";
$route['patients_comments']="patients/patientsViews/patients_comments";
$route['patients_message_history']="patients/patientsViews/patients_message_history";
$route['patients_popup/(:any)']="patients/patientsPopup/$1";
$route['patients_information']="patients/patientsViews/patients_information";
$route['patients_medical_history']="patients/patientsViews/patients_medical_history";
$route['patients_medical_history_diseases']="patients/patientsViews/patients_medical_history_diseases";
$route['patients_program']="patients/patientsViews/patients_program";
$route['patients_payment']="patients/patientsViews/patients_payment";
$route['patients_medication']="patients/patientsViews/medication";
$route['patients_labtest']="patients/patientsViews/labtest";
$route['patients_genetictest']="patients/patientsViews/genetictest";
$route['get_patients_list']="patients/getPatientsList";

$route['login']="login/index";
$route['nutritionists']="nutritionists";
$route['get_nutritionists_list']="nutritionists/getNutritionistsList";
$route['nutritionists_add']="nutritionists/nutritionstadd";
$route['nutritionists_details']="nutritionists/nutritionistsDetails";

$route['dietrecallmaster_list']="Master/dietrecallmasterList";
$route['branchmaster_list']="Master/branchMasterList";
$route['get_branch_list']="Master/getBranchList";
$route['labnamemaster_list']="Master/labNameMasterList";
$route['get_branch_list']="Master/getLabNameList";
$route['medicationmaster_list']="Master/medicationMasterList";
$route['program_list']="Master/programList";
$route['get_program_list']="Master/getProgramsList";

$route['programmaster_list']="Master/programMainMasterList";
$route['get_program_mainmaster']="Master/getProgramMainList";

$route['unitmaster_list']="Master/unitMasterList";
$route['get_unit_list']="Master/getUnitList";

$route['exercisemaster_list']="Master/exerciseMasterList";
$route['labtestmaster_list']="Master/labTestMasterList";
$route['genetictestmaster_list']="Master/geneticTestMasterList";
$route['anthropometricmaster_list']="Master/anthropometricMasterList";
$route['diagnosismaster_list']="Master/diagnosisMasterList";
$route['questionnairemaster_list']="Master/questionnaireMasterList";
$route['diseasesmaster_list']="Master/diseasesMasterList";
$route['programmaster_add']="Master/programAdd";

$route['newpatientreport_list']="Reports/newPatientReportList";
$route['get_newpatientreport_list']="Reports/getNewpatientReportList";
$route['patientbillingreport_list']="Reports/patientBillingReportList";
$route['get_patientbillingreport_list']="Reports/getPatientBillingList";

$route['revenuereport_list']="Reports/revenueReportList";
$route['get_revenue_list']="Reports/getRevenueReportList";

$route['outstanding_reports']="Reports/outstandingReportList";
$route['get_outstanding_list']="Reports/getOutstandingReportList";

$route['missedappointment_reports']="Reports/missedApptReportList";
$route['get_missedappt_list']="Reports/getMissedApptReportList";

$route['cancelledappointment_reports']="Reports/cancelledApptReportList";
$route['get_cancelledappt_list']="Reports/getCancelledApptReportList";


//url routing for base ends
$route['marketing-template']="marketing/marketing_template";
$route['marketing-listing']="marketing/marketing_listing";
$route['user-management-setting']="settings/user_management_setting";
$route['calendar-setting']="settings/calendar_setting";
