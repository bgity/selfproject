<div class="container-fluid all_side_space header_sub_sec">
    <!-- BEGIN PAGE TITLE -->
    <div class="row">
        <div class="col-md-2 header_page_title_all">
            <div class="page-title">
                <h1>
                    <span data-ng-bind="$state.current.data.pageTitle"></span>
                    <small data-ng-bind="$state.current.data.pageSubTitle"></small>
                </h1>
            </div>
        </div>
        <div class="col-md-10 search_area_section"
             ng-if="$state.current.name == 'patients' || $state.current.name == 'nutritionists' || $state.current.name == 'ProgramMaster'">
            <div class="row">
                <div class="col-md-8 no-space">
                    <div class="col-md-12 no-space center-alignment">
                        <div class="input-group area_nextbtn_with_earch">
                            <input type="text" class="form-control global_search_area" name="typeahead_example_1"
                                   placeholder="Search" id="typeahead_example_1" ng-model="searchText">
                        </div>
                        <div class="form-group new_section_btn">
                            <div ng-if="$state.current.name == 'patients'" class="default_patient">
                                <a class="btn" href="add-patient.html">Add a new</a>
                            </div>
                            <div ng-if="$state.current.name == 'nutritionists'" class="default_nutri">
                                <a class="btn" href="add-nutritionists.html">Add a new</a>
                            </div>
                            <div ng-if="$state.current.name == 'ProgramMaster'" class="default_nutri">
                                <a class="btn" ng-click="add_program();">Add a new</a>
                            </div>
                            <div ng-if="$state.current.name == 'ProgramMaster'" class="default_nutri">
                            <a class="btn" ng-click="add_program();">Advance Search</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div ng-if="$state.current.name == 'patients' || $state.current.name == 'nutritionists'" class="col-md-4 no-space pull-right right-alignment header_right_align_area">
                    <a class="filter_img" href="javascript:;">
                        <img src="http://localhost/selfcare/assets/layouts/layout/self-images/excel_file.png" class=="filter_1_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="http://localhost/selfcare/assets/layouts/layout/self-images/pdf_file.png" class=="filter_3_img">
                    </a>
                    <a class="filter_img" href="javascript:;">
                        <img src="http://localhost/selfcare/assets/layouts/layout/self-images/print_file.png" class=="filter_3_img">
                    </a>
                </div>
            </div>
        </div>
        <!-- END PAGE TITLE -->
    </div>
</div>