<!-- BEGIN POST-FOOTER -->
<div class="page-footer">
    <div class="container-fluid"> 2016 &copy; Appetals. All Rights Reserved. </div>
</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>
<!-- END POST-FOOTER -->