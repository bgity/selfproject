<!-- BEGIN HEADER TOP -->
<div class="page-header-top  mobile_self">
    <div class="container">
        <!-- BEGIN LOGO -->
        <div class="page-logo">
            <a href="dashboard.html">
                <img src="{{settings.layoutPath}}/img/self_care.png" alt="logo" class="logo-default"> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN RESPONSIVE MENU TOGGLER -->
        <a href="javascript:;" class="menu-toggler"></a>
        <!-- END RESPONSIVE MENU TOGGLER -->
        <!-- BEGIN TOP NAVIGATION MENU -->
        <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
                <!-- BEGIN NOTIFICATION DROPDOWN -->
                <!-- END INBOX DROPDOWN -->
                <!-- BEGIN USER LOGIN DROPDOWN -->
                <li class="dropdown dropdown-user dropdown-dark">
                    <a href="javascript:;" class="dropdown-toggle" dropdown-menu-hover data-toggle="dropdown" data-close-others="true">
                        <img alt="" class="img-circle" src="{{settings.layoutPath}}/img/avatar9.jpg">
                        <span class="username username-hide-mobile">Nick</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-default">
                        <li>
                            <a href="my-profile.html">
                                <i class="icon-user"></i> My Profile </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="icon-calendar"></i> My Calendar </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="icon-envelope-open"></i> My Inbox
                                <span class="badge badge-danger"> 3 </span>
                            </a>
                        </li>
                        <li>
                            <a href="todo">
                                <i class="icon-rocket"></i> My Tasks
                                <span class="badge badge-success"> 7 </span>
                            </a>
                        </li>
                        <li class="divider"> </li>
                        <li>
                            <a href="#">
                                <i class="icon-lock"></i> Lock Screen </a>
                        </li>
                        <li>
                            <a href="login.html">
                                <i class="icon-key"></i> Log Out </a>
                        </li>
                    </ul>
                </li>
                <!-- END USER LOGIN DROPDOWN -->                
            </ul>
        </div>
        <!-- END TOP NAVIGATION MENU -->
    </div>
</div>
<!-- END HEADER TOP -->
<!-- BEGIN HEADER MENU -->
<div class="container-fluid all_side_space">
    <div class="row"> 
        <div class="col-md-2">
            <a href="dashboard.html">
                <div class="center-logo">
                    <img src="{{settings.layoutPath}}/img/self_care.png" alt="logo" class="logo-default">
                </div> </a>
        </div>
        <div class="col-md-10 no-space no-sapce-with-fluid">
            <div class="page-header-menu">

                <!-- BEGIN MEGA MENU -->
                <!-- DOC: Apply "hor-menu-light" class after the "hor-menu" class below to have a horizontal menu with white background -->
                <!-- DOC: Remove dropdown-menu-hover and data-close-others="true" attributes below to disable the dropdown opening on mouse hover -->
                <div class="hor-menu red hor-menu-light">
                    <ul class="nav navbar-nav">
                        <li class="active">
                            <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown" href="">Dashboard</a>
                            <ul class="dropdown-menu">                                           
                                <li>
                                    <a href="dashboard.html" class="iconify">My Dashboard</a>
                                </li>
                                <li>
                                    <a href="my-patients.html" class="iconify">My Patients</a>
                                </li>
                            </ul>    
                        </li>
                        <li>
                            <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown" href="">Appointments</a>
                            <ul class="dropdown-menu">                                           
                                <li>
                                    <a href="team-calender.html" class="iconify">Team Calender</a>
                                </li>
                                <li>
                                    <a href="my-appointments.html" class="iconify">My Appointments</a>
                                </li>
                                <li>
                                    <a href="" class="iconify">Add New Appointment</a>
                                </li>
                                <li>
                                    <a href="" class="iconify">Missed Appointments</a>
                                </li>
                                <li>
                                    <a href="" class="iconify">Cancelled Appointments</a>
                                </li>
                            </ul>    
                        </li>
                        <li>
                            <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown" href="">Patients</a>                    
                            <ul class="dropdown-menu">                                           
                                <li>
                                    <a href="my-patients.html" class="iconify">My Patient List</a>
                                </li>
                                <li>
                                    <a href="patients.html" class="iconify">All Patients</a>
                                </li>
                                <li>
                                    <a href="new-patients.html" class="iconify">New Patients List</a>
                                </li>
                                <li>
                                    <a href="add-patient.html" class="iconify">Add a New Patient</a>
                                </li>
                            </ul>                                                           
                        </li>
                        <li>
                            <a href="nutritionists.html">Nutritionists</a>
                        </li>
                        <li>
                            <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown"
                               href="">Settings</a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" class="iconify">User Management</a>
                                </li>
                                <li>
                                    <a href="#" class="iconify">Calendar Settings</a>
                                </li>
                                <li class="dropdown-submenu ">
                                    <a href="javascript:;" class="nav-link nav-toggle ">
                                        Masters
                                        <span class="arrow"></span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="dietrecallmaster-list.html" class="iconify">Diet Recall</a>
                                        </li>
                                        <li>
                                            <a href="branchmaster-list.html" class="iconify">Branch</a>
                                        </li>
                                        <li>
                                            <a href="medicationmaster-list.html" class="iconify">Medication</a>
                                        </li>
                                        <li>
                                            <a href="labtestmaster-list.html" class="iconify">Lab Test</a>
                                        </li>
                                        <li>
                                            <a href="anthropometricmaster-list.html" class="iconify">Anthropometric</a>
                                        </li>
                                        <li class="dropdown-submenu ">
                                                <a href="javascript:;" class="nav-link nav-toggle">
                                                     Medical History
                                                    <span class="arrow"></span>
                                                </a>
                                                <ul class="dropdown-menu">
                                                    <li class="">
                                                        <a href="diagnosismaster-list.html" class="iconify"> Diagnosis </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="questionnairemaster-list.html" class="iconify"> Questionnaire </a>
                                                    </li>
                                                  </ul>
                                            </li>
                                        <li>
                                            <a href="programmaster-list.html" class="iconify">Program</a>
                                        </li>
                                        <li>
                                            <a href="exercisemaster-list.html" class="iconify">Exercise</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                            </ul>
                        </li>              
                        <li>
                            <a href="marketing.html">Marketing</a>
                        </li>               
                        <li>
                            <a href="reports.html">Reports</a>
                        </li>               
                    </ul>
                </div>
                <!-- END MEGA MENU -->
                <!-- BEGIN TOP NAVIGATION MENU -->
                <div class="top-menu hide_desktop_self">
                    <ul class="nav navbar-nav pull-right">
                        <!-- BEGIN NOTIFICATION DROPDOWN -->
                        <!-- END INBOX DROPDOWN -->
                        <!-- BEGIN USER LOGIN DROPDOWN -->
                        <li class="dropdown dropdown-user dropdown-dark iconify">
                            <a href="javascript:;" class="dropdown-toggle" dropdown-menu-hover data-toggle="dropdown" data-close-others="true">
                                <img alt="" class="img-circle" src="{{settings.layoutPath}}/img/avatar9.jpg">
                                <span class="username username-hide-mobile">Nick</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-default">
                                <li>
                                    <a href="my-profile.html">
                                        <i class="icon-user"></i> My Profile </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-calendar"></i> My Calendar </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-envelope-open"></i> My Inbox
                                        <span class="badge badge-danger"> 3 </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="todo">
                                        <i class="icon-rocket"></i> My Tasks
                                        <span class="badge badge-success"> 7 </span>
                                    </a>
                                </li>
                                <li class="divider"> </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-lock"></i> Lock Screen </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="icon-key"></i> Log Out </a>
                                </li>
                            </ul>
                        </li>
                        <!-- END USER LOGIN DROPDOWN -->                
                    </ul>
                </div>
                <!-- END TOP NAVIGATION MENU -->

            </div>
        </div>
    </div>
</div>
<!-- END HEADER MENU -->