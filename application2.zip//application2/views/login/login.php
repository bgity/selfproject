        <!-- BEGIN LOGIN -->
        <div class="page-logo">
            <a href="dashboard.html">
                <img src="{{settings.layoutPath}}/img/self_care.png" alt="logo" class="logo-default"> </a>
        </div>
        <div class="content">
            <!-- BEGIN LOGIN FORM -->
            <form class="login-form" action="dashboard.html" method="post" ng-show="showlogin">
                <h3 class="form-title">Login to your account</h3>
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
                    <span> Enter any username and password. </span>
                </div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                    <div class="input-icon">
                        <i class="fa fa-user"></i>
                        <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Username" name="username" /> </div>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password" /> </div>
                </div>
                <div class="form-actions">                    
                    <label class="checkbox"></label>
                    <button type="submit" class="btn green pull-right"> Login </button>
                </div>                
                <div class="forget-password">                    
                    <p>  <a href="javascript:;" ng-click="showlogin=false; showforgot=true;">Forgot Password</a></p>
                </div>                
            </form>
            <!-- END LOGIN FORM -->
            <!-- BEGIN FORGOT PASSWORD FORM -->
            <h3>{{ sent_message }}</h3>
            <button type="button" id="back-btn" class="btn grey-salsa btn-outline" ng-show="sent_message"  ng-click="showlogin=true; showforgot=false;sent_message='';"> Back </button>
            <form class="forget-form" ng-show="showforgot">
                <h3>Forget Password ?</h3>
                <p> Enter your e-mail address below to reset your password. </p>
                <div class="form-group">
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Email" name="email" /> </div>
                </div>
                <div class="form-actions">                   
                    <button type="button" id="back-btn" class="btn grey-salsa btn-outline"  ng-click="showlogin=true; showforgot=false;"> Back </button>
                    <button type="submit" class="btn green pull-right" ng-click="sendpassword()"> Reset Password </button>
                </div>
            </form>
            <!-- END FORGOT PASSWORD FORM -->            
        </div>
    
        <!-- END LOGIN -->