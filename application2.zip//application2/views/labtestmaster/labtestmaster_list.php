<div class="profile-content">
    <div class="row">
        <div class="col-md-4">
            <!-- BEGIN PORTLET -->
            <div class="portlet light bordered ">
                <div class="portlet-body padding-15" style="padding-top: 20px">
                    <p>This is a list of Lab Tests values that will be asked for when you take patient follow-ups.</p>
                    <p>The values are organized in groups. You can create any number of groups and values by clicking on
                        <b class="a-link">Add Group </b>or <b class="a-link">Add Item</b>
                    </p>
                    <p>Group and the value names displayed can be changed anytime. Groups and values cannot be deleted
                        if they are used in followups.
                    </p>
                    <p>The checkbox next to a value (or group) indicates that this value is active - meaning it will be
                        displayed as prompt when you take follow-ups. You can make a value active or inactive anytime.
                        Inactive values are not asked for when taking new followup (but they are displayed when you see
                        old follow-ups)
                    </p>
                    <p><strong>Note:</strong><br>
                        Default group is a system group and its values cannot be changed or deleted. But you can make
                        any value as InActive.
                    </p>
                </div>
            </div>
            <!-- END PORTLET -->
        </div>
        <div class="col-md-8">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <img src="assets/layouts/layout/self-images/inbox.png" class="dashboard-icons-single">
                        <span class="caption-subject bold">Lab Tests Master</span>
                    </div>
                    <div class="actions">
                        <a href="#" class="btn btn-circle green btn-outline btn-sm" ng-click="addNewGroup();"> Add
                            Group </a>
                    </div>
                </div>
                <div class="portlet-body padding-15">
                    <div ng-repeat="groups in labTestMasterList" class="dietRecallMasterList">
                        <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                            <div ng-mouseenter="showEdit = true" ng-mouseleave="showEdit = false">
                                <div class="accordion-icn hand-pointer" ng-click="collapse = !collapse">
                                    <i ng-class="{'fa fa-minus-square': !collapse, 'fa fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>
                                <div>
                                    <input type="checkbox" class="accordion-icn">
                                </div>
                                <div ng-init="currentIndex = $index"
                                     ng-hide="editingGroup && $root.editingGroupLock && currentIndex === $root.previousGroupIndex"
                                     class="rowHeight group-top-margin">
                                    <strong>{{ groups.group}}</strong>
                                    <!-- <a title="edit"
                                        ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(groups.IsSystem);setOldGroup(groups);"
                                        ng-show="showEdit && $root.showEditOther;">
                                         <i class="fa fa-edit"></i></a>-->
                                    <a ng-click="editGroup();"  ng-show="showEdit && $root.showEditOther;"><i class="fa fa-edit"></i></a>
                                    <a title="delete" ng-show="showEdit && $root.showEditOther;">
                                        <i class="fa fa-close"></i></a>
                                </div>

                            </div>
                        </form>
                        <div collapse="collapse" class="item-list">
                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <div ng-repeat="items in groups.item" ng-mouseenter="showItemEdit = true"
                                     ng-mouseleave="showItemEdit = false">
                                    <div
                                        ng-hide="editingItem && $root.editingItemLock && currentIndex === $root.previousItemIndex && currentParentIndex === $root.previousParentIndex"
                                        ng-init="currentIndex = $index; currentParentIndex = $parent.$index">
                                        <div>
                                            <input type="checkbox" class="accordion-icn">
                                        </div>
                                        {{items.name}}
                                        <!--<a title="edit"
                                           ng-click="editingItem = !items.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(items.IsSystem);setOldItem(items);showEditMessageForSystem(items.IsSystem,'Item')"
                                           ng-show="(!items.IsSystem) && showItemEdit  && $root.showEditOther;">
                                            <i class="fa fa-edit"></i></a>-->
                                        <a ng-click="editItem();"
                                           ng-show="(!items.IsSystem) && showItemEdit && $root.showEditOther;"><i
                                                class="fa fa-edit"></i></a>
                                        <a title="delete" ng-show="showItemEdit && $root.showEditOther;">
                                            <i class="fa fa-close"></i></a>
                                    </div>   
                                </div>
                            </form>
                        </div>
                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div class="div-margin">
                                <div
                                    ng-hide="addingItem && $root.addingItemLock && currentIndex === $root.previousItemIndex && currentParentIndex === $root.previousParentIndex"
                                    ng-init="currentIndex = $index;
                                                currentParentIndex = $parent.$index">
                                    <!--<a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       style="text-decoration: none;"><strong>Add Item</strong></a>-->
                                    <a ng-click="addGroupItem();" style="text-decoration: none;"><strong>Add
                                            Item</strong></a>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END PROFILE CONTENT --> 
<script type="text/ng-template" id="add-new-group">
    <div class="modal-header">
    <h3 class="modal-title col-md-11">Add a New Group</h3>
    <a ng-click="cancel()" class="btn btn-circle btn-icon-only btn-default col-md-1">
    <i class="fa fa-times"></i>
    </a>
    </div>
    <div class="modal-body">
    <form class="form-horizontal form-bordered" valid-submit="addGroup();" name="frmaddGroup" novalidate>
    <div class="form-body">
    <div class="form-group">
    <label class="control-label col-md-4">Group Name</label>
    <div class="col-md-8">
    <input type="text" alphabets-only="" ng-maxlength="30" ng-minlength="2" required=""
    autocomplete="off"
    placeholder="Enter Group" ng-model="groupFrm.groupname"
    class="form-control input-inline input-medium ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-valid-minlength"
    name="groupname" id="groupname" only-names="" restrict-paste="">
    <div class="custom-error" ng-show="frmaddGroup.groupname.$invalid">
        <span ng-show="frmaddGroup.$submitted && frmaddGroup.groupname.$error.required" class="error ng-hide">Name is Required.</span>
        <span ng-show="frmaddGroup.groupname.$error.minlength" class="error ng-hide">Group name can accept minimum 2 characters.</span>
        <span ng-show="frmaddGroup.groupname.$error.maxlength" class="error ng-hide">Group name can accept maximum 30 characters.</span>
    </div>
    </div>
    </div>
    <div class="modal-footer">
    <button type="submit" value="Submit" class="btn green-meadow">Save</button>
    <button class="btn red-intense" ng-click="cancel()">Cancel</button>
    </div>
    </div>
    </form>
    </div>

</script>