<div dhx-schedulerunit data="events | filter:search" style="height:800px; width:100%;">
        <div class="dhx_cal_prev_button">&nbsp;</div>
        <div class="dhx_cal_next_button">&nbsp;</div>
        <div class="dhx_cal_today_button"></div>
        <div class="dhx_cal_date"></div>    
</div>
<div style="display:none;" id="my_form" class="ng-scope portlet light poup_all_self_area" onload="init()">
	<div class="portlet-title">
		<div class="caption">
		<span class="caption-subject bold uppercase"> 
		        <b> Appointment</b>
		</span>
		</div>
		<div class="actions">
		<a ng-click="Cancel()" class="btn btn-circle btn-icon-only btn-default">
                                            <i class="fa fa-times"></i>
                                        </a>							
        </div>
	</div>
	<div class="portlet-body">
		<div class="col-md-12 pad-top-10 pad-0 col-xs-12" style="float: left;">
		<form class="form-horizontal ng-pristine ng-invalid ng-invalid-required" ng-init="init();submitted=false;" role="form" novalidate name="SchedAppointmentForm">
				<div class="form-group">
					<label class="col-md-3 control-label">Patient </label>
					<div class="col-sm-9 col-md-7 col-lg-7">
						<input type="text" name="PatientName" id="PatientName" ng-disabled="editable" typeahead-editable="true" ng-model="Appointment.PatientName" typeahead="refer.name for refer in people | filter:{name:$viewValue} | limitTo:10" typeahead-template-url="customRatingTemplate.html" class="form-control" typeahead-on-select="$root.IsValidName = false;setPatientId($item);DisplayPatientInfo(Appointment.PatientId);" ng-blur="IsValidName(Appointment,$root.isCPCollapsed);" ng-focus="$root.IsValidName = false" required placeholder="Patient name">
                         <input type="hidden" id="PatientId" name="PatientId"  ng-model="Appointment.PatientId" required  />
						<!-- <span class="error" ng-show="submitted && SchedAppointmentForm.PatientName.$error.required">Patient is required.</span>-->
						 </div>
                                <div class="col-lg-2 col-sm-2 col-md-2 pad-top-0" >
                                    <a ng-if="mode === 'Create'"  class="active-item btn red-intense pull-right" style="margin-left:-14px;" href="#" ng-click="$root.isCPCollapsed=!$root.isCPCollapsed;$root.newPatientInit(Appointment);IsValidName(Appointment,$root.isCPCollapsed);" prevent-click><span ng-if="!$root.isCPCollapsed">New patient</span><span ng-if="$root.isCPCollapsed">Cancel</span></a>
                                    <div ng-init="$root.isCPCollapsed=false" collapse="!$root.isCPCollapsed" class="text-center pad-right-0 cpModal" style="margin-left:-14px;">
                                      <!--  <div class="" ng-include="'../appointment/SchCreateNewPatient.html'"></div>-->
                                    </div>
                                </div>                   
				</div>				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" style="margin-top: -5px;" for="gender"></span>
					<div class="col-sm-7 col-md-7 col-lg-7" style="width: 180px;">
					<dd>
					<label class="new-ui-radio" style="width: 75px;">
					<input id="rdoM" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" value="Male" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Male</span>
					</label>
					<label class="new-ui-radio" style="width: 70px;">
					<input id="rdoF" class="ng-pristine ng-invalid ng-invalid-required" type="radio" ng-required="$root.isCPCollapsed==true" checked="" value="Female" ng-model="Appointment.Gender" name="gender" required="required">
					<span>Female</span>
					</label>
					</dd>
					<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.gender.$error.required" style="float: left;">Gender is required</span>-->
					</div>
				</div>

				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mealType">Meal Type</span>
					<div class="col-sm-7 col-md-7 col-lg-7">
					<select class="form-control dropdownHeight ng-pristine ng-valid ng-valid-required" ng-required="$root.isCPCollapsed==true" ng-model="Appointment.MealType" name="mealtype" required="required">
					<option style="display: none;" selected="" disabled="" value="">Select Meal Type</option>
					<option class="ng-scope ng-binding" value="UNKNOWN" >Unknown</option>
					<option class="ng-scope ng-binding" value="Vegetarian" >Vegetarian</option>
					<option class="ng-scope ng-binding" value="Jain Vegetarian">Jain Vegetarian</option>
					<option class="ng-scope ng-binding" value="Vegan">Vegan</option>
					<option class="ng-scope ng-binding" value="Eggetarian">Eggetarian</option>
					<option class="ng-scope ng-binding" value="Non Vegetarian">Non Vegetarian</option>
					</select>
					 <!-- <span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.mealtype.$error.required" style="float: left;">Meal type is required</span>-->
					</div>
				</div>
				
				<div class="form-group pad-right-5 ng-scope" ng-if="$root.isCPCollapsed">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label pad-right-0" for="mobile">Mobile</span>
					<div class="col-sm-7 col-md-7 col-lg-7 datediv">
					<div class="input-group input-group-sm">
					<span class="input-group-addon">
					<i class="fa fa-phone icons_height_width"></i>
					</span>
					<input class="form-control ng-pristine ng-valid" type="text" only-selected="" restrict-paste="" mobile-number="" name="mobileno1" ng-model="Appointment.Mobile1">
					</div>
					 <!-- <span class="error ng-hide" ng-show="SchedAppointmentForm.mobileno1.$error.mobile" style="float: left;">Invalid mobile number</span>-->
					</div>
				</div>
				
				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Nutritionist">Nutritionist</span>
					<div class="col-sm-7 col-md-7 col-lg-7">
						<select id="NutritionistId" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-change="selectBranch(Appointment.NutritionistId);IsAppointmentExist(Appointment)" ng-model="Appointment.NutritionistId" required="" name="NutritionistName" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Nutritionist</option>
						<option ng-repeat="oldcn in nutritionist | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						 <!-- <span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.NutritionistName.$error.required">Nutritionist is required.</span>-->
					</div>
				</div>

				<div class="form-group">
					<span class="col-sm-3 col-md-3 col-lg-3 control-label" for="Branch">Branch</span>
						<div class="col-sm-7 col-md-7 col-lg-7">
							<select id="Branch" class="form-control dropdownHeight" required="" name="Branch">
							<option style="display: none;" selected="" disabled="" value="">Select Branch</option>
							<option ng-repeat="branch in branchLists | orderBy:'Name'" value="{{branch.id}}">{{branch.name}}</option>
							</select>
							 <!-- <span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.Branch.$error.required">Branch is required.</span>-->
						</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Date</label>
					<div class="col-md-6">
						<div class="input-group date form_datetime">
							<input type="text" id="Sch_CreateDate" class="form-control" datepicker-popup="{{app_date_format}}" ng-model="Appointment.AppointmentDate" is-open="opened" min-date="minDate" max-date="" datepicker-options="dateOptions" date-disabled="disabled(date, mode)" ng-required="false" close-text="Close" />
							<span class="input-group-btn">
								<button type="button" class="btn btn-default" ng-click="open($event)">
									<i class="glyphicon glyphicon-calendar"></i>
								</button>
							</span>     
						</div>
						<!-- /input-group -->
					</div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Time</label>
					<div class="col-md-6">
                        <span class="col-sm-5 col-md-5 col-lg-5" style="padding: 0px;">
						<span class="input-group timediv">
						<input id="timepicker4" class="form-control input-small ng-pristine ng-animate ng-valid-remove ng-invalid-add ng-valid-required-remove ng-valid-remove-active ng-invalid ng-invalid-add-active ng-valid-required-remove-active ng-invalid-required" type="text" restrict-paste="" required="" placeholder="00:00 AM" ng-blur="IsAppointmentExist(Appointment); IsValidStrtTimeLimit(Appointment)" ng-focus="appointmentExist=false;IsStartTimeValid=false;IsEndTimeValid=false;" ng-model="Appointment.StartTime" style="width: 100%;"  name="AppointmentStartTime">
						<span class="input-group-addon" style="padding-left: 9px; padding-right: 11px;">
						<i class="fa fa-clock-o icons_height_width"></i>
						</span>
						</span>
						</span>
						
						<span class="col-sm-2 col-md-2 col-lg-2" style="padding: 5px 5px 0px 5px; width: 11%;">
							<label for="to">To</label>
						</span>
						
						<span class="col-sm-5 col-md-5 col-lg-5" style="padding: 0px; width: 42%;">
							<span class="input-group timediv">

								<input id="timepicker3" type="text" name="AppointmentEndTime" class="form-control input-small" style="width: 100%" ng-model="Appointment.EndTime" ng-focus="IsStartTimeValid=false;IsEndTimeValid=false" ng-blur="IsValidEndTimeLimit(Appointment)" placeholder="00:00 AM" required restrict-paste>
								<span class="input-group-addon" style="padding-left: 9px; padding-right: 11px;">
									<i class="fa fa-clock-o icons_height_width"></i>
								</span>
							</span>
						</span>
						
						<!--<span class="error" ng-show="submitted && SchedAppointmentForm.AppointmentEndTime.$error.required && SchedAppointmentForm.AppointmentStartTime.$error.required || IsStartTimeValid ||IsEndTimeValid">Appointment time is required.</span>
						<span class="error" id="error" ng-show="SchedAppointmentForm.AppointmentEndTime.$error.validtime && !IsStartTimeValid && !IsEndTimeValid">End time should be greater than start time.</span>
						<span class="error" ng-show="SchedAppointmentForm.AppointmentStartTime.$error.required==false && IsStartTimeValid==false && IsStartLimitInValid==true ">Invalid start time.</span>
						<span class="error" ng-show="SchedAppointmentForm.AppointmentEndTime.$error.required==false && IsEndTimeValid==false && IsEndLimitInValid==true ">Invalid end time.</span>-->
					</div>
				</div>   
				
				<div class="form-group">
					<label class="control-label col-md-3">Type</label>
					<div class="col-md-6">
						<select id="appointment_type" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" ng-model="Appointment.AppointmentTypeID" required="" name="AppointmentType" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Appointment Type</option>
						<option ng-repeat="oldcn in typeList | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						<!--<span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AppointmentType.$error.required">Attended By is required.</span>-->
						
					</div>
                </div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Attended By</label>
					<div class="col-md-6">
						<select id="attended_by" class="form-control dropdownHeight ng-pristine ng-animate ng-invalid-remove ng-valid-add ng-invalid-required-remove ng-invalid-remove-active ng-valid ng-valid-add-active ng-invalid-required-remove-active ng-valid-required" " ng-model="Appointment.attended_by" required="" name="AttendedByName" style="">
						<option style="display: none;" selected="" disabled="" value="">Select Person</option>
						<option ng-repeat="oldcn in people | orderBy:'Name'" value="{{oldcn.id}}">{{oldcn.name}}</option>
						</select>
						 <!-- <span class="error ng-hide" ng-show="submitted && SchedAppointmentForm.AttendedByName.$error.required">Attended By is required.</span>-->
					</div>
				</div>
				
				<div class="form-group" style="display:none" id="patient_checked_in">
					<input type="checkbox" value="1" ng-model="Appointment.patient_checked_in" >
					<div class="col-sm-7 col-md-7 col-lg-7">
					Patient Checked In
					</div>
				</div>
				
				<div class="form-group" style="display:none" id="appointment_complete" >
					<input type="checkbox" value="1" ng-model="Appointment.appointment_complete">
					<div class="col-sm-7 col-md-7 col-lg-7">
					Appointment Complete
					</div>
				</div>
				
				<div class="form-group">
					<div class="row col-sm-7 col-md-7 col-lg-7 col-sm-offset-3 col-md-offset-3 col-lg-offset-3" style="text-align: center;">
					<button class="btn red-intense" style="margin-bottom: 0.5%; margin-top: 0.5%; margin-right:0.5%;" ng-click="save(Appointment,true);submitted=true;" type="submit">Save</button>
					<button class="btn red-intense" style="margin-bottom: 0.5%; margin-top: 0.5%; margin-right:0.5%;" ng-click="save('','',1)" type="submit">Cancel Appointment</button>
					<button class="btn btn-w-md btn-gap-v btn-default BodyFont" style="margin-bottom: 0.5%; margin-top: 0.5%;" ng-click="Cancel()" value="Cancel" type="button">Cancel</button>
					</div>
				</div>
		</form>
	</div>
	</div>
</div>

<script type="text/ng-template" id="customRatingTemplate.html">
   <a tabindex="-1">
	  <div ng-bind-html="match.model.name"></div>
	  <small ng-bind-html="match.model.email"></small>
   </a>
</script>
