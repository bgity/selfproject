<div class="modal-header">
    <h3 class="modal-title col-md-11">Add a New Group Item</h3>
    <a ng-click="cancel()" class="btn btn-circle btn-icon-only btn-default col-md-1">
        <i class="fa fa-times"></i>
    </a>
</div>
<div class="modal-body">
    <form class="form-horizontal form-bordered" valid-submit="programadd()" name="frmprogramadd" novalidate>
        <div class="form-body">
            <div class="form-group">
                <label class="control-label col-md-3">Lable</label>
                <div class="col-md-8">
                    <input type="text" class="form-control" name="item_lable" id="item_lable"
                           ng-model="frm.item_lable" ng-required="true">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label">Field type</label>
                <div class="col-md-8">
                    <select class="layout-style-option form-control input-sm" ng-model="formData.field_type"
                            name="field_type" id="field_type"
                            ng-options="fieldtype.fieldId as fieldtype.fieldType for fieldtype in fieldTypes"
                            ng-required="true" ng-change="changeOptionItem();">
                        <option value="">Select Field Type</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label">Units</label>
                <div class="col-md-8">
                    <select class="layout-style-option form-control input-sm" ng-model="formData.field_type"
                            name="field_type" id="field_type"
                            ng-options="unittype.unitId as unittype.unitType for unittype in unitTypes"
                            ng-required="true">
                        <option value="">Select Unit Type</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <!--<label class="control-label col-md-4"></label>-->
                <div class="col-md-8">
                    <div id="dropdown" ng-if="formData.field_type == 'dropdown' || formData.field_type == 'radio' || formData.field_type == 'checkbox' || formData.field_type == 'multiplecheck'">
                        <button class="btn" ng-click="addoptions(formData);">+ Add Option</button>
                    </div>
                </div>
            </div>
            <div class="form-group" ng-repeat="options in resultValue = (formData.optionvalue) track by $index" ng-animate="animate">
                <label class="control-label col-md-3"></label>
                <div class="col-md-6">
                    <input type="text" class="form-control" name="optionval" id="optionval"
                           ng-model="formData.optionvalue[$index].optionval">
                </div>
                <div class="col-md-2">
                    <a type="button" class="btn btn-danger" ng-click="formData.optionvalue.splice(i, 1);">Del<i class="fa fa-times"></i></a>
                </div>
            </div>
            <div class="form-group">
                <!-- <label class="control-label col-md-4"></label>-->
                <div class="col-md-8">
                    <div id="dropdown">
                        <a class="btn" ng-click="addExtraOptions(formData);">+ Add Extra Field</a>
                    </div>
                </div>
            </div>
            <div class="form-group" ng-repeat="extraoptions in resultValue = (formData.extraoptionvalue) track by $index"
                 ng-animate="animate">
                <label class="control-label col-md-3"></label>
                <div class="col-md-6">
                    <input type="text" class="form-control" name="extraoptionval" id="extraoptionval" ng-model="formData.extraoptionvalue[$index].extraoptionval">
                </div>
                <div class="col-md-2">
                    <a type="button" class="btn btn-danger" ng-click="formData.extraoptionvalue.splice(i, 1);">Del<i class="fa fa-times"></i></a>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" value="Submit" class="btn green-meadow">Save</button>
                <button class="btn red-intense" ng-click="cancel()">Cancel</button>
            </div>
        </div>
    </form>
</div>