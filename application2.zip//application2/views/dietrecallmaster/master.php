<div class="panel-body master-panel-body-height-without-footer">
    <div class="container col-lg-12 col-md-12 col-sm-12">
        <div class="row">
            <div>
                <!-- ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid system-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false"
                                                           disabled="disabled">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer SystemColor"><strong class="ng-binding">Default</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Vt Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">General Health</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Mediaction Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Medical report</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dr. Visit</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Diet Followed %</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Level 2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Level 3</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Combo</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">MO</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dst Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Frd Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Alc Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Ptn Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Cho Intake</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Other Cheating</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Remarks</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Travel</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Early
                                                        Morning</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Early Morning NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong
                                                        class="ng-binding">Breakfast</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Breakfast B </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Breakfast C </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Breakfast P </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Breakfast F </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Mid
                                                        Morning</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Mid Morning NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Lunch</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch C1</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch P1</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch C2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch P2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch L2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Lunch L3</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Snack</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Snack B </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Snack C </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Snack P </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Snack F </span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Mid
                                                        Evening</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Mid Evening NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Dinner</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner C1</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner P1</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner C2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner P2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner L2</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Dinner L3</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">After
                                                        Dinner</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">After Dinner NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Food
                                                        Avoidance</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Food Avoidance NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->
                <div ng-repeat="group in dietRecallGroupList" class="ng-scope">
                    <!---------------------Edit Group Form---------------------------------------------------------------->

                    <form novalidate="" name="EditGroupForm" class="ng-pristine ng-valid">
                        <div class="row">
                            <div style="margin-left: -14px; margin-top: 5px;" class="col-sm-11 col-md-11 col-lg-11"
                                 ng-mouseleave="showEdit = false" ng-mouseenter="showEdit = true">
                                <div style="width: 0px;" class="hand-pointer col-sm-1 col-md-1 col-lg-1"
                                     ng-click="collapse = !collapse">
                                    <i ng-class="{'fa-minus-square': !collapse, 'fa-plus-square': collapse}"
                                       class="fa fa-minus-square"></i>
                                </div>

                                            <span class="rowHeight group-top-margin"
                                                  ng-hide="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex"
                                                  ng-init="currentIndex=$index" ui-on-drop="onDrop($data,group,null)"
                                                  drag="group" ui-draggable="true" draggable="true">
                                                <span
                                                    class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                    ng-show="true">
                                                    <span ng-change="editGroupCheckbox(group);collapse=false;"
                                                          ng-model="group.IsActive"
                                                          ng-class="{'active-item': group.IsActive==true &amp;&amp; (!group.IsSystem), 'inactive-item': group.IsActive==false,'system-item':group.IsSystem}"
                                                          flat-checkbox="{IsSystem:group.IsSystem,Type:&quot;Group&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                          ng-show="true"
                                                          class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>
                                                    <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                           ng-model="group.IsActive" ng-disabled="group.IsSystem"
                                                           class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                           ng-change="editGroupCheckbox(group)" ng-show="false">
                                                </span>
                                                <span ng-class="{SystemColor:group.IsSystem}"
                                                      class="default-pointer"><strong class="ng-binding">Alcohol and
                                                        other Allowance</strong></span>
                                                <a title="edit"
                                                   ng-click="editingGroup = true;hideOtherElements('editGroup',currentIndex);currentIndex=$index;IsEditingTextBox(group.IsSystem);setOldGroup(group);"
                                                   class="show-pointer ng-hide"
                                                   ng-show="showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                        class="fa fa-edit active-item"></i></a>
                                                <a title="delete"
                                                   ng-click="editingGroup = false;openDeleteEntityModal(group,'DietRecall Group',group.IsSystem,dietRecallItemList)"
                                                   ng-controller="InlineModalController"
                                                   class="show-pointer ng-scope ng-hide"
                                                   ng-show="(!group.IsSystem) &amp;&amp; showEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                        class="fa fa-times active-item"></i></a>

                                            </span>
                                <div style="padding-left: 0px; margin-top: 0px;"
                                     class="col-lg-11 col-md-11 col-sm-11 group-top-margin ng-hide"
                                     ng-show="editingGroup &amp;&amp; $root.editingGroupLock &amp;&amp; currentIndex===$root.previousGroupIndex">
                                    <div class="col-lg-3 col-md-3 col-sm-3 group-right-padding">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" style="width: 105%;" alphabets-only="" ng-maxlength="30"
                                               ng-minlength="2" required=""
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                               placeholder="Group" ng-model="group.Name" name="EditGroupName"
                                               only-names="" restrict-paste="">
                                        <span ng-show="EditGroupForm.EditGroupName.$error.required"
                                              class="error ng-hide">Group name is required.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.minlength"
                                              class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                        <span ng-show="EditGroupForm.EditGroupName.$error.maxlength"
                                              class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                                    </div>
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="group.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">

                                    <div style="padding-left: 3%;" class="col-lg-9 col-md-9 col-sm-9">
                                        <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                ng-click="editGroup(group,EditGroupForm.$valid)">Save
                                        </button>
                                        <button class="btn btn-sm btn-default btn-width"
                                                ng-click="editingGroup = false;getOldGroup(group);$root.showEditOther=true;setUniqueFalse();">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!------------------------------------------------------------------------------------->

                    <div ng-show="!collapse" class="group-indent">
                        <!-- ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <div ng-repeat="item in dietRecallItemList  | filter:{GroupId: group.Id}:strict"
                             class="ng-scope">

                            <!---------------------Edit Item Form---------------------------------------------------------------->

                            <form novalidate="" name="EditItemForm" class="ng-pristine ng-valid">
                                <!-- ngIf: item.GroupId==group.Id -->
                                <div ng-if="item.GroupId==group.Id" ng-mouseleave="showItemEdit = false"
                                     ng-mouseenter="showItemEdit = true" class="ng-scope">
                                                <span style="padding-left: 0px"
                                                      class="col-lg-12 col-md-12 col-sm-12 rowHeight"
                                                      ng-hide="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                                      ng-init="currentIndex=$index;currentParentIndex=$parent.$index"
                                                      ui-on-drop="onDrop($data,group,item)" drag="item"
                                                      ui-draggable="true" draggable="true">
                                                    <span
                                                        class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox"
                                                        ng-show="true">
                                                        <span ng-change="editItemCheckbox(item)"
                                                              ng-model="item.IsActive"
                                                              ng-class="{'active-item': item.IsActive==true &amp;&amp; (!item.IsSystem), 'inactive-item': item.IsActive==false,'system-item':item.IsSystem}"
                                                              flat-checkbox="{IsSystem:item.IsSystem,Type:&quot;Item&quot;,Access:$root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit}"
                                                              ng-show="true"
                                                              class="default-pointer ng-pristine ng-valid active-item fa fa-check-square-o"></span>

                                                        <input type="checkbox" style="cursor: pointer; margin-top: -2px"
                                                               ng-model="item.IsActive" ng-disabled="item.IsSystem"
                                                               class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                                               ng-change="editItemCheckbox(item,group)" ng-show="false">
                                                    </span>
                                                    <span ng-class="{SystemColor:item.IsSystem}"
                                                          class="default-pointer ng-binding">Alcohol and other Allowance NA</span>
                                                    <span ng-hide="true"
                                                          class="master-muted-size default-pointer ng-binding ng-hide">()</span>
                                                    <a title="edit"
                                                       ng-click="editingItem = !item.IsSystem;hideOtherElements('editItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;IsEditingTextBox(item.IsSystem);setOldItem(item);showEditMessageForSystem(item.IsSystem,'Item')"
                                                       class="show-pointer ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Edit"><i
                                                            class="fa fa-edit active-item"></i></a>
                                                    <a title="delete"
                                                       ng-click="editingItem = false;openDeleteEntityModal(item,'DietRecall Item',item.IsSystem)"
                                                       ng-controller="InlineModalController"
                                                       class="show-pointer ng-scope ng-hide"
                                                       ng-show="(!item.IsSystem) &amp;&amp; showItemEdit  &amp;&amp; $root.showEditOther &amp;&amp; $root.loggedPerson.AccessPrivileges.DietRecallAccess.Delete"><i
                                                            class="fa fa-times active-item"></i></a>

                                                </span>
                                    <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                         ng-show="editingItem &amp;&amp; $root.editingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                        <input type="text" ng-show="false" ng-model="item.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="group.Id"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="text" ng-show="false" ng-model="item.Sequence"
                                               class="form-control master-input ng-pristine ng-valid ng-hide">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsSystem" ng-show="false"
                                               class="ng-pristine ng-valid ng-hide">
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                                   required="" placeholder="Name" ng-model="item.Name"
                                                   class="form-control master-input  ng-pristine ng-valid ng-valid-maxlength ng-valid-minlength ng-valid-required"
                                                   name="EditItemName" only-names="" restrict-paste="">
                                            <span ng-show="EditItemForm.EditItemName.$error.required"
                                                  class="error ng-hide">Item name is required.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.minlength"
                                                  class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                            <span ng-show="EditItemForm.EditItemName.$error.maxlength"
                                                  class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                            <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                            <input type="text" ng-maxlength="100" placeholder="Remark"
                                                   ng-model="item.Remark"
                                                   class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                                   name="EditItemRemark">
                                            <span ng-show="EditItemForm.EditItemRemark.$error.maxlength"
                                                  class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                                    ng-click="editingItem = EditingItem(item,EditItemForm.$valid);editItem(item,group,EditItemForm.$valid);">
                                                Save
                                            </button>
                                            <button class="btn btn-sm btn-default btn-width"
                                                    ng-click="editingItem = false;$root.showEditOther=true;setUniqueFalse();getOldItem(item)">
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- end ngIf: item.GroupId==group.Id -->
                            </form>

                            <!------------------------------------------------------------------------------------->
                        </div><!-- end ngRepeat: item in dietRecallItemList  | filter:{GroupId: group.Id}:strict -->
                        <!---------------------Add Item Form---------------------------------------------------------------->

                        <form novalidate="" name="AddItemForm" class="ng-pristine ng-invalid ng-invalid-required">
                            <div>
                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12"
                                     ng-hide="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex"
                                     ng-init="currentIndex=$index;currentParentIndex=$parent.$index">
                                    <a ng-click="addingItem = true;submitted = false;hideOtherElements('addItem',$index,$parent.$index);currentIndex=$index;currentParentIndex=$parent.$index;$root.showEditOther=false"
                                       ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                                       class="active-item">Add Item</a>
                                </div>

                                <div style="padding-left: 0px" class="col-lg-12 col-md-12 col-sm-12 ng-hide"
                                     ng-show="addingItem &amp;&amp; $root.addingItemLock &amp;&amp; currentIndex===$root.previousItemIndex &amp;&amp; currentParentIndex===$root.previousParentIndex">
                                    <input type="text" ng-show="false" ng-model="item.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="text" ng-show="false" ng-model="group.Id"
                                           class="ng-pristine ng-valid ng-hide">
                                    <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                           ng-model="item.IsSystem" ng-show="false"
                                           class="ng-pristine ng-valid ng-hide">
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" alphabets-only="" ng-maxlength="50" ng-minlength="2"
                                               required="" placeholder="Name" ng-init="oldItemName=item.Name"
                                               ng-model="item.Name"
                                               class="form-control master-input ng-pristine ng-valid-maxlength ng-valid-minlength ng-invalid ng-invalid-required"
                                               name="AddItemName" ng-change="submitted=false" only-names=""
                                               restrict-paste="">
                                        <span ng-show="submitted &amp;&amp; AddItemForm.AddItemName.$error.required"
                                              class="error ng-hide">Item name is required.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.minlength" class="error ng-hide">Item name can accept minimum 2 characters.</span>
                                        <span ng-show="AddItemForm.AddItemName.$error.maxlength" class="error ng-hide">Item name can accept maximum 50 characters.</span>
                                        <span ng-show="unique" class="error ng-hide">Item already exist.</span>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 item-padding">
                                        <input type="text" ng-maxlength="100" placeholder="Remark"
                                               ng-init="oldItemRemark=item.Remark" ng-model="item.Remark"
                                               class="form-control master-input ng-pristine ng-valid ng-valid-maxlength"
                                               name="AddItemRemark">
                                        <span ng-show="AddItemForm.AddItemRemark.$error.maxlength"
                                              class="error ng-hide">Remark can accept maximum 100 characters.</span>
                                    </div>
                                    <div class="col-lg-1 col-md-1 col-sm-1 col-checkbox-span ng-hide" ng-show="false">
                                        Archive
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                         ng-show="false">
                                        <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                               ng-model="item.IsActive" style="width: 18px; height: 18px;"
                                               class="ng-pristine ng-valid">
                                    </div>
                                    <button class="btn btn-sm btn-success btn-width margin-right-2"
                                            ng-click="addItem(item,group,AddItemForm.$valid);submitted = true">Save
                                    </button>
                                    <button class="btn btn-sm btn-default btn-width"
                                            ng-click="addingItem = false;submitted = false;item.Name=oldItemName;item.Remark=oldItemRemark;$root.showEditOther=true;setUniqueFalse();">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>

                        <!------------------------------------------------------------------------------------->
                    </div>
                </div><!-- end ngRepeat: group in dietRecallGroupList -->

            </div>
            <div>
                <!---------------------Add Group Form---------------------------------------------------------------->

                <form novalidate="" name="AddGroupForm" class="ng-pristine ng-invalid ng-invalid-required">
                    <div>
                        <div class="col-lg-12 col-md-12 col-sm-12 group-top-margin"
                             ng-hide="addingGroup &amp;&amp; $root.addingGroupLock">
                            <div class="col-lg-2 col-md-2 col-sm-2 item-padding col-master-checkbox ng-hide"
                                 ng-show="false">
                                <input type="checkbox" ng-false-value="false" ng-true-value="true"
                                       ng-model="group.IsActive"
                                       class="master-checkbox checkbox-inline ng-pristine ng-valid ng-hide"
                                       ng-change="editGroup(group)" name="IsActiveGroup" ng-show="showEdit">
                            </div>
                            <a ng-click="addingGroup = true;submitted = false;hideOtherElements('addGroup');$root.showEditOther=false;"
                               ng-show="$root.loggedPerson.AccessPrivileges.DietRecallAccess.Create"
                               class="active-item"><strong>Add Group</strong></a>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 group-top-margin ng-hide"
                             ng-show="addingGroup &amp;&amp; $root.addingGroupLock">

                            <input type="text" ng-show="false" ng-model="group.Id"
                                   class="form-control master-input ng-pristine ng-valid ng-hide">
                            <input type="checkbox" ng-false-value="false" ng-true-value="true" ng-model="group.IsSystem"
                                   ng-show="false" class="ng-pristine ng-valid ng-hide">

                            <div class="col-lg-3 col-md-3 col-sm-3 item-padding">
                                <input type="text" alphabets-only="" ng-maxlength="30" ng-minlength="2" required=""
                                       placeholder="Enter Group" ng-init="oldGroupName=group.Name" ng-model="group.Name"
                                       class="form-control master-input ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength ng-valid-minlength"
                                       name="AddGroupName" ng-change="submitted=false" only-names="" restrict-paste="">
                                <span ng-show="submitted &amp;&amp; AddGroupForm.AddGroupName.$error.required"
                                      class="error ng-hide">Group name is required.</span>
                                <span ng-show="AddGroupForm.AddGroupName.$error.minlength" class="error ng-hide">Group name can accept minimum 2 characters.</span>
                                <span ng-show="AddGroupForm.AddGroupName.$error.maxlength" class="error ng-hide">Group name can accept maximum 30 characters.</span>
                                <span ng-show="unique" class="error ng-hide">Group already exist.</span>
                            </div>
                            <button class="btn btn-sm btn-success btn-width margin-right-2"
                                    ng-click="addGroup(group);submitted = true">Save
                            </button>
                            <button class="btn btn-sm btn-default btn-width"
                                    ng-click="addingGroup = false;submitted = false;group.Name=oldGroupName;$root.showEditOther=true;setUniqueFalse();">
                                Cancel
                            </button>
                        </div>
                    </div>
                </form>

                <!---------------------------------------------------------------------------------------------------->
            </div>

        </div>
    </div>
</div>