<!-- BEGIN SAMPLE TABLE PORTLET-->
<div class="portlet box green">
	<div class="portlet-title">
		<div class="caption">
			<i class="fa fa-cogs"></i>My Patients </div>

	</div>
	<div class="portlet-body flip-scroll">
		<table class="table table-bordered table-striped table-condensed flip-content">
			<thead class="flip-content">
				<tr>
					<th> Name </th>
					<th> Reference </th>
					<th> Package </th>
					<th class="numeric"> Contact </th>
					<th> Category </th>
					<th> Location </th>
					<th> Last Visit </th>
					<th> Outstanding </th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td> AAC </td>
					<td> AUSTRALIAN AGRICULTURAL COMPANY LIMITED. </td>
					<td class="numeric"> &nbsp; </td>
					<td class="numeric"> -0.01 </td>
					<td class="numeric"> -0.36% </td>
					<td class="numeric"> $1.39 </td>
					<td class="numeric"> $1.39 </td>
					<td class="numeric"> &nbsp; </td>
				</tr>
				<tr>
					<td> AAD </td>
					<td> ARDENT LEISURE GROUP </td>
					<td class="numeric"> $1.15 </td>
					<td class="numeric"> +0.02 </td>
					<td class="numeric"> 1.32% </td>
					<td class="numeric"> $1.14 </td>
					<td class="numeric"> $1.15 </td>
					<td class="numeric"> $1.13 </td>
				</tr>
				<tr>
					<td> AAX </td>
					<td> AUSENCO LIMITED </td>
					<td class="numeric"> $4.00 </td>
					<td class="numeric"> -0.04 </td>
					<td class="numeric"> -0.99% </td>
					<td class="numeric"> $4.01 </td>
					<td class="numeric"> $4.05 </td>
					<td class="numeric"> $4.00 </td>
				</tr>
				<tr>
					<td> ABC </td>
					<td> ADELAIDE BRIGHTON LIMITED </td>
					<td class="numeric"> $3.00 </td>
					<td class="numeric"> +0.06 </td>
					<td class="numeric"> 2.04% </td>
					<td class="numeric"> $2.98 </td>
					<td class="numeric"> $3.00 </td>
					<td class="numeric"> $2.96 </td>
				</tr>
				<tr>
					<td> ABP </td>
					<td> ABACUS PROPERTY GROUP </td>
					<td class="numeric"> $1.91 </td>
					<td class="numeric"> 0.00 </td>
					<td class="numeric"> 0.00% </td>
					<td class="numeric"> $1.92 </td>
					<td class="numeric"> $1.93 </td>
					<td class="numeric"> $1.90 </td>
				</tr>
				<tr>
					<td> ABY </td>
					<td> ADITYA BIRLA MINERALS LIMITED </td>
					<td class="numeric"> $0.77 </td>
					<td class="numeric"> +0.02 </td>
					<td class="numeric"> 2.00% </td>
					<td class="numeric"> $0.76 </td>
					<td class="numeric"> $0.77 </td>
					<td class="numeric"> $0.76 </td>
				</tr>
				<tr>
					<td> ACR </td>
					<td> ACRUX LIMITED </td>
					<td class="numeric"> $3.71 </td>
					<td class="numeric"> +0.01 </td>
					<td class="numeric"> 0.14% </td>
					<td class="numeric"> $3.70 </td>
					<td class="numeric"> $3.72 </td>
					<td class="numeric"> $3.68 </td>
				</tr>
				<tr>
					<td> ADU </td>
					<td> ADAMUS RESOURCES LIMITED </td>
					<td class="numeric"> $0.72 </td>
					<td class="numeric"> 0.00 </td>
					<td class="numeric"> 0.00% </td>
					<td class="numeric"> $0.73 </td>
					<td class="numeric"> $0.74 </td>
					<td class="numeric"> $0.72 </td>
				</tr>
				<tr>
					<td> AGG </td>
					<td> ANGLOGOLD ASHANTI LIMITED </td>
					<td class="numeric"> $7.81 </td>
					<td class="numeric"> -0.22 </td>
					<td class="numeric"> -2.74% </td>
					<td class="numeric"> $7.82 </td>
					<td class="numeric"> $7.82 </td>
					<td class="numeric"> $7.81 </td>
				</tr>
				<tr>
					<td> AGK </td>
					<td> AGL ENERGY LIMITED </td>
					<td class="numeric"> $13.82 </td>
					<td class="numeric"> +0.02 </td>
					<td class="numeric"> 0.14% </td>
					<td class="numeric"> $13.83 </td>
					<td class="numeric"> $13.83 </td>
					<td class="numeric"> $13.67 </td>
				</tr>
				<tr>
					<td> AGO </td>
					<td> ATLAS IRON LIMITED </td>
					<td class="numeric"> $3.17 </td>
					<td class="numeric"> -0.02 </td>
					<td class="numeric"> -0.47% </td>
					<td class="numeric"> $3.11 </td>
					<td class="numeric"> $3.22 </td>
					<td class="numeric"> $3.10 </td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<!-- END SAMPLE TABLE PORTLET-->