<div class="page-content-inner">
    <div class="row">
        <div class="col-md-12">
            <div class="portlet light ">
                <div class="portlet-body">
                    <div class="tab-content">
                        <div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
							<div class="portlet-body">
								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<img src="{{profile_image}}"/>
											<i class="fa fa-pencil-square-o fa-1 profic_img_edit" aria-hidden="true"></i>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<div class="col-md-6">
												<input disabled type="text" placeholder="Username"
													   class="form-control input-inline input-medium">
											</div>
                                        </div>
										<div class="form-group">
											<div class="col-md-6">
												<button class="btn red-intense reset-password-button" ng-click="reset_password()">Reset Password </button>
											</div>
										</div>
									</div>								
									<div class="col-md-6">
										<div class="dashboard-stat blue">
											<div class="visual">
											</div>
											<div class="details">
												<div class="number"> 10 </div>
												<div class="desc"> Active Patients </div>
											</div>
										</div>
										
										
										<div class="dashboard-stat red">
											<div class="visual">
											</div>
											<div class="details">
												<div class="number"> 24 </div>
												<div class="desc"> New Patients </div>
											</div>
										</div>
										
										<div class="dashboard-stat green">
											<div class="visual">
											</div>
											<div class="details">
												<div class="number"> 10000 </div>
												<div class="desc">Collections</div>
											</div>
										</div>
										
										<div class="dashboard-stat purple">
											<div class="visual">
											</div>
											<div class="details">
												<div class="number"> 10000 </div>
												<div class="desc">Outstanding</div>
											</div>
										</div>
										
										<div class="dashboard-stat blue">
											<div class="visual">
											</div>
											<div class="details">
												<div class="number"> 5 </div>
												<div class="desc">Missed Appointments</div>
											</div>
										</div>
									</div>
								</div>
							</div>
                            <div class="portlet box red ">
                                <div class="portlet-title">
                                    <div class="caption"> Personal Information</div>
                                    <div class="tools">
                                        <a class="collapse" href="" data-original-title="" title=""> </a>
                                        <a class="reload" href="" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body form">
                                    <form role="form" class="form-horizontal">
                                        <div class="form-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Name</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Name"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Date Of Birth</label>
                                                        <div class="col-md-6">
                                                           	<div class="input-group date form_datetime">
																<input disabled type="text" class="form-control input-date" datepicker-popup="{{format}}" ng-model="dt" is-open="opened" min-date="minDate" max-date="" datepicker-options="dateOptions" date-disabled="disabled(date, mode)" ng-required="true" close-text="Close" />
																<span class="input-group-btn">
																	<button type="button" class="btn btn-default" ng-click="open($event)">
																		<i class="glyphicon glyphicon-calendar"></i>
																	</button>
																</span>     
															</div>
														</div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Qualification</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Qualification"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
														<label class="col-md-4 form-lable-name"></label>
														<div class="col-md-8">
															<div class="radio-list">
																<label class="radio-inline">
																	<input type="radio" name="gender" id="male"  value="male" checked> Male </label>
																<label class="radio-inline">
																	<input type="radio" name="gender" id="female"  value="female"> Female </label>
															</div>
														</div>
													</div>    
                                                    <div class="form-group">
                                                        <label class="col-md-4 control-label"></label>
                                                        <div class="col-md-8">
                                                            <div class="radio-list">
                                                                <label class="radio-inline">
                                                                    <input type="radio" name="status" id="single"
                                                                           value="single" checked> Single </label>
                                                                <label class="radio-inline">
                                                                    <input type="radio" name="status" id="married"
                                                                           value="married"> Married </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="portlet box red ">
                                <div class="portlet-title">
                                    <div class="caption"> Official Information</div>
                                    <div class="tools">
                                        <a class="collapse" href="" data-original-title="" title=""> </a>
                                        <a class="reload" href="" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body form">
                                    <form role="form" class="form-horizontal">
                                        <div class="form-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
														<label class="control-label col-md-6">Date of Joining</label>
														<div class="col-md-6">
															<div class="input-group date form_datetime">
																<input disabled type="text" class="form-control input-date" datepicker-popup="{{format}}" ng-model="dt" is-open="opened" min-date="minDate" max-date="" datepicker-options="dateOptions" date-disabled="disabled(date, mode)" ng-required="true" close-text="Close" />
																<span class="input-group-btn">
																	<button type="button" class="btn btn-default" ng-click="open($event)">
																		<i class="glyphicon glyphicon-calendar"></i>
																	</button>
																</span>     
															</div>
															<!-- /input-group -->
														</div>
													</div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Designation</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Designation"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Role</label>
                                                        <div class="col-md-6">
                                                             <select class="bs-select form-control" required name="role" id="role">
																<option ng-repeat="role in roleList" value="role.value">{{ role.text}}</option>
															</select> </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Branch</label>
                                                        <div class="col-md-6">
                                                            <select class="bs-select form-control" required name="branch" id="branch">
																<option ng-repeat="branch in branchList" value="branch.value">{{ branch.text}}</option>
															</select> 
														</div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">some text</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="some text"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Username</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Username"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Password</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="password" placeholder="Password"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Confirm <br/>Password</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="password" placeholder="Confirm Password"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
													<label
														class="col-md-6 form-lable-name"></label>
													<div class="col-md-6">                                            
														 <input type="checkbox" class="make-switch" checked data-on-text="Active" data-off-text="Inactive">    
													</div>
													</div> 
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="portlet box red ">
                                <div class="portlet-title">
                                    <div class="caption"> Contact Information</div>
                                    <div class="tools">
                                        <a class="collapse" href="" data-original-title="" title=""> </a>
                                        <a class="reload" href="" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body form">
                                    <form role="form" class="form-horizontal">
                                        <div class="form-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Address</label>
                                                        <div class="col-md-6">
                                                            <textarea disabled placeholder="Full Address"
                                                                   class="form-control input-inline input-medium" /></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">City</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your City"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">State</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your State"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Country</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Country"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
													<div class="form-group">
                                                        <label class="col-md-6 control-label">Pincode</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Pincode"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Email 1</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Email ID"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Email 2</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Email ID"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-6 control-label">Mobile 1</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Mobile Number"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
													<div class="form-group">
                                                        <label class="col-md-6 control-label">Mobile 2</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Your Mobile Number"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
													<div class="form-group">
                                                        <label class="col-md-6 control-label">Home Phone</label>
                                                        <div class="col-md-6">
                                                            <input disabled type="text" placeholder="Home Phone"
                                                                   class="form-control input-inline input-medium"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                         </div>
                    </div>
                    <div class="clearfix margin-bottom-20"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/ng-template" id="reset-password">
	<div class="modal-header">
		<h3 class="modal-title">Reset Password</h3>
	</div>
	<div class="modal-body">
		<form action="#" class="form-horizontal form-bordered">
			<div class="form-body">
				<div class="form-group">
					<label class="col-md-3 control-label">Old Password</label>
					<div class="col-md-6">
					<input type="password" placeholder="Old Password" class="form-control input-inline input-medium"></div>
				</div>
				<div class="form-group">
					<label class="col-md-3 control-label">New Password</label>
					<div class="col-md-6">
					<input type="password" placeholder="New Password" class="form-control input-inline input-medium"></div>
				</div>
				<div class="form-group">
					<label class="col-md-3 control-label">Confirm <br/>Password</label>
					<div class="col-md-6">
						<input type="password" placeholder="Confirm Password"
							   class="form-control input-inline input-medium"></div>
				</div>
			</div>
		</form>
	</div>
	<div class="modal-footer">
		<button class="btn red-intense" ng-click="ok()">OK</button>
		<button class="btn red-intense" ng-click="cancel()">Cancel</button>
	</div>
</script>