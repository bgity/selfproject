<div class="portlet">
    <div class="portlet-body flip-scroll">
        <table class="table table-bordered table-striped table-condensed flip-content">
            <thead class="flip-content thead-default">
                <tr>
                    <th class="name"> Name <a ng-click="sort('name')"><i class="fa fa-sort"></i></a></th>
                    <th class="type"> Type <a ng-click="sort('type')"><i class="fa fa-sort"></i></a></th>
                    <th class="category"> Category <a ng-click="sort('category')"><i class="fa fa-sort"></i></a></th>
                    <th class="kg"> Kg <a ng-click="sort('kg')"><i class="fa fa-sort"></i></a></th>
                    <th class="amount"> Amount <a ng-click="sort('amount')"><i class="fa fa-sort"></i></a></th>
                    <th class="duration"> Duration <a ng-click="sort('duration')"><i class="fa fa-sort"></i></a></th>
                    <th class="visit"> Visits <a ng-click="sort('visit')"><i class="fa fa-sort"></i></a></th>
                    <th class="consult"> SA Consultations <a ng-click="sort('consult')"><i class="fa fa-sort"></i></a></th>
                    <th class="status"> Status <a ng-click="sort('status')"><i class="fa fa-sort"></i></a></th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="program in programList">
                    <td>{{ program.name}}</td>
                    <td>{{ program.type}}</td>
                    <td>{{ program.category}}</td>
                    <td>{{ program.kg}}</td>
                    <td>{{ program.amount}}</td>
                    <td>{{ program.duration}}</td>
                    <td>{{ program.visits}}</td>
                    <td>{{ program.consultations}}</td>
                    <td>{{ program.status}}</td>
                    <td><i class="fa fa-close"></i></td>

                </tr>
            </tbody>
        </table>
    </div>
    <div class="pagi_wrap" ng-if="programListTotal > itemsPerPage">
        <div class="dataTables_paginate paging_simple_numbers">
            <uib-pagination total-items="programListTotal" items-per-page="itemsPerPage" ng-model="currentPage"
                            page="$parent.currentPage" boundary-links="true" max-size="3"
                            class="pagination-sm"></uib-pagination>
        </div>
    </div>

</div>