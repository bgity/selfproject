<!--<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="col-sm-8">
                <label class="control-label col-sm-2">Search </label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-search"></i>
                    </span>
                    <input type="text" class="form-control" name="typeahead_example_1" id="typeahead_example_1"
                           ng-model="searchText">
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <a class="btn red-intense pull-right" ng-click="add_program()">Add a new Program</a>
                </div>
            </div>
        </div>
    </div>
</div>-->
<div class="row">
    <div class="col-md-12">
        <uib-tabset>
            <uib-tab heading="Active" active="programActiveFlag" ng-click="getProgramList('active')">
                <div ng-include="'ProgramMaster/programtabList'"></div>
            </uib-tab>
            <uib-tab heading="Inactive" active="programInactiveFlag" ng-click="getProgramList('inactive');">
                <div ng-include="'ProgramMaster/programtabList'"></div>
            </uib-tab>
        </uib-tabset>
    </div>
</div>

<script type="text/ng-template" id="add-new-program">
    <div class="modal-header">
        <h3 class="modal-title">Add a New Program</h3>
    </div>
    <div class="modal-body">
        <form class="form-horizontal form-bordered" valid-submit="programadd()" name="frmprogramadd" novalidate>
            <div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-3">Name</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="program_name" id="program_name"
                               ng-model="frm.program_name" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_name.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_name.$error.required">Name is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label">Type</label>
                    <div class="col-md-6">
                        <select class="layout-style-option form-control input-sm" ng-model="frm.program_type"
                                name="program_type" id="program_type"
                                ng-options="programtype.programtypeId as programtype.programType for programtype in programTypes"
                                ng-required="true">
                            <option value="">Select Type</option>
                        </select>
                        <div class="custom-error" ng-show="frmprogramadd.program_type.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_type.$error.required">Select Category.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label">Type</label>
                    <div class="col-md-6">
                        <select class="layout-style-option form-control input-sm" ng-model="frm.category"
                                name="category" id="category"
                                ng-options="programcategory.programCatId as programcategory.programCategory for programcategory in programCategorys"
                                ng-required="true">
                            <option value="">Select Catagory</option>
                        </select>
                        <div class="custom-error" ng-show="frmprogramadd.program_type.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_type.$error.required">Select Category.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">Kgs</label>
                    <div class="col-md-6">
                            <input type="text" class="form-control" name="program_weight" id="program_weight"
                               ng-model="frm.program_weight" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_weight.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_weight.$error.required">Weight is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">Amount</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="program_name" id="program_name"
                               ng-model="frm.program_name" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_name.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_name.$error.required">Amount is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">Duration</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="program_name" id="program_name"
                               ng-model="frm.program_name" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_name.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_name.$error.required">Duration is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">Visits</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="program_name" id="program_name"
                               ng-model="frm.program_name" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_name.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_name.$error.required">Visits is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">SA Consultation</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="program_name" id="program_name"
                               ng-model="frm.program_name" ng-required="true">
                        <div class="custom-error" ng-show="frmprogramadd.program_name.$invalid">
                            <span ng-show="frmprogramadd.$submitted && frmprogramadd.program_name.$error.required">Consultation is Required.</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" value="Submit" class="btn save_btn">Save</button>
                    <button class="btn red-intense" ng-click="cancel()">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</script>