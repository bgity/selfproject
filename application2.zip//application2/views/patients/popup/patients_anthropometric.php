<div class="row">
    <div class="col-md-12 portlet light bordered allpoup_patient_area"> 
        <div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Anthropometric </span></div>
        </div>
        <div class="portlet-body">                                        
            <div class="flip-scroll">
			<div class="scroller" style="height: 260px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                <table class="table table-striped table-condensed">
                    <thead class="flip-content thead-default">
                        <tr>
                            <th class="fileno"> Visit </th>
                            <th class="name"> Date  </th>
                            <th class="rating"> Weight  </th>
                            <th class="nutritionist"> BFC </th>
                            <th class="branch"> BFM </th>
                            <th class="program"> Chest </th>
                            <th class="registeredon"> Waist </th>
                            <th class="outstanding"> Hips </th>
                            <th class="totalbilling"> LA </th>
                            <th class="reference"> Wrist </th>
                            <th class="category"> Height </th>
                            <th class="status"> BMR </th>
                            <th class="city"> Mid Arms </th>
                            <th class="country"> Upper Thigh </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="fileno"> 002 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                        <tr>
                            <td class="fileno"> 003 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                        <tr>
                            <td class="fileno"> 004 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                        <tr>
                            <td class="fileno"> 005 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                        <tr>
                            <td class="fileno"> 006 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                        <tr>
                            <td class="fileno"> 007 </td>
                            <td class="name"> 02/04/2016  </td>
                            <td class="rating"> 60 </td>
                            <td class="nutritionist"> 45 </td>
                            <td class="branch"> 45 </td>
                            <td class="program"> 34 </td>
                            <td class="registeredon"> 34 </td>
                            <td class="outstanding"> 38 </td>
                            <td class="totalbilling"> 32 </td>
                            <td class="reference"> 11 </td>
                            <td class="category"> 5.6 </td>
                            <td class="status"> 164 </td>
                            <td class="city"> 1455 </td>
                            <td class="country"> 20 </td>                                                   
                        </tr>                                              
                    </tbody>
                </table>
            </div> 
			</div> 			
        </div>
         <div class="modal-footer">
                                    <button class="btn btn-primary" ng-click="ok()">OK</button>
                                    <button class="btn btn-warning" ng-click="cancel()">Cancel</button>
                                </div>
    </div>  
</div>  