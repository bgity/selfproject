<div class="row">
<div class="col-md-12 portlet light bordered allpoup_patient_area"> 
<div class="portlet">                
<div class="popover-title portlet-title">
		<div class="caption"><span class="caption-subject bold">Deit </span></div>
        </div>                        
        <div class="portlet-body flip-scroll">
		<div class="scroller" style="height: 260px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
            <table class="table table-striped table-condensed">
                <thead class="flip-content thead-default">
                    <tr>
                        <th class="fileno"> File No <a ng-click="sort('fileno')"><i class="fa fa-sort"></i></a> </th>
                        <th class="name"> Name <a ng-click="sort('name')"><i class="fa fa-sort"></i></a> </th>
                        <th class="rating"> Rating <a ng-click="sort('rating')"><i class="fa fa-sort"></i></a> </th>
                        <th class="nutritionist"> Nutritionist <a ng-click="sort('nutritionist')"><i class="fa fa-sort"></i></a> </th>
                        <th class="branch"> Branch <a ng-click="sort('branch')"><i class="fa fa-sort"></i></a> </th>
                        <th class="program"> Program <a ng-click="sort('program')"><i class="fa fa-sort"></i></a> </th>
                        <th class="registeredon"> Registered On <a ng-click="sort('registeredon')"><i class="fa fa-sort"></i></a> </th>
                        <th class="outstanding"> Outstanding <a ng-click="sort('outstanding')"><i class="fa fa-sort"></i></a> </th>
                        <th class="totalbilling"> Total Billing <a ng-click="sort('totalbilling')"><i class="fa fa-sort"></i></a> </th>
                        <th class="reference"> Reference <a ng-click="sort('reference')"><i class="fa fa-sort"></i></a> </th>
                        <th class="category"> Category <a ng-click="sort('category')"><i class="fa fa-sort"></i></a> </th>
                        <th class="status"> Status <a ng-click="sort('status')"><i class="fa fa-sort"></i></a> </th>
                        <th class="city"> City <a ng-click="sort('city')"><i class="fa fa-sort"></i></a> </th>
                        <th class="country"> Country <a ng-click="sort('country')"><i class="fa fa-sort"></i></a> </th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-repeat="patient in patientsList">
                        <td> {{ patient.fileno}} </td>
                        <td> <a href="patient-details.html">{{ patient.name}}</a></td>
                        <td> <uib-rating ng-model="patient.rating" max="maxRating" readonly="isReadonly" on-hover="hoveringOver(value)" on-leave="overStar = null"></uib-rating> </td>
                <td> {{ patient.nutritionist}} </td>                                                     
                <td> {{ patient.branch}} </td>                                                     
                <td> {{ patient.program}} </td>                                                     
                <td> {{ patient.register}} </td>                                                     
                <td> {{ patient.outstanding}} </td>                                                     
                <td> {{ patient.total}} </td>                                                     
                <td> {{ patient.reference}} </td>                                                     
                <td> {{ patient.category}} </td>                                                     
                <td> {{ patient.status}} </td>                                                     
                <td> {{ patient.city}} </td>                                                     
                <td> {{ patient.country}} </td>                                                     
                </tr>                                              
                </tbody>
            </table>
        </div>
        <div class="pagi_wrap" ng-if="patientsListTotal > itemsPerPage">
                        <div class="dataTables_paginate paging_simple_numbers">                                                                  
                        <uib-pagination total-items="patientsListTotal" items-per-page="itemsPerPage" ng-model="currentPage" page="$parent.currentPage" boundary-links="true" max-size="3" class="pagination-sm"></uib-pagination>                            
                        </div>
                     </div>
    </div>
	</div>
	</div>
	</div>