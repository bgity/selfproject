
<!--- Started work on profile view ------>
<div class="patient_profile_details">
<div class="profile">
                        <div class="tabbable-line tabbable-full-width">
                            
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_1_1">
                                    <div class="row patient_panel_area">
                                        <div class="col-md-2 no-space">
                                            <ul class="list-unstyled profile-nav profile-list">
                                                <li>
                                                    <img src="assets/layouts/layout/self-images/profile_picture.png" class="" alt="">
                                                    <a href="javascript:;" class="profile-edit"> </a>
                                                </li>
												<li class="star_images">
                                                    <a href="javascript:;"> <img src="assets/layouts/layout/self-images/blank_color.png" class="" alt="star_icon_self">
												<img src="assets/layouts/layout/self-images/blank_color.png" class="star_icon_self" alt="">
												<img src="assets/layouts/layout/self-images/fill_star.png" class="star_icon_self" alt="">
												<img src="assets/layouts/layout/self-images/fill_star.png" class="star_icon_self" alt="">
												<img src="assets/layouts/layout/self-images/fill_star.png" class="star_icon_self" alt="">
													</a>
                                                </li>
												<li class="patient_name_dash">
                                                    <a href="javascript:;"> <img src="assets/layouts/layout/self-images/agenda.png"> Jane Doe </a>
                                                </li>
                                                <li class="active">
                                                    <a href="javascript:;"> Patient Dashboard </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Patient Information
                                                       
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Medical History </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Program </a>
                                                </li>
												<li>
                                                    <a href="javascript:;"> Payment </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-10 no-space right_patient_text_area">
                                            <div class="row">
											<div class="height-20px"> </div>
                                                <div class="col-md-8 profile-info table-responsive">
                                                    <div class="portlet-body">
													<div class="row font-size-13">
													
													<div class="col-md-4"> 
													<table class="table table-condensed margin-left-15">
                                                                
                                                                <tbody>

                                                                    <tr>
                                                                        <td>File No</td>
                                                                        <td> 1145 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Branch</td>
                                                                        <td> Tardev </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td>Program </td>
                                                                        <td>Platinum</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Age </td>
                                                                        <td> 40 Years </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Sex </td>
                                                                        <td> Male </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td> Height </td>
                                                                        <td>5.1f</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
													</div>
													<div class="col-md-5 no-space"> 
													<table class="table table-condensed ">
                                                                
                                                                <tbody>
                                                                    <tr>
                                                                        <td> Occupation </td>
                                                                        <td> Software </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Mobile</td>
                                                                        <td> 8080049990 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td>E-mial </td>
                                                                        <td>manoj.upadhyay@appetals.com</td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    
																	<tr>
                                                                        <td>Country</td>
                                                                        <td> India </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Out Standing</td>
                                                                        <td> 15000 </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	<tr>
                                                                        <td> Status </td>
                                                                        <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                                <select class="form-control edited" id="form_control_1">
                                                    <option value=""></option>
                                                    <option value="1" selected="">Active</option>
                                                    <option value="2">Option 2</option>
                                                    <option value="3">Option 3</option>
                                                    <option value="4">Option 4</option>
                                                </select>
                                                
                                            </div> </td>
																		<td class="patie_right_border"> &nbsp; </td>
                                                                    </tr>
																	
                                                                </tbody>
                                                            </table>
													</div>
													<div class="col-md-3 no-space"> 
													<table class="table table-condensed ">
                                                                
                                                                <tbody>
                                                                    <tr>
                                                                        <td> Nutritionist </td>
                                                                        <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                                <select class="form-control edited" id="form_control_1">
                                                    <option value=""></option>
                                                    <option value="1" selected="">Sheetal</option>
                                                    <option value="2">Option 2</option>
                                                    <option value="3">Option 3</option>
                                                    <option value="4">Option 4</option>
                                                </select>
                                                
                                            </div> </td>
																		
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Meal Pref:</td>
                                                                        <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                                <select class="form-control edited" id="form_control_1">
                                                    <option value=""></option>
                                                    <option value="1" selected="">Vegeterian</option>
                                                    <option value="2">Option 2</option>
                                                    <option value="3">Option 3</option>
                                                    <option value="4">Option 4</option>
                                                </select>
                                                
                                            </div> </td>
																		
                                                                    </tr>
																	<tr>
                                                                        <td>Pregnancy </td>
                                                                        <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                                <select class="form-control edited" id="form_control_1">
                                                    <option value=""></option>
                                                    <option value="1" selected="">No</option>
                                                    <option value="2">Option 2</option>
                                                    <option value="3">Option 3</option>
                                                    <option value="4">Option 4</option>
                                                </select>
                                                
                                            </div> </td>
																		
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Cool Sculpt </td>
                                                                        <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                                <select class="form-control edited" id="form_control_1">
                                                    <option value=""></option>
                                                    <option value="1" selected=""> Yes </option>
                                                    <option value="2">Option 2</option>
                                                    <option value="3">Option 3</option>
                                                    <option value="4">Option 4</option>
                                                </select>
                                                
                                            </div> </td>
																		
                                                                    </tr>
                                                                    <tr>
                                                                        <td> Referal </td>
                                                                        <td> 6 </td>
																		
                                                                    </tr>
																	<tr>
                                                                        <td> Visits Left </td>
                                                                        <td> 12 </td>
																		
                                                                    </tr>
                                                                </tbody>
                                                            </table>
													</div>
													</div>
									
                                </div>
                                                </div>
                                                <!--end col-md-8-->
                                                <div class="col-md-4">
                                                    <div class="portlet sale-summary">
                                                        <div class="portlet-title">
                                                            <div class="caption font-red sbold"> Sales Summary </div>
                                                            <div class="tools">
                                                                <a class="reload" href="javascript:;" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <!--end col-md-4-->
                                            </div>
                                            <!--end row-->
                                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a href="#tab_1_11" data-toggle="tab" aria-expanded="true"> Snapshot </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="#tab_1_22" data-toggle="tab" aria-expanded="true"> Follow Up </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_33" data-toggle="tab" aria-expanded="true"> Meal Plans </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_44" data-toggle="tab" aria-expanded="true"> Documents </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_55" data-toggle="tab" aria-expanded="true"> Comments </a>
                                                    </li>
													<li class="">
                                                        <a href="#tab_1_66" data-toggle="tab" aria-expanded="true"> Message History </a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab_1_11">
                                                        <div class="portlet-body">
                                    <div class="table-responsive table_new_self_bg line-height-30">
                                        <table class="table">
                                            
                                            <tbody class="margin-left-15">
                                                <tr>
                                                    <td class="padding-left-15"> Blood Group </td>
                                                    <td> O +ve </td>
                                                    <td> Genetic-Pridisposition </td>
                                                    <td> Thyroid, Migrane </td>
                                                    <td> &nbsp; </td>
                                                </tr>
                                                <tr>
                                                    <td class="padding-left-15"> Current Meditation </td>
                                                    <td> Thyroid Migrane </td>
                                                    <td> Dignosis </td>
                                                    <td> Thyroid </td>
                                                   <td> &nbsp; </td>
                                                </tr>
                                                <tr>
                                                    <td class="padding-left-15"> Diseases </td>
                                                    <td> Thyronorm </td>
                                                    <td> Allergy Alert </td>
                                                    <td> Thyroid <img src="assets/layouts/layout/self-images/icon.png" class="left_text_self_icon"></td>
													 <td> <button type="button" class="btn btn-circle red-mint leftplace_tenp"> Details </button> </td>
                                                    
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
									
									<div class="table-responsive">
                                        <table class="table">
                                            
                                            <tbody>
                                                <tr>
                                                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>

                                                    <td> Sheetal </td>
                                                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Anthropromatic </button> 
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
													</td>
                                                    <td> 1500 mnt </td>
                                                    
                                                </tr>
                                                <tr>
                                                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                                                    <td> Sheetal </td>
                                                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Anthropromatic </button> 
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
													</td>
                                                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
                                                    
                                                </tr>
                                                <tr>
                                                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                                                    <td> Sheetal </td>
                                                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Anthropromatic </button> 
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
													</td>
                                                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
                                                    
                                                </tr>
												<tr>
                                                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                                                    <td> Sheetal </td>
                                                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Anthropromatic </button> 
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
													<button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
													</td>
                                                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
                                                    
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
									
                                </div>
                                                    </div>
                                                    <!--tab-pane-->
                                                    <div class="tab-pane" id="tab_1_22">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello cfgd
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													<div class="tab-pane" id="tab_1_33">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 33
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													<div class="tab-pane" id="tab_1_44">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 44
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													<div class="tab-pane" id="tab_1_55">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 55
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													<div class="tab-pane" id="tab_1_66">
                                                        <div class="portlet-body">
                                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                                
                                                                <tbody>
                                                                    hello 66
																	
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
													
													
													
													
													
                                                        </div>
                                                    </div>
                                                    <!--tab-pane-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
</div>


<!------ Started work on profile view ---------->