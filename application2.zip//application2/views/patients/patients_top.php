<div class="height-20px"> </div>
<div class="col-md-8 profile-info table-responsive">
    <div class="portlet-body">
        <div class="row font-size-13">
            <div class="col-md-4"> 
                <table class="table table-condensed margin-left-15">

                    <tbody>

                        <tr>
                            <td>File No</td>
                            <td> 1145 </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td>Branch</td>
                            <td> Tardev </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td>Program </td>
                            <td>Platinum</td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td> Age </td>
                            <td> 40 Years </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td> Sex </td>
                            <td> Male </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td> Height </td>
                            <td>5.1f</td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-5 no-space"> 
                <table class="table table-condensed ">

                    <tbody>
                        <tr>
                            <td> Occupation </td>
                            <td> Software </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td>Mobile</td>
                            <td> 8080049990 </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td>E-mial </td>
                            <td>manoj.upadhyay@appetals.com</td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>

                        <tr>
                            <td>Country</td>
                            <td> India </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td>Out Standing</td>
                            <td> 15000 </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>
                        <tr>
                            <td> Status </td>
                            <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                    <select class="form-control edited" id="form_control_1">
                                        <option value=""></option>
                                        <option value="1" selected="">Active</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>

                                </div> </td>
                            <td class="patie_right_border"> &nbsp; </td>
                        </tr>

                    </tbody>
                </table>
            </div>
            <div class="col-md-3 no-space"> 
                <table class="table table-condensed ">

                    <tbody>
                        <tr>
                            <td> Nutritionist </td>
                            <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                    <select class="form-control edited" id="form_control_1">
                                        <option value=""></option>
                                        <option value="1" selected="">Sheetal</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>

                                </div> </td>

                        </tr>
                        <tr>
                            <td>Meal Pref:</td>
                            <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                    <select class="form-control edited" id="form_control_1">
                                        <option value=""></option>
                                        <option value="1" selected="">Vegeterian</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>

                                </div> </td>

                        </tr>
                        <tr>
                            <td>Pregnancy </td>
                            <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                    <select class="form-control edited" id="form_control_1">
                                        <option value=""></option>
                                        <option value="1" selected="">No</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>

                                </div> </td>

                        </tr>
                        <tr>
                            <td> Cool Sculpt </td>
                            <td> <div class="form-group form-md-line-input form-md-floating-label has-info">
                                    <select class="form-control edited" id="form_control_1">
                                        <option value=""></option>
                                        <option value="1" selected=""> Yes </option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>

                                </div> </td>

                        </tr>
                        <tr>
                            <td> Referal </td>
                            <td> 6 </td>

                        </tr>
                        <tr>
                            <td> Visits Left </td>
                            <td> 12 </td>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<!--end col-md-8-->
<div class="col-md-4">
    <div class="portlet sale-summary">                                        
        <div class="portlet-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="progress-pie-chart customstyle" percent="targetweight1" divideby="currentweight1">

                        <div class="ppc-progress">
                            <div class="ppc-progress-fill"></div>
                        </div>
                        <div class="ppc-percents">
                            <div class="pcc-percents-wrapper">
                                <span>{{ targetweight1}}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="progress-pie-chart customstyle" percent="targetweight" divideby="currentweight">

                        <div class="ppc-progress">
                            <div class="ppc-progress-fill"></div>
                        </div>
                        <div class="ppc-percents">
                            <div class="pcc-percents-wrapper">
                                <span>{{ targetweight}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end col-md-4-->