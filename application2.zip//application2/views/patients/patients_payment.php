<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">

                            <div class="row main-height_detail_pat">
                                <?php include_once 'patients_top.php'; ?>                                
                            </div>
                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab_1_11" data-toggle="tab" aria-expanded="true"> Billing History </a>
                                    </li>
                                    <li class="">
                                        <a href="#tab_1_22" data-toggle="tab" aria-expanded="true"> Add Payment </a>
                                    </li>
                                    <li class="">
                                        <a href="#tab_1_33" data-toggle="tab" aria-expanded="true"> Adjust Payment </a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                   <div class="tab-pane active" id="tab_1_11">
                                        <div class="portlet-body">
                                            <table class="table table-striped table-bordered table-advance table-hover">
                                                <tbody>
                                                    Billing history
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab_1_22">
                                        <div class="portlet-body">
                                            <table class="table table-striped table-bordered table-advance table-hover">

                                                <tbody>
                                                    hello cfgd

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="tab-pane" id="tab_1_33">
                                        <div class="portlet-body">
                                            <table class="table table-striped table-bordered table-advance table-hover">

                                                <tbody>
                                                    hello 33

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!--tab-pane-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

