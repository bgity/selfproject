<div class="portlet-body">
   <?php include_once 'patients_info.php'; ?>
    <div class="table-responsive">
        <table class="table">
            <tbody>
                <tr>
                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                    <td> Sheetal </td>
                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropometric </button> 
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_diet')"> Diet </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_exercise')"> Exercise </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_meditation')"> Meditation </button>
                    </td>
                    <td> 1500 mnt </td>
                </tr>
                <tr>
                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                    <td> Sheetal </td>
                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropromatic </button> 
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
                    </td>
                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
                </tr>
                <tr>
                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                    <td> Sheetal </td>
                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropromatic </button> 
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
                    </td>
                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
                </tr>
                <tr>
                    <td class="padding-left-15"> <img src="assets/layouts/layout/self-images/pluse.png" class="left_text_self_icon"> 09/03/2016 </td>
                    <td> Sheetal </td>
                    <td class="center"> <button type="button" class="btn btn-circle btn-default leftplace_tenp" ng-click="loadPopup('patients_anthropometric')"> Anthropromatic </button> 
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Diet </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Exercise </button>
                        <button type="button" class="btn btn-circle btn-default leftplace_tenp"> Meditation </button>
                    </td>
                    <td> <img src="assets/layouts/layout/self-images/dustbin.png" class="left_text_self_icon"> </td>
 
               </tr>
            </tbody>
        </table>
    </div>
</div>
