<!--- Started work on profile view ------>
<div class="patient_profile_details">
    <div class="profile">
        <div class="tabbable-line tabbable-full-width">
            <div class="tab-content">
                <div class="tab-pane active" id="tab_1_1">
                    <div class="row patient_panel_area">
                        <div class="col-md-2 no-space">
                            <?php include_once 'patients_left.php'; ?>
                        </div>
                        <div class="col-md-10 no-space right_patient_text_area">
                            <div class="row main-height_detail_pat">
                                <?php include_once 'patients_top.php'; ?>                                
                            </div>
                            <!--end row-->
                            <div class="tabbable-line tabbable-custom-profile margin-top-7">
                                <ul class="nav nav-tabs">                                   
                                    <li ng-repeat="tab in tabs" ng-class="{active: $index == 0}" ng-click="loadTabContent($index)">
                                        <a data-toggle="tab" aria-expanded="true">{{ tab.title}} </a>                                        
                                    </li>
                                </ul>
                                <div class="tab-content">                                    
                                    <div  ng-repeat="tab in tabs" ng-class="{active: $index == 0}">                                                
                                        <ng-include src="tab.content" ng-if="$index == currentTab"></ng-include>
                                    </div>                                    
                                </div>                                                                                             
                            </div>
                            <!--tab-pane-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!------ Started work on profile view ---------->