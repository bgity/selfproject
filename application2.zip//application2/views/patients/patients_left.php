<ul class="list-unstyled profile-nav profile-list">
    <li>
        <img src="assets/layouts/layout/self-images/profile_picture.png" class="" alt="">
        <a href="javascript:;" class="profile-edit"> </a>
    </li>
    <li class="star_images">
        <a href="javascript:;"><uib-rating ng-model="profile_rating" max="5" readonly="true" on-hover="hoveringOver(value)" on-leave="overStar = null"></uib-rating> </a>
    </li>
    <li class="patient_name_dash">
        <a href="javascript:;"> <img src="assets/layouts/layout/self-images/agenda.png"> Jane Doe </a>
    </li>
    <li ng-class="{active: $state.current.name == 'patient_details'}">
        <a href="patient-details.html"> Patient Dashboard </a>
    </li>
    <li ng-class="{active : $state.current.name == 'patient_information'}">
        <a href="patient-information.html"> Patient Information </a>
    </li>
   <li ng-class="{active : $state.current.name == 'patient_medical_history'}">
        <a href="patient-medical-history.html"> Medical History </a>
    </li>
    <li ng-class="{active : $state.current.name == 'patient_program'}">
        <a href="patient-program.html"> Program </a>
    </li>
    <li ng-class="{active : $state.current.name == 'patient_payment'}">
        <a href="patient-payment.html"> Payment </a>
    </li>
</ul>                  