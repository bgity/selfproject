<div class="portlet-body">
    <?php include_once 'patients_info.php'; ?>
    <form name="frmFollowup" id="frmFollowup">           
        <div class="form-body">
            <div class="row">
                <div class="col-md-4">Date : <input type="text" class="form-control" name="date _follow" id="" required /></div>
                <div class="col-md-4">Time : <input type="text" class="form-control" name="time_follow" id="" required /> </div>
                <div class="col-md-4">Visit : <input type="checkbox" class="make-switch" checked data-on-text="Follow Up" data-off-text="Visit" name="status"> <input type="checkbox" class="make-switch" checked data-on-text="Active" data-off-text="Inactive" name="status" ng-model="status"></div>
                <div class="col-md-12">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">

                                <span class="caption-subject bold">Anthropometric</span>                            
                            </div>
                            <div class="tools">
                                <a href="" class="collapse" data-original-title="" title=""> </a>                            

                            </div>
                        </div>
                        <div class="portlet-body" style="display: block"> 
                            <div class="col-md-1"></div>
                            <div class="col-md-10">                        
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in AnthroDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Anthro in value">
                                                <label class="col-md-4 control-label">{{ Anthro.Name}}</label>
                                                <div class="col-md-8"><input type="text" class="form-control" name="{{ Anthro.Name}}" id="{{ Anthro.Name}}"></div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>                                 
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="height-20"></div>               
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">

                                <span class="caption-subject bold">Diet Recall</span>                            
                            </div>
                            <div class="tools">
                                <a href="" class="collapse" data-original-title="" title=""> </a>                            

                            </div>
                        </div>
                        <div class="portlet-body" style="display: block">                          
                            <div class="col-md-1"></div>
                            <div class="col-md-10">
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in DietDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Diet in value">
                                                <label class="col-md-4 control-label">{{ Diet.Name}}</label>
                                                <div class="col-md-8"><input type="text" class="form-control" name="{{ Diet.Name}}" id="{{ Diet.Name}}"></div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="height-20"></div>
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">

                                <span class="caption-subject bold">Lab tests</span>                            
                            </div>
                            <div class="tools">
                                <a href="" class="collapse" data-original-title="" title=""> </a>                            

                            </div>
                        </div>
                        <div class="portlet-body" style="display: block">                          
                            <div class="col-md-1"></div>
                            <div class="col-md-10">
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in LabtestDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Lab in value">
                                                <label class="col-md-4 control-label">{{ Lab.Name}}</label>
                                                <div class="col-md-8"><input type="text" class="form-control" name="{{ Lab.Name}}" id="{{ Lab.Name}}"></div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>    
                <div class="col-md-12">
                    <div class="height-20"></div>
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">

                                <span class="caption-subject bold">Exercise</span>                            
                            </div>
                            <div class="tools">
                                <a href="" class="collapse" data-original-title="" title=""> </a>                            

                            </div>
                        </div>
                        <div class="portlet-body" style="display: block">                          
                            <div class="col-md-1"></div>
                            <div class="col-md-10">
                                <uib-accordion close-others="true">
                                    <uib-accordion-group ng-repeat="(key, value) in ExerciseDataGroupList" is-open="$first"  heading="{{key}}">
                                        <div class="row">                              
                                            <div class="col-sm-6" ng-repeat="Exercise in value">
                                                <label class="col-md-4 control-label">{{ Exercise.Name}}</label>
                                                <div class="col-md-8"><input type="text" class="form-control" name="{{ Exercise.Name}}" id="{{ Exercise.Name}}"></div>   
                                            </div>                               
                                        </div>
                                        <br>          
                                    </uib-accordion-group>
                                </uib-accordion>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div> 
                </div>  
                <div class="col-md-12">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">
                                <span class="caption-subject bold">Medication</span>                            
                            </div>
                            <div class="tools">
                                <a href="" class="collapse" data-original-title="" title=""> </a>      
                            </div>
                        </div>
                        <div class="portlet-body" style="display: block">
                            <div class="col-md-12">
                            <div class="col-md-3"></div>
                            <div class="col-md-3">Dosage</div>
                            <div class="col-md-3">Remarkd</div>
                            <div class="col-md-3">Reminder in</div>
                            </div>
                            <div class="col-md-3">
                                <select>
                                    <option value="">Select</option>
                                    <option>Multi Vitamins</option>
                                    <option>Vitamins</option>                            
                                </select>
                            </div>
                            <div class="col-md-3"><input type="text" class="form-control"></div>
                            <div class="col-md-3"><input type="text" class="form-control"></div>
                            <div class="col-md-3"><select>
                                    <option value="">1</option>
                                    <option>2</option>
                                    <option>3</option>                            
                                </select></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-md-2"></div>
                    <div class="col-md-3 text-right" >
                        Review Require<input type="checkbox" ng-model="review_require">
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-4 text-left" ng-show="review_require">
                        Review by
                        <select>
                            <option value="">Select</option>
                            <option value="Shwetal">Shwetal</option>
                            <option value="Simran">Simran</option>                            
                        </select>
                    </div>   
                    <div class="col-md-2"></div>
                </div>
                <div class="col-md-8 text-center">                                       
                        <button type="submit">Save Only</button>
                        <button type="button">Save and Email</button>                  
                </div>
            </div>
        </div>        
    </form>
</div>


