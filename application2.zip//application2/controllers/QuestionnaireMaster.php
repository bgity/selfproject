<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class QuestionnaireMaster extends CI_Controller {

    public function questionnaireMasterList() {
        $this->load->view('questionnairemaster/questionnairemaster_list');
    }

    public function addQuestionnaireItems() {
        $this->load->view('questionnairemaster/addquestionnairemaster_item');
    }

}
