<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AnthropometricMaster extends CI_Controller {

    public function anthropometricMasterList() {
        $this->load->view('anthropometricmaster/anthropometricmaster_list');
    }

    public function addAnthropometricItems() {
        $this->load->view('anthropometricmaster/adddanthropometric_item');
    }

}
