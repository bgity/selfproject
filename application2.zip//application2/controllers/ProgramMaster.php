<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ProgramMaster extends CI_Controller {

    public function index() {
        $this->load->view('programmaster/programmaster_list');
    }

    public function programtabList() {
        $this->load->view('programmaster/programmaster_tabs');
    }

    public function getProgramsList() {
        
        $programList = array();

        if ($this->input->post('pageno') != '') {
            $page = $this->input->post('pageno') - 1;
        } else {
            $page = 0;
        }
        $status = $this->input->post('status');
        $limit = $this->config->item('pagination_limit');
        $start = $page * $limit;

        $programData = json_decode(file_get_contents(base_url() . '/assets/json/programMaster.json'), true);
         foreach ($programData as $n) {
            if (isset($n['status']) == $status) {
                $programList['data'][] = $n;
            }
        }
        $programList['total'] = count($programList['data']);
        $programList['data'] = (array_slice($programList['data'], $start, $limit));
        $this->output->set_content_type('application/json')->set_output(json_encode($programList));
    }

}
