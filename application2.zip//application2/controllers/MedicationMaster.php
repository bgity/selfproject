<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MedicationMaster extends CI_Controller
{

    public function medicationMasterList()
    {
        $this->load->view('medicationmaster/medicationmaster_list');
    }
    
    public function addMedicationItems() {
        $this->load->view('medicationmaster/adddmedication_item');
    }

}
