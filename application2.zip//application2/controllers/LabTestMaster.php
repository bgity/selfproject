<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LabTestMaster extends CI_Controller {

    public function labTestMasterList() {
        $this->load->view('labtestmaster/labtestmaster_list');
    }

    public function addLabTestItems() {
        $this->load->view('labtestmaster/adddlabtest_item');
    }

}
