<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class DiagnosisMaster extends CI_Controller {

    public function diagnosisMasterList() {
        $this->load->view('diagnosismaster/diagnosismaster_list');
    }

    public function addDiagnosisItems() {
        $this->load->view('labtestmaster/diagnosisadd_item');
    }

}
