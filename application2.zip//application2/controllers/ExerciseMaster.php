<?php

/********************************************************/
/** Class/Function Name		    : ExerciseMaster()
/**
/** Class/Function Description	: This function is use user list for Exercise Master.
/**
/**
/** Author   			        : Bhagwan Pawar[bhagwan.pawar@appetals.com]
/**
/** Creation Date		        : [24/04/2016]
/**
/** param1			            : -
/** param2			            : -
/** return			            : Exercise master view
/**
/*********************************************************/

defined('BASEPATH') OR exit('No direct script access allowed');

class ExerciseMaster extends CI_Controller
{
    public function exerciseMasterList() {
        $this->load->view('exercisemaster/exercisemaster_list');
    }

    public function addExerciseItems() {
        $this->load->view('exercisemaster/adddexercise_item');
    }

}
