<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DietrecallMaster extends CI_Controller
{

    public function dietrecallmasterList()
    {
        $this->load->view('dietrecallmaster/dietrecallmaster_list');
    }

    public function addDietRecallItems()
    {
        $this->load->view('dietrecallmaster/adddietrecall_item');
    }

}
