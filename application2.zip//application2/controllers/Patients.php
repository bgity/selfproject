<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('patients/patients_listing');
	}
	public function add()
	{
		$this->load->view('patients/patients_add');
	}
	public function patientsMedicalHistory()
	{
		$this->load->view('patients/patients_medical_history');
	}
	public function patientsMedicalHistoryDiseases()
	{
		$this->load->view('patients/patients_medical_history_diseases');
	}
        public function patientDetails(){
            $this->load->view('patients/patient_details');
        }
	public function patientCommonList()
	{
		$this->load->view('patients/patients_tabs');
	}
	public function patientsSnapshot()
	{
		$this->load->view('patients/patients_snapshot');
	}
	public function patientsFollowup()
	{
		$this->load->view('patients/patients_followup');
	}
	public function patientsMealPlans()
	{
		$this->load->view('patients/patients_meal_plans');
	}
	public function patientsDocuments()
	{
		$this->load->view('patients/patients_documents');
	}
	public function patientsComments()
	{
		$this->load->view('patients/patients_comments');
	}
	public function patientsMessageHistory()
	{
		$this->load->view('patients/patients_message_history');
	}
	public function patientsAnthropometric()
	{
		$this->load->view('patients/popup/patients_anthropometric');
	}
	public function patientsDiet()
	{
		$this->load->view('patients/popup/patients_diet');
	}
	public function patientsInformation()
	{
		$this->load->view('patients/patients_information');
	}
	public function patientsProgram()
	{
		$this->load->view('patients/patients_program');
	}
	public function patientsPayment()
	{
		$this->load->view('patients/patients_payment');
	}
         public function getPatientsList(){
            $patientList=array();
            
            if($this->input->post('pageno') != ''){
                $page = $this->input->post('pageno') - 1;
            } else {
                $page = 0;
            }            
            $status = $this->input->post('status');
            
            
            $limit=$this->config->item('pagination_limit');
            $start=$page * $limit;
            
            $patients = json_decode(file_get_contents(base_url().'/assets/json/patientsList.json'),true);
            if($status == 'showall'){
                foreach ($patients as $p){                                
                    $patientList['data'][]=$p;               
                }  
            }else {
                foreach ($patients as $p){                
                    if($p['status'] == $status){
                        $patientList['data'][]=$p;
                    }
                }  
            }
            
                      
            $patientList['total'] = count($patientList['data']); 
            $patientList['data'] = (array_slice( $patientList['data'], $start, $limit));
                       
            $this->output->set_content_type('application/json')->set_output(json_encode($patientList));            
        }
	
	
        
        
}
