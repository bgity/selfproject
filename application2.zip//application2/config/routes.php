<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//html url starts
$route['(:any).html'] = 'home';
//html url ends

//url routing for base starts  
$route['dashboard']="home/dashboard";
$route['my-dashboard']="home/my_dashboard";
$route['my-patients']="home/my_patients";
$route['my_profile']="home/my_profile";
$route['my-appointments']="appointment/my_appointments";
$route['team-calendar']="appointment/team_calendar";

$route['patients']="patients";
$route['patients_add']="patients/add";
$route['patient_details']="patients/patientDetails";
$route['patients_snapshot']="patients/patientsSnapshot";
$route['patients_followup']="patients/patientsFollowup";
$route['patients_meal_plans']="patients/patientsMealPlans";
$route['patients_documents']="patients/patientsDocuments";
$route['patients_comments']="patients/patientsComments";
$route['patients_message_history']="patients/patientsMessageHistory";
$route['patients_anthropometric']="patients/patientsAnthropometric";
$route['patients_diet']="patients/patientsDiet";
$route['patients_information']="patients/patientsInformation";
$route['patients_medical_history']="patients/patientsMedicalHistory";
$route['patients_medical_history_diseases']="patients/patientsMedicalHistoryDiseases";
$route['patients_program']="patients/patientsProgram";
$route['patients_payment']="patients/patientsPayment";

$route['get_patients_list']="patients/getPatientsList";



$route['login']="login/index";
$route['nutritionists']="nutritionists";
$route['get_nutritionists_list']="nutritionists/getNutritionistsList";
$route['nutritionists_add']="nutritionists/nutritionstadd";


$route['dietrecallmaster_list']="DietrecallMaster/dietrecallmasterList";
$route['branchmaster_list']="BranchMaster/branchMasterList";
$route['medicationmaster_list']="MedicationMaster/medicationMasterList";
$route['programmaster_list']="ProgramMaster";
$route['get_program_list']="ProgramMaster/getProgramsList";
$route['exercisemaster_list']="ExerciseMaster/exerciseMasterList";
$route['labtestmaster_list']="LabTestMaster/labTestMasterList";
$route['anthropometricmaster_list']="AnthropometricMaster/anthropometricMasterList";
$route['diagnosismaster_list']="DiagnosisMaster/diagnosisMasterList";
$route['questionnairemaster_list']="QuestionnaireMaster/questionnaireMasterList";
//url routing for base ends
 

